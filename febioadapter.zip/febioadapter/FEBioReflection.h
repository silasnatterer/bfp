//
// Created by fritz on 5/5/22.
//

#ifndef FEBIOPRECICEADAPTER_FEBIOREFLECTION_H
#define FEBIOPRECICEADAPTER_FEBIOREFLECTION_H

#include <rttr/registration>
using namespace rttr;



class FEBioReflection {

};


#endif //FEBIOPRECICEADAPTER_FEBIOREFLECTION_H
