#pragma once

#include <string>
#include <vector>
//#include "Partition.hpp"

#include "Partition2.h"

#include "logging/Logger.hpp"
#include "mesh/BoundingBox.hpp"
//#include "mesh/Mesh.hpp"

#include "Mesh2.h"

#include "mesh/SharedPointer.hpp"
#include "mesh/Vertex.hpp"

#include "M2N2.h"
#include "partition/ReceivedPartition.hpp"

namespace precice {
namespace m2n {
class M2N;
} // namespace m2n

namespace partition {

/**
 * @brief A partition that is computed from a mesh received from another participant.
 *
 * A mesh is received by the master rank and re-partitioned among all slave ranks.
 * Afterwards necessary distribution data structures are set up.
 */
class ReceivedPartition2 : public Partition2 {
public:
  /// Defines the typ of geometric filter used
  enum GeometricFilter {
    /// undefined
    UNDEFINED,
    /// No geometric filter used (e.g. for RBF mappings)
    NO_FILTER,
    /// Filter at master and communicate only filtered mesh.
    ON_MASTER,
    /// Filter after communication on all slave ranks
    ON_SLAVES
  };
  
  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;

  /// Constructor
  ReceivedPartition2(PtrMesh2 mesh, partition::ReceivedPartition::GeometricFilter geometricFilter, double safetyFactor);

  virtual ~ReceivedPartition2() {}

  void communicate() override;

  void compute() override;

  void compareBoundingBoxes() override;

private:
  /// return the one m2n, a ReceivedPartition can only have one m2n
  m2n::M2N2 &m2n();

  void filterByBoundingBox();

  /// Sets _bb to the union with the mesh from fromMapping resp. toMapping, also enlage by _safetyFactor
  void prepareBoundingBox();

  /** Checks whether provided meshes are empty.
   *
   * Empty provided meshes mean that the re-partitioning completely filtered
   * out the mesh received on this rank at the coupling interface.
   */
  bool areProvidedMeshesEmpty() const;

  void createOwnerInformation();

  /// Helper function for 'createOwnerFunction' to set local owner information
  void setOwnerInformation(const std::vector<int> &ownerVec);

  /// Is the local other (i.e. provided) bounding box already prepared (i.e. has prepareBoundingBox() been called)
  bool _boundingBoxPrepared = false;

  partition::ReceivedPartition::GeometricFilter _geometricFilter;

  mesh::BoundingBox _bb;

  int _dimensions;

  double _safetyFactor;

  logging::Logger _log{"partition::ReceivedPartition"};

  /// Max global vertex IDs of remote connected ranks
  std::vector<int> _remoteMaxGlobalVertexIDs;

  /// Min global vertex IDs of remote connected ranks
  std::vector<int> _remoteMinGlobalVertexIDs;
};

} // namespace partition
} // namespace precice
