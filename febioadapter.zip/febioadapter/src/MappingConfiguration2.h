#pragma once

#include "mapping/SharedPointer.hpp"

#include "XMLTag2.h"
#include "MeshConfiguration2.h"
#include "Mesh2.h"
#include "Mapping2.h"

namespace precice {
namespace mapping {

/// How to handle the polynomial?
/**
 * ON: Include it in the system matrix
 * OFF: Omit it altogether
 * SEPARATE: Compute it separately using least-squares QR.
 */
enum class Polynomial2 {
  ON,
  OFF,
  SEPARATE
};

enum class Preallocation2 {
  OFF,
  COMPUTE,
  ESTIMATE,
  SAVE,
  TREE
};

enum class RBFType2 {
  EIGEN,
  PETSc
};

/// Performs XML configuration and holds configured mappings.
class MappingConfiguration2  : public xml::XMLTag2::Listener {
public:
  
  using PtrMeshConfiguration2 = std::shared_ptr<precice::mesh::MeshConfiguration2>;
  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrMapping2 = std::shared_ptr<Mapping2>;
      
 /// Constants defining the direction of a mapping.
  enum Direction2 {
    WRITE,
    READ
  };

  enum Timing2 {
    INITIAL,
    ON_ADVANCE,
    ON_DEMAND
  };

  /// Configuration data for one mapping.
  struct ConfiguredMapping2 {
    /// Mapping object.
    PtrMapping2 mapping;
    /// Remote mesh to map from
    PtrMesh2 fromMesh;
    /// Remote mesh to map to
    PtrMesh2 toMesh;
    /// Direction of mapping (important to set input and output mesh).
    Direction2 direction;
    /// When the mapping should be executed.
    Timing2 timing;
    /// true for RBF mapping
    bool isRBF;
  };
  
   FEModel *fem1;
  
   MappingConfiguration2(
      xml::XMLTag2 &                     parent,
      const PtrMeshConfiguration2 &meshConfiguration,
      FEModel *fem);
   
  /**
   * @brief Callback function required for use of automatic configuration.
   *
   * @return True, if successful.
   */
  virtual void XMLTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);
  /**
   * @brief Callback function required for use of automatic configuration.
   *
   * @return True, if successful.
   */
  virtual void xmlEndTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);

  /// Returns all configured mappings.
  const std::vector<ConfiguredMapping2> &mappings();

  void resetMappings()
  {
    _mappings.clear();
  }
  
private:
  mutable logging::Logger _log{"config:MappingConfiguration2"};

  const std::string TAG = "mapping";

  const std::string ATTR_DIRECTION      = "direction";
  const std::string ATTR_FROM           = "from";
  const std::string ATTR_TO             = "to";
  const std::string ATTR_TIMING         = "timing";
  const std::string ATTR_TYPE           = "type";
  const std::string ATTR_CONSTRAINT     = "constraint";
  const std::string ATTR_SHAPE_PARAM    = "shape-parameter";
  const std::string ATTR_SUPPORT_RADIUS = "support-radius";
  const std::string ATTR_SOLVER_RTOL    = "solver-rtol";
  const std::string ATTR_X_DEAD         = "x-dead";
  const std::string ATTR_Y_DEAD         = "y-dead";
  const std::string ATTR_Z_DEAD         = "z-dead";
  const std::string ATTR_USE_QR         = "use-qr-decomposition";

  const std::string VALUE_WRITE        = "write";
  const std::string VALUE_READ         = "read";
  const std::string VALUE_CONSISTENT   = "consistent";
  const std::string VALUE_CONSERVATIVE = "conservative";

  const std::string VALUE_NEAREST_NEIGHBOR      = "nearest-neighbor";
  const std::string VALUE_NEAREST_PROJECTION    = "nearest-projection";
  const std::string VALUE_RBF_TPS               = "rbf-thin-plate-splines";
  const std::string VALUE_RBF_MULTIQUADRICS     = "rbf-multiquadrics";
  const std::string VALUE_RBF_INV_MULTIQUADRICS = "rbf-inverse-multiquadrics";
  const std::string VALUE_RBF_VOLUME_SPLINES    = "rbf-volume-splines";
  const std::string VALUE_RBF_GAUSSIAN          = "rbf-gaussian";
  const std::string VALUE_RBF_CTPS_C2           = "rbf-compact-tps-c2";
  const std::string VALUE_RBF_CPOLYNOMIAL_C0    = "rbf-compact-polynomial-c0";
  const std::string VALUE_RBF_CPOLYNOMIAL_C6    = "rbf-compact-polynomial-c6";

  const std::string VALUE_TIMING_INITIAL    = "initial";
  const std::string VALUE_TIMING_ON_ADVANCE = "onadvance";
  const std::string VALUE_TIMING_ON_DEMAND  = "ondemand";
  
  PtrMeshConfiguration2 _meshConfig;

  std::vector<ConfiguredMapping2> _mappings;  

  ConfiguredMapping2 createMapping(
      const xml::ConfigurationContext2 &context,
      const std::string &              direction,
      const std::string &              type,
      const std::string &              constraint,
      const std::string &              fromMeshName,
      const std::string &              toMeshName,
      Timing2                           timing,
      double                           shapeParameter,
      double                           supportRadius,
      double                           solverRtol,
      bool                             xDead,
      bool                             yDead,
      bool                             zDead,
      bool                             useLU,
      Polynomial2                      polynomial,
      Preallocation2                   preallocation) const;

  void checkDuplicates(const ConfiguredMapping2 &mapping);

  Timing2 getTiming(const std::string &timing) const;
};

} // namespace mapping
} // namespace precice
