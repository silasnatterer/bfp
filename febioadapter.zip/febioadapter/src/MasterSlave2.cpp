//#ifndef PRECICE_NO_MPI

//#include "MasterSlave.hpp"

#include "MasterSlave2.h"

#include <Eigen/Core>
#include <math.h>
#include <memory>
#include <ostream>
#include <string>
//#include "com/Communication.hpp"

#include "Communication2.h"

#include "logging/LogMacros.hpp"
#include "logging/Logger.hpp"
#include "utils/assertion.hpp"

namespace precice {
namespace utils {

  using PtrCommunication2 = std::shared_ptr<precice::com::Communication2>;

int                   MasterSlave2::_rank     = -1;
int                   MasterSlave2::_size     = -1;
bool                  MasterSlave2::_isMaster = false;
bool                  MasterSlave2::_isSlave  = false;
PtrCommunication2 MasterSlave2::_communication;

logging::Logger MasterSlave2::_log("utils::MasterSlave");

void MasterSlave2::configure(int rank, int size)
{
  PRECICE_TRACE(rank, size);
  _rank = rank;
  _size = size;
  PRECICE_ASSERT(_rank != -1 && _size != -1);
  _isMaster = (rank == 0) && _size != 1;
  _isSlave  = (rank != 0);
  PRECICE_DEBUG("isSlave: " << _isSlave << ", isMaster: " << _isMaster);
}

int MasterSlave2::getRank()
{
  return _rank;
}

int MasterSlave2::getSize()
{
  return _size;
}

bool MasterSlave2::isMaster()
{
  return _isMaster;
}

bool MasterSlave2::isSlave()
{
  return _isSlave;
}

double MasterSlave2::l2norm(const Eigen::VectorXd &vec)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) { //old case
    return vec.norm();
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());
  double localSum2  = 0.0;
  double globalSum2 = 0.0;

  for (int i = 0; i < vec.size(); i++) {
    localSum2 += vec(i) * vec(i);
  }

  // localSum is modified, do not use afterwards
  allreduceSum(localSum2, globalSum2, 1);
  /* old loop over all slaves solution
  if(_isSlave){
    _communication->send(localSum2, 0);
    _communication->receive(globalSum2, 0);
  }
  if(_isMaster){
    globalSum2 += localSum2;
    for(int rankSlave = 1; rankSlave < _size; rankSlave++){
      _communication->receive(localSum2, rankSlave);
      globalSum2 += localSum2;
    }
    for(int rankSlave = 1; rankSlave < _size; rankSlave++){
      _communication->send(globalSum2, rankSlave);
    }
  }
  */
  return sqrt(globalSum2);
}

double MasterSlave2::dot(const Eigen::VectorXd &vec1, const Eigen::VectorXd &vec2)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) { //old case
    return vec1.dot(vec2);
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());
  PRECICE_ASSERT(vec1.size() == vec2.size(), vec1.size(), vec2.size());
  double localSum  = 0.0;
  double globalSum = 0.0;

  for (int i = 0; i < vec1.size(); i++) {
    localSum += vec1(i) * vec2(i);
  }

  // localSum is modified, do not use afterwards
  allreduceSum(localSum, globalSum, 1);

  // old loop over all slaves solution
  /*
  if(_isSlave){
    _communication->send(localSum, 0);
    _communication->receive(globalSum, 0);
  }
  if(_isMaster){
    globalSum += localSum;
    for(int rankSlave = 1; rankSlave < _size; rankSlave++){
      _communication->receive(localSum, rankSlave);
      globalSum += localSum;
    }
    for(int rankSlave = 1; rankSlave < _size; rankSlave++){
      _communication->send(globalSum, rankSlave);
    }
  }
  */
  return globalSum;
}

void MasterSlave2::reset()
{
  PRECICE_TRACE();
  _isMaster = false;
  _isSlave  = false;
  _rank     = -1;
  _size     = -1;
}

void MasterSlave2::reduceSum(double *sendData, double *rcvData, int size)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isSlave) {
    // send local result to master
    _communication->reduceSum(sendData, rcvData, size, 0);
  }

  if (_isMaster) {
    // receive local results from slaves, apply SUM
    _communication->reduceSum(sendData, rcvData, size);
  }
}

void MasterSlave2::reduceSum(int &sendData, int &rcvData, int size)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isSlave) {
    // send local result to master
    _communication->reduceSum(sendData, rcvData, 0);
  }

  if (_isMaster) {
    // receive local results from slaves, apply SUM
    _communication->reduceSum(sendData, rcvData);
  }
}

void MasterSlave2::allreduceSum(double *sendData, double *rcvData, int size)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isSlave) {
    // send local result to master, receive reduced result from master
    _communication->allreduceSum(sendData, rcvData, size, 0);
  }

  if (_isMaster) {
    // receive local results from slaves, apply SUM, send reduced result to slaves
    _communication->allreduceSum(sendData, rcvData, size);
  }
}

void MasterSlave2::allreduceSum(double &sendData, double &rcvData, int size)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isSlave) {
    // send local result to master, receive reduced result from master
    _communication->allreduceSum(sendData, rcvData, 0);
  }

  if (_isMaster) {
    // receive local results from slaves, apply SUM, send reduced result to slaves
    _communication->allreduceSum(sendData, rcvData);
  }
}

void MasterSlave2::allreduceSum(int &sendData, int &rcvData, int size)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isSlave) {
    // send local result to master, receive reduced result from master
    _communication->allreduceSum(sendData, rcvData, 0);
  }

  if (_isMaster) {
    // receive local results from slaves, apply SUM, send reduced result to slaves
    _communication->allreduceSum(sendData, rcvData);
  }
}

void MasterSlave2::broadcast(bool &value)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isMaster) {
    // Broadcast (send) value.
    _communication->broadcast(value);
  }

  if (_isSlave) {
    // Broadcast (receive) value.
    _communication->broadcast(value, 0);
  }
}

void MasterSlave2::broadcast(double &value)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isMaster) {
    // Broadcast (send) value.
    _communication->broadcast(value);
  }

  if (_isSlave) {
    // Broadcast (receive) value.
    _communication->broadcast(value, 0);
  }
}

void MasterSlave2::broadcast(double *values, int size)
{
  PRECICE_TRACE();

  if (not _isMaster && not _isSlave) {
    return;
  }

  PRECICE_ASSERT(_communication.get() != nullptr);
  PRECICE_ASSERT(_communication->isConnected());

  if (_isMaster) {
    // Broadcast (send) value.
    _communication->broadcast(values, size);
  }

  if (_isSlave) {
    // Broadcast (receive) value.
    _communication->broadcast(values, size, 0);
  }
}

} // namespace utils
} // namespace precice
