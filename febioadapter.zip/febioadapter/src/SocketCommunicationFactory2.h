#pragma once

//#include "CommunicationFactory.hpp"

#include "CommunicationFactory2.h"

#include "com/SharedPointer.hpp"
#include "utils/networking.hpp"

#include "Communication2.h"
#include <string>

namespace precice {
namespace com {
class SocketCommunicationFactory2 : public CommunicationFactory2 
{
public:

  using PtrCommunication2 = std::shared_ptr<Communication2>;

  SocketCommunicationFactory2(unsigned short     portNumber       = 0,
                             bool               reuseAddress     = false,
                             std::string const &networkName      = utils::networking::loopbackInterfaceName(),
                             std::string const &addressDirectory = ".");

  explicit SocketCommunicationFactory2(std::string const &addressDirectory);

  PtrCommunication2 newCommunication() override;

  std::string addressDirectory() override;

private:
  unsigned short _portNumber;
  bool           _reuseAddress;
  std::string    _networkName;
  std::string    _addressDirectory;
};
} // namespace com
} // namespace precice
