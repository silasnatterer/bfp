//#include "Mapping.hpp"

#include "Mapping2.h"

#include <boost/config.hpp>
#include <ostream>
#include "utils/assertion.hpp"

namespace precice {
namespace mapping {

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;

Mapping2::Mapping2(
    Constraint constraint,
    int        dimensions)
    : _constraint(constraint),
      _inputRequirement(MeshRequirement::UNDEFINED),
      _outputRequirement(MeshRequirement::UNDEFINED),
      _input(),
      _output(),
      _dimensions(dimensions)
{
}

void Mapping2::setMeshes(
    const PtrMesh2 &input,
    const PtrMesh2 &output)
{
  _input  = input;
  _output = output;
}

const PtrMesh2 &Mapping2::getInputMesh() const
{
  return _input;
}

const PtrMesh2 &Mapping2::getOutputMesh() const
{
  return _output;
}

Mapping2::Constraint Mapping2::getConstraint() const
{
  return _constraint;
}

Mapping2::MeshRequirement Mapping2::getInputRequirement() const
{
  return _inputRequirement;
}

Mapping2::MeshRequirement Mapping2::getOutputRequirement() const
{
  return _outputRequirement;
}

PtrMesh2 Mapping2::input() const
{
  return _input;
}

PtrMesh2 Mapping2::output() const
{
  return _output;
}

void Mapping2::setInputRequirement(
    MeshRequirement requirement)
{
  _inputRequirement = requirement;
}

void Mapping2::setOutputRequirement(
    MeshRequirement requirement)
{
  _outputRequirement = requirement;
}

int Mapping2::getDimensions() const
{
  return _dimensions;
}

bool operator<(Mapping2::MeshRequirement lhs, Mapping2::MeshRequirement rhs)
{
  switch (lhs) {
  case (Mapping2::MeshRequirement::UNDEFINED):
    return rhs != Mapping2::MeshRequirement::UNDEFINED;
  case (Mapping2::MeshRequirement::VERTEX):
    return rhs == Mapping2::MeshRequirement::FULL;
  case (Mapping2::MeshRequirement::FULL):
    return false;
  };
  BOOST_UNREACHABLE_RETURN(false);
}

std::ostream &operator<<(std::ostream &out, Mapping2::MeshRequirement val)
{
  switch (val) {
  case (Mapping2::MeshRequirement::UNDEFINED):
    out << "UNDEFINED";
    break;
  case (Mapping2::MeshRequirement::VERTEX):
    out << "VERTEX";
    break;
  case (Mapping2::MeshRequirement::FULL):
    out << "FULL";
    break;
  default:
    PRECICE_ASSERT(false, "Implementation does not cover all cases");
  };
  return out;
}

} // namespace mapping
} // namespace precice
