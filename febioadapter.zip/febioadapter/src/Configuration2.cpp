#include "Configuration2.h"
#include "logging/LogMacros.hpp"
#include "xml/XMLAttribute.hpp"

namespace precice {

extern bool syncMode;

namespace config {

Configuration2::Configuration2(FEModel *fem)
 //     : _tag(*this, "precice-Configuration", xml::XMLTag::OCCUR_ONCE)
    : _tag(*this, "precice-configuration", xml::XMLTag2::OCCUR_ONCE, "", fem),
      _logConfig(_tag, fem),
      _solverInterfaceConfig(_tag, fem)
{
   fem1 = fem;

   write_log(fem1, 3,"here precice 17.1");
   
  _tag.setDocumentation("Main tag containing preCICE Configuration.");
  _tag.addNamespace("data");
  _tag.addNamespace("communication");
  _tag.addNamespace("mapping");
  _tag.addNamespace("export");
  _tag.addNamespace("action");
  _tag.addNamespace("coupling-scheme");
  _tag.addNamespace("acceleration");

  auto attrSyncMode = xml::makeXMLAttribute("sync-mode", false)
                          .setDocumentation("sync-mode enabled additional inter- and intra-participant synchronizations");
  _tag.addAttribute(attrSyncMode);
  
  
  write_log(fem1, 3,"here precice 17.2");
  
}

xml::XMLTag2 &Configuration2::getXMLTag()
{
  return _tag;
}

/*
xml::XMLTag &Configuration2::getXMLTag()
{
  return _tag;
}
*/

void Configuration2::XMLTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag)
{
  PRECICE_TRACE(_tag.getName());
  if (_tag.getName() == "precice-configuration") {
    precice::syncMode = _tag.getBooleanAttributeValue("sync-mode");
  }
}

void Configuration2::xmlEndTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag)
{
  PRECICE_TRACE(_tag.getName());
}

const SolverInterfaceConfiguration2 &
Configuration2::getSolverInterfaceConfiguration() const
{
  return _solverInterfaceConfig;
}

} // namespace config
} // namespace precice
