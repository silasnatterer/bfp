#pragma once

#include <Eigen/Core>
#include <memory>
#include <stddef.h>
#include <string>
#include <utility>
#include <vector>
#include "SharedPointer.hpp"
#include "action/SharedPointer.hpp"
#include "cplscheme/SharedPointer.hpp"
#include "io/ExportContext.hpp"
#include "io/config/ExportConfiguration.hpp"
#include "logging/Logger.hpp"
#include "mapping/SharedPointer.hpp"
#include "mesh/SharedPointer.hpp"
#include "partition/ReceivedPartition.hpp"
#include "utils/ManageUniqueIDs.hpp"
#include "utils/MasterSlave.hpp"
#include "utils/PointerVector.hpp"
#include "WatchPoint.hpp"

#include "MeshConfiguration2.h"
#include "Mesh2.h"
#include "Data2.h"

#include "DataContext2.h"
#include "MappingContext2.h"
#include "MeshContext2.h"

namespace precice {
namespace impl {
struct DataContext;
struct MeshContext;
struct MappingContext;
} // namespace impl
} // namespace precice

// Forward declaration to friend the boost test struct
namespace PreciceTests {
namespace Serial {
struct TestConfigurationPeano;
struct TestConfigurationComsol;
} // namespace Serial
} // namespace PreciceTests

namespace precice {
namespace utils {
class ManageUniqueIDs;
} // namespace utils

namespace impl {

/// Holds coupling state of one participating solver in coupled simulation.
class Participant2 {
public:

  using PtrMeshConfiguration2 = std::shared_ptr<precice::mesh::MeshConfiguration2>;
  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrData2 = std::shared_ptr<precice::mesh::Data2>;

  enum MappingConstants {
    MAPPING_LINEAR_CONSERVATIVE,
    MAPPING_LINEAR_CONSISTENT,
    MAPPING_DIRECT
  };

  /**
   * @brief Constructor.
   *
   * @param[in] name Name of the participant. Has to be unique.
   */
  Participant2(
      std::string                 name,
      PtrMeshConfiguration2 &meshConfig);

  virtual ~Participant2();

  /// Returns the name of the participant.
  const std::string &getName() const;

  void addWriteData(
      const PtrData2 &data,
      const PtrMesh2 &mesh);

  void addReadData(
      const PtrData2 &data,
      const PtrMesh2 &mesh);

  const DataContext2 &dataContext(int dataID) const;

  DataContext2 &dataContext(int dataID);

  const utils::ptr_vector<DataContext2> &writeDataContexts() const;

  utils::ptr_vector<DataContext2> &writeDataContexts();

  const utils::ptr_vector<DataContext2> &readDataContexts() const;

  utils::ptr_vector<DataContext2> &readDataContexts();

  bool isMeshUsed(int meshID) const;

  bool isDataUsed(int dataID) const;

  bool isDataRead(int dataID) const;

  bool isDataWrite(int dataID) const;

  const MeshContext2 &meshContext(int meshID) const;

  MeshContext2 &meshContext(int meshID);

  const std::vector<MeshContext2 *> &usedMeshContexts() const;

  std::vector<MeshContext2 *> &usedMeshContexts();

  /** Looks for a used MeshContext for a mesh name.
   * @param[in] name the name of the \ref Mesh
   * @return a pointer to the MeshContext or nullptr if it was not found
   */
  MeshContext2 *usedMeshContextByName(const std::string &name);

  /** Looks for a used MeshContext for a mesh name.
   * @param[in] name the name of the \ref Mesh
   * @return a pointer to the MeshContext or nullptr if it was not found
   */
  MeshContext2 const *usedMeshContextByName(const std::string &name) const;

  void addReadMappingContext(MappingContext2 *mappingContext);

  void addWriteMappingContext(MappingContext2 *mappingContext);

  const utils::ptr_vector<MappingContext2> &readMappingContexts() const;

  const utils::ptr_vector<MappingContext2> &writeMappingContexts() const;

  void addWatchPoint(const PtrWatchPoint &watchPoint);

  std::vector<PtrWatchPoint> &watchPoints();

  /// Adds a mesh to be used by the participant.
  void useMesh(
      const PtrMesh2 &                         mesh,
      const Eigen::VectorXd &                       localOffset,
      bool                                          remote,
      const std::string &                           fromParticipant,
      double                                        safetyFactor,
      bool                                          provideMesh,
      partition::ReceivedPartition::GeometricFilter geoFilter);

  void addAction(const action::PtrAction &action);

  std::vector<action::PtrAction> &actions();

  const std::vector<action::PtrAction> &actions() const;

  /// Adds an export context to export meshes and data.
  void addExportContext(const io::ExportContext &context);

  /// Returns all export contexts for exporting meshes and data.
  const std::vector<io::ExportContext> &exportContexts() const;

  /// Returns true, if the participant uses a master process.
  bool useMaster();

  void setUseMaster(bool useMaster);

  void setMeshIdManager(std::unique_ptr<utils::ManageUniqueIDs> &&idm)
  {
    _meshIdManager = std::move(idm);
  }

private:
  logging::Logger _log{"impl::Participant"};

  std::string _name;

  std::vector<PtrWatchPoint> _watchPoints;

  /// Export contexts to export meshes, data, and more.
  std::vector<io::ExportContext> _exportContexts;

  std::vector<action::PtrAction> _actions;

  /// All mesh contexts involved in a simulation, mesh ID == index.
  std::vector<MeshContext2 *> _meshContexts;

  /// Read mapping contexts used by the participant.
  utils::ptr_vector<MappingContext2> _readMappingContexts;

  /// Write mapping contexts used by the participant.
  utils::ptr_vector<MappingContext2> _writeMappingContexts;

  /// Mesh contexts used by the participant.
  std::vector<MeshContext2 *> _usedMeshContexts;

  std::vector<DataContext2 *> _dataContexts;

  utils::ptr_vector<DataContext2> _writeDataContexts;

  utils::ptr_vector<DataContext2> _readDataContexts;

  //io::ExportContext _exportContext;

  bool _useMaster = false;

  std::unique_ptr<utils::ManageUniqueIDs> _meshIdManager;

  template <typename ELEMENT_T>
  bool isDataValid(
      const std::vector<ELEMENT_T> &data,
      const ELEMENT_T &             newElement) const;

  void checkDuplicatedUse(const PtrMesh2 &mesh);

  void checkDuplicatedData(const PtrData2 &data);

  /// To allow white box tests.
  friend struct PreciceTests::Serial::TestConfigurationPeano;
  friend struct PreciceTests::Serial::TestConfigurationComsol;
};

// --------------------------------------------------------- HEADER DEFINITIONS

template <typename ELEMENT_T>
bool Participant2::isDataValid(
    const std::vector<ELEMENT_T> &data,
    const ELEMENT_T &             newElement) const
{
  for (size_t i = 0; i < data.size(); i++) {
    if (data[i].name == newElement.name) {
      return false;
    }
  }
  return true;
}

} // namespace impl
} // namespace precice
