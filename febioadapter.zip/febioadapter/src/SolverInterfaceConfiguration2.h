#pragma once

#include <string>
#include "SharedPointer.hpp"
#include "boost/smart_ptr.hpp"
#include "cplscheme/SharedPointer.hpp"
#include "logging/Logger.hpp"
#include "m2n/M2N.hpp"
//#include "m2n/config/M2NConfiguration.hpp"
#include "mapping/SharedPointer.hpp"
#include "mesh/SharedPointer.hpp"
#include "precice/impl/Participant.hpp"
#include "precice/impl/SharedPointer.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"
#include "DataConfiguration2.h"
#include "MeshConfiguration2.h"
#include "M2NConfiguration2.h"
#include "ParticipantConfiguration2.h"
#include "CouplingSchemeConfiguration2.h"

namespace precice {
namespace config {

/**
 * @brief Configures class SolverInterfaceImpl from XML.
 */
class SolverInterfaceConfiguration2 : public xml::XMLTag2::Listener {
public:

  using PtrDataConfiguration2 = std::shared_ptr<precice::mesh::DataConfiguration2>;
  using PtrMeshConfiguration2 = std::shared_ptr<precice::mesh::MeshConfiguration2>;
  using PtrParticipantConfiguration2 = std::shared_ptr<precice::config::ParticipantConfiguration2>;
  using PtrCouplingSchemeConfiguration2 = std::shared_ptr<precice::cplscheme::CouplingSchemeConfiguration2>;
    
  SolverInterfaceConfiguration2(xml::XMLTag2 &parent, FEModel *fem);

  FEModel *fem1;

  /**
   * @brief Destructor.
   *
   * Deletes geometry configuration and coupling scheme configuration.
   */
  virtual ~SolverInterfaceConfiguration2() {}

  /**
   * @brief Callback method required when using xml::XMLTag.
   */
  virtual void XMLTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag);

  /**
   * @brief Callback method required when using xml::XMLTag.
   */
  virtual void xmlEndTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag);
  

  /**
   * @brief Returns number of spatial dimensions configured.
   */
   
  int getDimensions() const;

  const PtrDataConfiguration2 getDataConfiguration() const
  {
    return _dataConfiguration;
  }

  const PtrMeshConfiguration2 getMeshConfiguration() const
  {
    return _meshConfiguration;
  }

  const m2n::M2NConfiguration2::SharedPointer2 getM2NConfiguration() const
  {
    return _m2nConfiguration;
  }

  const PtrParticipantConfiguration2 &getParticipantConfiguration() const;

  const PtrCouplingSchemeConfiguration2
  getCouplingSchemeConfiguration() const
  {
    return _couplingSchemeConfiguration;
  }

  /**
   * @brief For manual configuration in test cases.
   */
  void setDataConfiguration(PtrDataConfiguration2 config)
  {
    _dataConfiguration = config;
  }

  /**
   * @brief For manual configuration in test cases.
   */
  void setMeshConfiguration(PtrMeshConfiguration2 config)
  {
    _meshConfiguration = config;
  }
  
  /**
    * @brief For manual configuration in test cases.
    */
  void setParticipantConfiguration(PtrParticipantConfiguration2 config)
  {
    _participantConfiguration = config;
  }

private:
  logging::Logger _log{"config::SolverInterfaceConfiguration2"};

  /// Spatial dimension of problem to be solved. Either 2 or 3.
  int _dimensions = -1;

  // @brief Participating solvers in the coupled simulation.
  //std::vector<impl::PtrParticipant> _participants;

  // @brief Index (in _participants) of solver accessing the interface.
  //int _indexAccessor;

  PtrDataConfiguration2 _dataConfiguration;

  PtrMeshConfiguration2 _meshConfiguration;

  m2n::M2NConfiguration2::SharedPointer2 _m2nConfiguration;

  PtrParticipantConfiguration2 _participantConfiguration;

  PtrCouplingSchemeConfiguration2 _couplingSchemeConfiguration;
};

} // namespace config
} // namespace precice
