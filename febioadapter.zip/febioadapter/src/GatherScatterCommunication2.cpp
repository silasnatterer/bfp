//#include "GatherScatterCommunication.hpp"

#include "GatherScatterCommunication2.h"

#include <algorithm>
#include <map>
#include <memory>
#include <ostream>
//#include "com/Communication.hpp"

#include "Communication2.h"

#include "logging/LogMacros.hpp"
//#include "m2n/DistributedCommunication.hpp"7

#include "DistributedCommunication2.h"

//#include "mesh/Mesh.hpp"
//#include "utils/MasterSlave.hpp"

#include "MasterSlave2.h"

#include "utils/assertion.hpp"

namespace precice {
namespace m2n {
GatherScatterCommunication2::GatherScatterCommunication2(
    PtrCommunication2 com,
    PtrMesh2         mesh)
    : DistributedCommunication2(mesh),
      _com(com),
      _isConnected(false)
{
}

GatherScatterCommunication2::~GatherScatterCommunication2()
{
  if (isConnected()) {
    closeConnection();
  }
}

bool GatherScatterCommunication2::isConnected() const
{
  return _isConnected;
}

void GatherScatterCommunication2::acceptConnection(
    const std::string &acceptorName,
    const std::string &requesterName)
{

    PRECICE_DEBUG("here inside acceptConnection 1.0");
    
  PRECICE_TRACE(acceptorName, requesterName);
  
      PRECICE_DEBUG("here inside acceptConnection 2.0");
      
  PRECICE_ASSERT(utils::MasterSlave2::isSlave() || _com->isConnected());
  
      PRECICE_DEBUG("here inside acceptConnection 3.0");
  
  _isConnected = true;
}

void GatherScatterCommunication2::requestConnection(
    const std::string &acceptorName,
    const std::string &requesterName)
{
  PRECICE_TRACE(acceptorName, requesterName);
  PRECICE_ASSERT(utils::MasterSlave2::isSlave() || _com->isConnected());
  _isConnected = true;
}

void GatherScatterCommunication2::closeConnection()
{
  PRECICE_TRACE();
  PRECICE_ASSERT(utils::MasterSlave2::isSlave() || not _com->isConnected());
  _isConnected = false;
}

void GatherScatterCommunication2::send(
    double const *itemsToSend,
    size_t        size,
    int           valueDimension)
{
  PRECICE_TRACE(size);

  // Gather data
  if (utils::MasterSlave2::isSlave()) { // Slave
    if (size > 0) {
      utils::MasterSlave2::_communication->send(itemsToSend, size, 0);
    }
  } else { // Master or coupling mode
    PRECICE_ASSERT(utils::MasterSlave2::getRank() == 0);
    mesh::Mesh::VertexDistribution &vertexDistribution = _mesh->getVertexDistribution();
    int                             globalSize         = _mesh->getGlobalNumberOfVertices() * valueDimension;
    PRECICE_DEBUG("Global Size = " << globalSize);
    std::vector<double> globalItemsToSend(globalSize);

    // Master data
    for (size_t i = 0; i < vertexDistribution[0].size(); i++) {
      for (int j = 0; j < valueDimension; j++) {
        globalItemsToSend[vertexDistribution[0][i] * valueDimension + j] += itemsToSend[i * valueDimension + j];
      }
    }

    // Slaves data
    for (int rankSlave = 1; rankSlave < utils::MasterSlave2::getSize(); rankSlave++) {
      PRECICE_ASSERT(utils::MasterSlave2::_communication.get() != nullptr);
      PRECICE_ASSERT(utils::MasterSlave2::_communication->isConnected());

      int slaveSize = vertexDistribution[rankSlave].size() * valueDimension;
      PRECICE_DEBUG("Slave Size = " << slaveSize);
      if (slaveSize > 0) {
        std::vector<double> valuesSlave(slaveSize);
        utils::MasterSlave2::_communication->receive(valuesSlave.data(), slaveSize, rankSlave);
        for (size_t i = 0; i < vertexDistribution[rankSlave].size(); i++) {
          for (int j = 0; j < valueDimension; j++) {
            globalItemsToSend[vertexDistribution[rankSlave][i] * valueDimension + j] += valuesSlave[i * valueDimension + j];
          }
        }
      }
    }

    // Send data to other master
    _com->send(globalItemsToSend.data(), globalSize, 0);
  }
}

void GatherScatterCommunication2::receive(
    double *itemsToReceive,
    size_t  size,
    int     valueDimension)
{
  PRECICE_TRACE(size);

  std::vector<double> globalItemsToReceive;

  // Receive data at master
  if (not utils::MasterSlave2::isSlave()) {
    int globalSize = _mesh->getGlobalNumberOfVertices() * valueDimension;
    PRECICE_DEBUG("Global Size = " << globalSize);
    globalItemsToReceive.resize(globalSize);
    _com->receive(globalItemsToReceive.data(), globalSize, 0);
  }

  // Scatter data
  if (utils::MasterSlave2::isSlave()) { // Slave
    if (size > 0) {
      PRECICE_DEBUG("itemsToRec[0] = " << itemsToReceive[0]);
      utils::MasterSlave2::_communication->receive(itemsToReceive, size, 0);
      PRECICE_DEBUG("itemsToRec[0] = " << itemsToReceive[0]);
    }
  } else { // Master or coupling mode
    PRECICE_ASSERT(utils::MasterSlave2::getRank() == 0);
    mesh::Mesh::VertexDistribution &vertexDistribution = _mesh->getVertexDistribution();

    // Master data
    for (size_t i = 0; i < vertexDistribution[0].size(); i++) {
      for (int j = 0; j < valueDimension; j++) {
        itemsToReceive[i * valueDimension + j] = globalItemsToReceive[vertexDistribution[0][i] * valueDimension + j];
      }
    }

    // Slaves data
    for (int rankSlave = 1; rankSlave < utils::MasterSlave2::getSize(); rankSlave++) {
      PRECICE_ASSERT(utils::MasterSlave2::_communication.get() != nullptr);
      PRECICE_ASSERT(utils::MasterSlave2::_communication->isConnected());

      int slaveSize = vertexDistribution[rankSlave].size() * valueDimension;
      PRECICE_DEBUG("Slave Size = " << slaveSize);
      if (slaveSize > 0) {
        std::vector<double> valuesSlave(slaveSize);
        for (size_t i = 0; i < vertexDistribution[rankSlave].size(); i++) {
          for (int j = 0; j < valueDimension; j++) {
            valuesSlave[i * valueDimension + j] = globalItemsToReceive[vertexDistribution[rankSlave][i] * valueDimension + j];
          }
        }
        utils::MasterSlave2::_communication->send(valuesSlave.data(), slaveSize, rankSlave);
        PRECICE_DEBUG("valuesSlave[0] = " << valuesSlave[0]);
      }
    }
  } // Master
}

void GatherScatterCommunication2::acceptPreConnection(
    std::string const &acceptorName,
    std::string const &requesterName)
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::requestPreConnection(
    std::string const &acceptorName,
    std::string const &requesterName)
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::broadcastSend(const int &itemToSend)
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::broadcastReceiveAll(std::vector<int> &itemToReceive)
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::broadcastSendMesh()
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::broadcastReceiveAllMesh()
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::scatterAllCommunicationMap(CommunicationMap &localCommunicationMap)
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::gatherAllCommunicationMap(CommunicationMap &localCommunicationMap)
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

void GatherScatterCommunication2::completeSlavesConnection()
{
  PRECICE_ASSERT(false, "Not available for GatherScatterCommunication.");
}

} // namespace m2n
} // namespace precice
