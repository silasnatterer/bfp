#include "CouplingSchemeConfiguration2.h"

#include <algorithm>
#include <list>
#include <memory>
#include <ostream>
#include <stddef.h>
#include <stdexcept>
#include <utility>
#include "acceleration/Acceleration.hpp"
//#include "acceleration/config/AccelerationConfiguration.hpp"

#include "AccelerationConfiguration2.h"

//#include "cplscheme/BaseCouplingScheme.hpp"

#include "BaseCouplingScheme2.h"

//#include "cplscheme/BiCouplingScheme.hpp"

#include "BiCouplingScheme2.h"

//#include "cplscheme/CompositionalCouplingScheme.hpp"

#include "CompositionalCouplingScheme2.h"

#include "cplscheme/MultiCouplingScheme.hpp"
#include "cplscheme/ParallelCouplingScheme.hpp"
//#include "cplscheme/SerialCouplingScheme.hpp"

#include "SerialCouplingScheme2.h"

#include "cplscheme/SharedPointer.hpp"
#include "cplscheme/impl/AbsoluteConvergenceMeasure.hpp"
#include "cplscheme/impl/MinIterationConvergenceMeasure.hpp"
//#include "cplscheme/impl/RelativeConvergenceMeasure.hpp"
#include "cplscheme/impl/ResidualRelativeConvergenceMeasure.hpp"
#include "logging/LogMacros.hpp"
#include "m2n/SharedPointer.hpp"
//#include "m2n/config/M2NConfiguration.hpp"

#include "M2NConfiguration2.h"

//#include "mesh/Data.hpp"
#include "Data2.h"

//#include "mesh/Mesh.hpp"

#include "Mesh2.h"

//#include "mesh/config/MeshConfiguration.hpp"

#include "MeshConfiguration2.h"

#include "precice/impl/SharedPointer.hpp"
#include "utils/Helpers.hpp"
#include "utils/assertion.hpp"
//#include "xml/ConfigParser.hpp"

#include "ConfigParser2.h"

#include "xml/XMLAttribute.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"
#include "easylogging++.h"

#include "M2N2.h"

namespace precice {
namespace cplscheme {

  using PtrData2 = std::shared_ptr<precice::mesh::Data2>;
  using PtrM2N2 = std::shared_ptr<precice::m2n::M2N2>;

CouplingSchemeConfiguration2::CouplingSchemeConfiguration2(
    xml::XMLTag2 &                               parent,
    const PtrMeshConfiguration2 &          meshConfig,
    const m2n::M2NConfiguration2::SharedPointer2 &m2nConfig, 
    FEModel *fem)
    : TAG("coupling-scheme"),
      TAG_PARTICIPANTS("participants"),
      TAG_PARTICIPANT("participant"),
      TAG_EXCHANGE("exchange"),
      TAG_MAX_TIME("max-time"),
      TAG_MAX_TIME_WINDOWS("max-time-windows"),
      TAG_TIME_WINDOW_SIZE("time-window-size"),
      TAG_ABS_CONV_MEASURE("absolute-convergence-measure"),
      TAG_REL_CONV_MEASURE("relative-convergence-measure"),
      TAG_RES_REL_CONV_MEASURE("residual-relative-convergence-measure"),
      TAG_MIN_ITER_CONV_MEASURE("min-iteration-convergence-measure"),
      TAG_MAX_ITERATIONS("max-iterations"),
      TAG_EXTRAPOLATION("extrapolation-order"),
      ATTR_DATA("data"),
      ATTR_MESH("mesh"),
      ATTR_PARTICIPANT("participant"),
      ATTR_INITIALIZE("initialize"),
      ATTR_TYPE("type"),
      ATTR_FIRST("first"),
      ATTR_SECOND("second"),
      ATTR_VALUE("value"),
      ATTR_VALID_DIGITS("valid-digits"),
      ATTR_METHOD("method"),
      ATTR_LIMIT("limit"),
      ATTR_MIN_ITERATIONS("min-iterations"),
      ATTR_NAME("name"),
      ATTR_FROM("from"),
      ATTR_TO("to"),
      ATTR_SUFFICES("suffices"),
      ATTR_STRICT("strict"),
      ATTR_CONTROL("control"),
      VALUE_SERIAL_EXPLICIT("serial-explicit"),
      VALUE_PARALLEL_EXPLICIT("parallel-explicit"),
      VALUE_SERIAL_IMPLICIT("serial-implicit"),
      VALUE_PARALLEL_IMPLICIT("parallel-implicit"),
      VALUE_MULTI("multi"),
      VALUE_FIXED("fixed"),
      VALUE_FIRST_PARTICIPANT("first-participant"),
      _config(),
      _meshConfig(meshConfig),
      _m2nConfig(m2nConfig),
      _couplingSchemes(),
      _couplingSchemeCompositions()
{
  using namespace xml;

  fem1 = fem;
  
  XMLTag2::Occurrence occ = XMLTag2::OCCUR_ARBITRARY;
  std::list<XMLTag2>  tags;
  std::string        doc;

  {
    XMLTag2 tag(*this, VALUE_SERIAL_EXPLICIT, occ, TAG, fem1);
    doc = "Explicit coupling scheme according to conventional serial";
    doc += " staggered procedure (CSS).";
    tag.setDocumentation(doc);
    addTypespecifcSubtags(VALUE_SERIAL_EXPLICIT, tag);
    tags.push_back(tag);
  }/*
  {
    XMLTag2 tag(*this, VALUE_PARALLEL_EXPLICIT, occ, TAG);
    doc = "Explicit coupling scheme according to conventional parallel";
    doc += " staggered procedure (CPS).";
    tag.setDocumentation(doc);
    addTypespecifcSubtags(VALUE_PARALLEL_EXPLICIT, tag);
    tags.push_back(tag);
  }
  {
    XMLTag2 tag(*this, VALUE_SERIAL_IMPLICIT, occ, TAG);
    doc = "Implicit coupling scheme according to block Gauss-Seidel iterations (S-System).";
    doc += " Improved implicit iterations are achieved by using a acceleration (recommended!).";
    tag.setDocumentation(doc);
    addTypespecifcSubtags(VALUE_SERIAL_IMPLICIT, tag);
    tags.push_back(tag);
  }
  {
    XMLTag2 tag(*this, VALUE_PARALLEL_IMPLICIT, occ, TAG);
    doc = "Parallel Implicit coupling scheme according to block Jacobi iterations (V-System).";
    doc += " Improved implicit iterations are achieved by using a acceleration (recommended!).";
    tag.setDocumentation(doc);
    addTypespecifcSubtags(VALUE_PARALLEL_IMPLICIT, tag);
    tags.push_back(tag);
  }
  {
    XMLTag2 tag(*this, VALUE_MULTI, occ, TAG);
    doc = "Multi coupling scheme according to block Jacobi iterations.";
    doc += " Improved implicit iterations are achieved by using a acceleration (recommended!).";
    tag.setDocumentation(doc);
    addTypespecifcSubtags(VALUE_MULTI, tag);
    tags.push_back(tag);
  }
  */
  for (XMLTag2 &tag : tags) {
    parent.addSubtag(tag);
  }
}

CouplingSchemeConfiguration2::~CouplingSchemeConfiguration2()
{
}

bool CouplingSchemeConfiguration2::hasCouplingScheme(
    const std::string &participantName) const
{
  return utils::contained(participantName, _couplingSchemes);
}

const PtrCouplingScheme &CouplingSchemeConfiguration2::getCouplingScheme(
    const std::string &participantName) const
{
  PRECICE_CHECK(utils::contained(participantName, _couplingSchemes),
                "No coupling scheme defined for "
                    << "participant \"" << participantName << "\". "
                    << "Please make sure to provide at least one <coupling-scheme:TYPE> in your "
                    << "precice-config.xml that couples this participant using the <participants .../> tag.");
  return _couplingSchemes.find(participantName)->second;
}

void CouplingSchemeConfiguration2::XMLTagCallback(
    const xml::ConfigurationContext2 &context,
    xml::XMLTag2 &                    tag)
{
  PRECICE_TRACE(tag.getFullName());
  if (tag.getNamespace() == TAG) {
    _config.type = tag.getName();
   // _accelerationConfig->clear();
  } else if (tag.getName() == TAG_PARTICIPANTS) { 
    std::string first = tag.getStringAttributeValue(ATTR_FIRST);
    _config.participants.push_back(first);
    std::string second = tag.getStringAttributeValue(ATTR_SECOND);
    PRECICE_CHECK(std::find(_config.participants.begin(), _config.participants.end(), second) == _config.participants.end(),
                  "Provided first participant equals second participant in coupling scheme. Please correct the <participants "
                      << "first=\"" << first << "\" "
                      << "second=\"" << second << "\" "
                      << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
    _config.participants.push_back(second);
  } else if (tag.getName() == TAG_PARTICIPANT) {
    PRECICE_ASSERT(_config.type == VALUE_MULTI);
    bool        control         = tag.getBooleanAttributeValue(ATTR_CONTROL);
    std::string participantName = tag.getStringAttributeValue(ATTR_NAME);
    PRECICE_CHECK(std::find(_config.participants.begin(), _config.participants.end(), participantName) == _config.participants.end() && participantName.compare(_config.controller) != 0,
                  "Participant \""
                      << participantName
                      << "\" is provided multiple times to multi coupling scheme. Please make sure that you do not provide the participant multiple times via the <participant name=\""
                      << participantName
                      << "\" /> tag in the <coupling-scheme:...> of your precice-config.xml");
    if (control) {
      PRECICE_CHECK(not _config.setController,
                    "Only one controller per MultiCouplingScheme can be defined. Please check the <participant "
                        << "name=\"" << participantName << "\" "
                        << "control=\"" << control << "\" "
                        << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
      _config.controller    = participantName;
      _config.setController = true;
    } else {
      _config.participants.push_back(participantName);
    }

  } else if (tag.getName() == TAG_MAX_TIME) {
    _config.maxTime = tag.getDoubleAttributeValue(ATTR_VALUE);
    PRECICE_CHECK(_config.maxTime > 0, "Maximum time has to be larger than zero. Please check the <max-time "
                                           << "value=\"" << _config.maxTime << "\" "
                                           << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
  } else if (tag.getName() == TAG_MAX_TIME_WINDOWS) {
    _config.maxTimeWindows = tag.getIntAttributeValue(ATTR_VALUE);
    PRECICE_CHECK(_config.maxTimeWindows > 0, "Maximum number of time windows has to be larger than zero. Please check the <max-time-windows "
                                                  << "value=\"" << _config.maxTimeWindows << "\" "
                                                  << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
  } else if (tag.getName() == TAG_TIME_WINDOW_SIZE) {
    _config.timeWindowSize = tag.getDoubleAttributeValue(ATTR_VALUE);
    _config.validDigits    = tag.getIntAttributeValue(ATTR_VALID_DIGITS);
    PRECICE_CHECK((_config.validDigits >= 1) && (_config.validDigits < 17), "Valid digits of time window size has to be between 1 and 16.");
    _config.dtMethod = getTimesteppingMethod(tag.getStringAttributeValue(ATTR_METHOD));
    if (_config.dtMethod == constants::TimesteppingMethod::FIXED_TIME_WINDOW_SIZE) {
      PRECICE_CHECK(_config.timeWindowSize > 0, "Time window size has to be larger than zero. Please check the <time-window-size "
                                                    << "value=\"" << _config.timeWindowSize << "\" "
                                                    << "valid-digits=\"" << _config.validDigits << "\" "
                                                    << "method=\"" << tag.getStringAttributeValue(ATTR_METHOD) << "\" "
                                                    << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
    } else {
      PRECICE_ASSERT(_config.dtMethod == constants::TimesteppingMethod::FIRST_PARTICIPANT_SETS_TIME_WINDOW_SIZE);
      PRECICE_CHECK(_config.timeWindowSize == -1, "Time window size value has to be equal to -1 (default), if method=\"first-participant\" is used. Please check the <time-window-size "
                                                      << "value=\"" << _config.timeWindowSize << "\" "
                                                      << "valid-digits=\"" << _config.validDigits << "\" "
                                                      << "method=\"" << tag.getStringAttributeValue(ATTR_METHOD) << "\" "
                                                      << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
    }
    PRECICE_CHECK((_config.validDigits >= 1) && (_config.validDigits < 17), "Valid digits of time window size has to be between 1 and 16. Please check the <time-window-size "
                                                                                << "value=\"" << _config.timeWindowSize << "\" "
                                                                                << "valid-digits=\"" << _config.validDigits << "\" "
                                                                                << "method=\"" << tag.getStringAttributeValue(ATTR_METHOD) << "\" "
                                                                                << "/> tag in the <coupling-scheme:...> of your precice-config.xml");
  } else if (tag.getName() == TAG_ABS_CONV_MEASURE) {
    std::string dataName = tag.getStringAttributeValue(ATTR_DATA);
    std::string meshName = tag.getStringAttributeValue(ATTR_MESH);
    double      limit    = tag.getDoubleAttributeValue(ATTR_LIMIT);
    bool        suffices = tag.getBooleanAttributeValue(ATTR_SUFFICES);
    bool        strict   = tag.getBooleanAttributeValue(ATTR_STRICT);
    PRECICE_ASSERT(_config.type == VALUE_SERIAL_IMPLICIT || _config.type == VALUE_PARALLEL_IMPLICIT || _config.type == VALUE_MULTI);
    addAbsoluteConvergenceMeasure(dataName, meshName, limit, suffices, strict);
  }/* else if (tag.getName() == TAG_REL_CONV_MEASURE) {
    std::string dataName = tag.getStringAttributeValue(ATTR_DATA);
    std::string meshName = tag.getStringAttributeValue(ATTR_MESH);
    double      limit    = tag.getDoubleAttributeValue(ATTR_LIMIT);
    bool        suffices = tag.getBooleanAttributeValue(ATTR_SUFFICES);
    bool        strict   = tag.getBooleanAttributeValue(ATTR_STRICT);
    PRECICE_ASSERT(_config.type == VALUE_SERIAL_IMPLICIT || _config.type == VALUE_PARALLEL_IMPLICIT || _config.type == VALUE_MULTI);
    addRelativeConvergenceMeasure(dataName, meshName, limit, suffices, strict);
  } */else if (tag.getName() == TAG_RES_REL_CONV_MEASURE) {
    std::string dataName = tag.getStringAttributeValue(ATTR_DATA);
    std::string meshName = tag.getStringAttributeValue(ATTR_MESH);
    double      limit    = tag.getDoubleAttributeValue(ATTR_LIMIT);
    bool        suffices = tag.getBooleanAttributeValue(ATTR_SUFFICES);
    bool        strict   = tag.getBooleanAttributeValue(ATTR_STRICT);
    PRECICE_ASSERT(_config.type == VALUE_SERIAL_IMPLICIT || _config.type == VALUE_PARALLEL_IMPLICIT || _config.type == VALUE_MULTI);
    addResidualRelativeConvergenceMeasure(dataName, meshName, limit, suffices, strict);
  } else if (tag.getName() == TAG_MIN_ITER_CONV_MEASURE) {
    std::string dataName      = tag.getStringAttributeValue(ATTR_DATA);
    std::string meshName      = tag.getStringAttributeValue(ATTR_MESH);
    int         minIterations = tag.getIntAttributeValue(ATTR_MIN_ITERATIONS);
    bool        suffices      = tag.getBooleanAttributeValue(ATTR_SUFFICES);
    bool        strict        = tag.getBooleanAttributeValue(ATTR_STRICT);
    PRECICE_ASSERT(_config.type == VALUE_SERIAL_IMPLICIT || _config.type == VALUE_PARALLEL_IMPLICIT || _config.type == VALUE_MULTI);
    addMinIterationConvergenceMeasure(dataName, meshName, minIterations, suffices, strict);
  } else if (tag.getName() == TAG_EXCHANGE) {
  
      write_log(fem1, 3,"cplscheme exchange");
      
    std::string   nameData            = tag.getStringAttributeValue(ATTR_DATA);
    std::string   nameMesh            = tag.getStringAttributeValue(ATTR_MESH);
    std::string   nameParticipantFrom = tag.getStringAttributeValue(ATTR_FROM);
    std::string   nameParticipantTo   = tag.getStringAttributeValue(ATTR_TO);
    bool          initialize          = tag.getBooleanAttributeValue(ATTR_INITIALIZE);
    PtrData2 exchangeData;
    PtrMesh2 exchangeMesh;
    for (PtrMesh2 mesh : _meshConfig->meshes()) {
      if (mesh->getName() == nameMesh) {
        for (PtrData2 data : mesh->data()) {
          if (data->getName() == nameData) {
            exchangeData = data;
            exchangeMesh = mesh;
            break;
          }
        }
      }
    }
    PRECICE_CHECK(exchangeData.get(), "Mesh \"" << nameMesh << "\" with data \"" << nameData
                                                << "\" not defined. Please check the <exchange "
                                                << "data=\"" << nameData << "\" "
                                                << "mesh=\"" << nameMesh << "\" "
                                                << "from=\"" << nameParticipantFrom << "\" "
                                                << "to=\"" << nameParticipantTo << "\" "
                                                << "/> tag in the <coupling-scheme:... /> of your precice-config.xml.");
    _meshConfig->addNeededMesh(nameParticipantFrom, nameMesh);
    _meshConfig->addNeededMesh(nameParticipantTo, nameMesh);
    _config.exchanges.push_back(std::make_tuple(exchangeData, exchangeMesh,
                                                nameParticipantFrom, nameParticipantTo, initialize));
  } else if (tag.getName() == TAG_MAX_ITERATIONS) {
    PRECICE_ASSERT(_config.type == VALUE_SERIAL_IMPLICIT || _config.type == VALUE_PARALLEL_IMPLICIT || _config.type == VALUE_MULTI);
    _config.maxIterations = tag.getIntAttributeValue(ATTR_VALUE);
    PRECICE_CHECK(_config.maxIterations > 0,
                  "Maximal iteration limit has to be larger than zero. Please check the <max-iterations "
                      << "value = \"" << _config.maxIterations << "\" /> subtag in the <coupling-scheme:... /> of your precice-config.xml.");
  } else if (tag.getName() == TAG_EXTRAPOLATION) {
    PRECICE_ASSERT(_config.type == VALUE_SERIAL_IMPLICIT || _config.type == VALUE_PARALLEL_IMPLICIT || _config.type == VALUE_MULTI);
    _config.extrapolationOrder = tag.getIntAttributeValue(ATTR_VALUE);
    PRECICE_CHECK((_config.extrapolationOrder == 0) || (_config.extrapolationOrder == 1) || (_config.extrapolationOrder == 2),
                  "Extrapolation order has to be  0, 1, or 2. Please check the <extrapolation-order "
                      << "value=\"" << _config.extrapolationOrder << "\" "
                      << "/> subtag in the <coupling-scheme:... /> of your precice-config.xml.");
  }
}

void CouplingSchemeConfiguration2::xmlEndTagCallback(
    const xml::ConfigurationContext2 &context,
    xml::XMLTag2 &                    tag)
{
  PRECICE_TRACE(tag.getFullName());
  if (tag.getNamespace() == TAG) {
    if (_config.type == VALUE_SERIAL_EXPLICIT) {
      std::string       accessor(_config.participants[0]);
      PtrCouplingScheme scheme = createSerialExplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      //_couplingSchemes[accessor] = scheme;
      accessor = _config.participants[1];
      scheme   = createSerialExplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      //_couplingSchemes[accessor] = scheme;
      _config = Config();
    } /*else if (_config.type == VALUE_PARALLEL_EXPLICIT) {
      std::string       accessor(_config.participants[0]);
      PtrCouplingScheme scheme = createParallelExplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      //_couplingSchemes[accessor] = scheme;
      accessor = _config.participants[1];
      scheme   = createParallelExplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      //_couplingSchemes[accessor] = scheme;
      _config = Config();
    } else if (_config.type == VALUE_SERIAL_IMPLICIT) {
      std::string       accessor(_config.participants[0]);
      PtrCouplingScheme scheme = createSerialImplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      //_couplingSchemes[accessor] = scheme;
      accessor = _config.participants[1];
      scheme   = createSerialImplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      //_couplingSchemes[accessor] = scheme;
      _config = Config();
    } else if (_config.type == VALUE_PARALLEL_IMPLICIT) {
      std::string       accessor(_config.participants[0]);
      PtrCouplingScheme scheme = createParallelImplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      accessor = _config.participants[1];
      scheme   = createParallelImplicitCouplingScheme(accessor);
      addCouplingScheme(scheme, accessor);
      _config = Config();
    } else if (_config.type == VALUE_MULTI) {
      PRECICE_CHECK(_config.setController,
                    "One controller per MultiCoupling needs to be defined. "
                    "Please check the <participant name=... /> tags in the <coupling-scheme:... /> of your precice-config.xml. "
                    "Make sure that at least one participant tag provides the attribute <participant name=... control=\"True\"/>.");
      for (std::string &accessor : _config.participants) {
        PtrCouplingScheme scheme = createMultiCouplingScheme(accessor);
        addCouplingScheme(scheme, accessor);
      }
      PtrCouplingScheme scheme = createMultiCouplingScheme(_config.controller);
      addCouplingScheme(scheme, _config.controller);
      _config = Config();
    } else {
      PRECICE_ASSERT(false, _config.type);
    }*/
  }
}

void CouplingSchemeConfiguration2::addCouplingScheme(
    PtrCouplingScheme  cplScheme,
    const std::string &participantName)
{
  PRECICE_TRACE(participantName);
  if (utils::contained(participantName, _couplingSchemes)) {
    PRECICE_DEBUG("Coupling scheme exists already for participant");
    if (utils::contained(participantName, _couplingSchemeCompositions)) {
      PRECICE_DEBUG("Coupling scheme composition exists already for participant");
      // Fetch the composition and add the new scheme.
      PRECICE_ASSERT(_couplingSchemeCompositions[participantName] != nullptr);
      _couplingSchemeCompositions[participantName]->addCouplingScheme(cplScheme);
    } else {
      PRECICE_DEBUG("No composition exists for the participant");
      // No composition exists, thus, the existing scheme is no composition.
      // Create a new composition, add the already existing and new scheme, and
      // overwrite the existing scheme with the composition.
      CompositionalCouplingScheme2 *composition = new CompositionalCouplingScheme2();
      PRECICE_CHECK(nullptr == dynamic_cast<MultiCouplingScheme *>(_couplingSchemes[participantName].get()), "A Multi Coupling Scheme cannot yet be combined with any other coupling scheme. Try to include all participants within one multi coupling scheme instead.");
      composition->addCouplingScheme(_couplingSchemes[participantName]);
      composition->addCouplingScheme(cplScheme);
      _couplingSchemes[participantName] = PtrCouplingScheme(composition);
    }
  } else {
    PRECICE_DEBUG("No coupling scheme exists for the participant");
    // Store the new coupling scheme.
    _couplingSchemes[participantName] = cplScheme;
  }
}

void CouplingSchemeConfiguration2::addTypespecifcSubtags(
    const std::string &type,
    //const std::string& name,
    xml::XMLTag2 &tag)
{
  PRECICE_TRACE(type);
  addTransientLimitTags(type, tag);
  _config.type = type;
  //_config.name = name;

  if (type == VALUE_SERIAL_EXPLICIT) {
    addTagParticipants(tag);
    addTagExchange(tag);
  } /*else if (type == VALUE_PARALLEL_EXPLICIT) {
    addTagParticipants(tag);
    addTagExchange(tag);
  } else if (type == VALUE_PARALLEL_IMPLICIT) {
    addTagParticipants(tag);
    addTagExchange(tag);
    addTagAcceleration(tag);
    addTagAbsoluteConvergenceMeasure(tag);
    addTagRelativeConvergenceMeasure(tag);
    addTagResidualRelativeConvergenceMeasure(tag);
    addTagMinIterationConvergenceMeasure(tag);
    addTagMaxIterations(tag);
    addTagExtrapolation(tag);
  } else if (type == VALUE_MULTI) {
    addTagParticipant(tag);
    addTagExchange(tag);
    addTagAcceleration(tag);
    addTagAbsoluteConvergenceMeasure(tag);
    addTagRelativeConvergenceMeasure(tag);
    addTagResidualRelativeConvergenceMeasure(tag);
    addTagMinIterationConvergenceMeasure(tag);
    addTagMaxIterations(tag);
    addTagExtrapolation(tag);
  } else if (type == VALUE_SERIAL_IMPLICIT) {
    addTagParticipants(tag);
    addTagExchange(tag);
    addTagAcceleration(tag);
    addTagAbsoluteConvergenceMeasure(tag);
    addTagRelativeConvergenceMeasure(tag);
    addTagResidualRelativeConvergenceMeasure(tag);
    addTagMinIterationConvergenceMeasure(tag);
    addTagMaxIterations(tag);
    addTagExtrapolation(tag);
  } else {
    // If wrong coupling scheme type is provided, this is already caught by the config parser. If the assertion below is triggered, it's a bug in preCICE, not wrong usage.
    PRECICE_ASSERT(false, "Unknown coupling scheme.");
  }*/
}

void CouplingSchemeConfiguration2::addTransientLimitTags(
    const std::string &type,
    xml::XMLTag2 &      tag)
{
  using namespace xml;
  XMLTag2               tagMaxTime(*this, TAG_MAX_TIME, XMLTag2::OCCUR_NOT_OR_ONCE, "", fem1);
  XMLAttribute<double> attrValueMaxTime(ATTR_VALUE);
  tagMaxTime.addAttribute(attrValueMaxTime);
  tag.addSubtag(tagMaxTime);

  XMLTag2            tagMaxTimeWindows(*this, TAG_MAX_TIME_WINDOWS, XMLTag2::OCCUR_NOT_OR_ONCE, "", fem1);
  XMLAttribute<int> attrValueMaxTimeWindows(ATTR_VALUE);
  tagMaxTimeWindows.addAttribute(attrValueMaxTimeWindows);
  tag.addSubtag(tagMaxTimeWindows);

  XMLTag2 tagTimeWindowSize(*this, TAG_TIME_WINDOW_SIZE, XMLTag2::OCCUR_ONCE, "", fem1);
  auto   attrValueTimeWindowSize = makeXMLAttribute(ATTR_VALUE, CouplingScheme::UNDEFINED_TIME_WINDOW_SIZE);
  tagTimeWindowSize.addAttribute(attrValueTimeWindowSize);
  XMLAttribute<int> attrValidDigits(ATTR_VALID_DIGITS, 10);
  tagTimeWindowSize.addAttribute(attrValidDigits);
  std::vector<std::string> allowedMethods;
  if (type == VALUE_SERIAL_EXPLICIT || type == VALUE_SERIAL_IMPLICIT) {
    // method="first-participant" is only allowed for serial coupling schemes
    allowedMethods = {VALUE_FIXED, VALUE_FIRST_PARTICIPANT};
  } else {
    allowedMethods = {VALUE_FIXED};
  }
  auto attrMethod = makeXMLAttribute(ATTR_METHOD, VALUE_FIXED).setOptions(allowedMethods);
  tagTimeWindowSize.addAttribute(attrMethod);
  tag.addSubtag(tagTimeWindowSize);
}

void CouplingSchemeConfiguration2::addTagParticipants(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2                    tagParticipants(*this, TAG_PARTICIPANTS, XMLTag2::OCCUR_ONCE, "", fem1);
  XMLAttribute<std::string> attrFirst(ATTR_FIRST);
  tagParticipants.addAttribute(attrFirst);
  XMLAttribute<std::string> attrSecond(ATTR_SECOND);
  tagParticipants.addAttribute(attrSecond);
  tag.addSubtag(tagParticipants);
}

void CouplingSchemeConfiguration2::addTagParticipant(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2                    tagParticipant(*this, TAG_PARTICIPANT, XMLTag2::OCCUR_ONCE_OR_MORE, "", fem1);
  XMLAttribute<std::string> attrName(ATTR_NAME);
  tagParticipant.addAttribute(attrName);
  XMLAttribute<bool> attrControl(ATTR_CONTROL, false);
  tagParticipant.addAttribute(attrControl);
  tag.addSubtag(tagParticipant);
}

void CouplingSchemeConfiguration2::addTagExchange(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2                    tagExchange(*this, TAG_EXCHANGE, XMLTag2::OCCUR_ONCE_OR_MORE, "", fem1);
  XMLAttribute<std::string> attrData(ATTR_DATA);
  tagExchange.addAttribute(attrData);
  XMLAttribute<std::string> attrMesh(ATTR_MESH);
  tagExchange.addAttribute(attrMesh);
  XMLAttribute<std::string> participantFrom(ATTR_FROM);
  tagExchange.addAttribute(participantFrom);
  XMLAttribute<std::string> participantTo(ATTR_TO);
  tagExchange.addAttribute(participantTo);
  XMLAttribute<bool> attrInitialize(ATTR_INITIALIZE, false);
  tagExchange.addAttribute(attrInitialize);
  tag.addSubtag(tagExchange);
}
/*
void CouplingSchemeConfiguration2::addTagAbsoluteConvergenceMeasure(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2 tagConvergenceMeasure(*this, TAG_ABS_CONV_MEASURE, XMLTag2::OCCUR_ARBITRARY);
  addBaseAttributesTagConvergenceMeasure(tagConvergenceMeasure);
  XMLAttribute<double> attrLimit(ATTR_LIMIT);
  tagConvergenceMeasure.addAttribute(attrLimit);
  tag.addSubtag(tagConvergenceMeasure);
}

void CouplingSchemeConfiguration2::addTagResidualRelativeConvergenceMeasure(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2 tagConvergenceMeasure(*this, TAG_RES_REL_CONV_MEASURE,
                               XMLTag2::OCCUR_ARBITRARY);
  addBaseAttributesTagConvergenceMeasure(tagConvergenceMeasure);
  XMLAttribute<double> attrLimit(ATTR_LIMIT);
  tagConvergenceMeasure.addAttribute(attrLimit);
  tag.addSubtag(tagConvergenceMeasure);
}

void CouplingSchemeConfiguration2::addTagRelativeConvergenceMeasure(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2 tagConvergenceMeasure(*this, TAG_REL_CONV_MEASURE, XMLTag2::OCCUR_ARBITRARY);
  addBaseAttributesTagConvergenceMeasure(tagConvergenceMeasure);
  XMLAttribute<double> attrLimit(ATTR_LIMIT);
  tagConvergenceMeasure.addAttribute(attrLimit);
  tag.addSubtag(tagConvergenceMeasure);
}

void CouplingSchemeConfiguration2::addTagMinIterationConvergenceMeasure(
    xml::XMLTag2 &tag)
{
  xml::XMLTag2 tagMinIterationConvMeasure(*this,
                                         TAG_MIN_ITER_CONV_MEASURE, xml::XMLTag2::OCCUR_ARBITRARY);
  addBaseAttributesTagConvergenceMeasure(tagMinIterationConvMeasure);
  xml::XMLAttribute<int> attrMinIterations(ATTR_MIN_ITERATIONS);
  tagMinIterationConvMeasure.addAttribute(attrMinIterations);
  tag.addSubtag(tagMinIterationConvMeasure);
}

void CouplingSchemeConfiguration2::addBaseAttributesTagConvergenceMeasure(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  auto attrData = XMLAttribute<std::string>(ATTR_DATA)
                      .setDocumentation("Data to be measured.");
  tag.addAttribute(attrData);
  auto attrMesh = XMLAttribute<std::string>(ATTR_MESH)
                      .setDocumentation("Mesh holding the data.");
  tag.addAttribute(attrMesh);
  auto attrSuffices = makeXMLAttribute(ATTR_SUFFICES, false)
                          .setDocumentation("If true, convergence of this measure is sufficient for overall convergence.");
  tag.addAttribute(attrSuffices);
  auto attrStrict = makeXMLAttribute(ATTR_STRICT, false)
                        .setDocumentation("If true, non-convergence of this measure ends the simulation. \"strict\" overrules \"suffices\".");
  tag.addAttribute(attrStrict);
}

void CouplingSchemeConfiguration2::addTagMaxIterations(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2            tagMaxIterations(*this, TAG_MAX_ITERATIONS, XMLTag2::OCCUR_NOT_OR_ONCE);
  XMLAttribute<int> attrValue(ATTR_VALUE);
  tagMaxIterations.addAttribute(attrValue);
  tag.addSubtag(tagMaxIterations);
}

void CouplingSchemeConfiguration2::addTagExtrapolation(
    xml::XMLTag2 &tag)
{
  using namespace xml;
  XMLTag2            tagExtrapolation(*this, TAG_EXTRAPOLATION, XMLTag2::OCCUR_NOT_OR_ONCE);
  XMLAttribute<int> attrValue(ATTR_VALUE);
  tagExtrapolation.addAttribute(attrValue);
  tagExtrapolation.setDocumentation("Sets order of predictor of interface values for first participant.");
  tag.addSubtag(tagExtrapolation);
}

void CouplingSchemeConfiguration2::addTagAcceleration(
    xml::XMLTag2 &tag)
{

  LOG(INFO) << "inner1.2.1";

  PRECICE_TRACE(tag.getFullName());
  if (_accelerationConfig.get() == nullptr) {
    _accelerationConfig = PtrAccelerationConfiguration2(
        new acceleration::AccelerationConfiguration2(_meshConfig));
  }
  _accelerationConfig->connectTags(tag); 		                                                       
}
*/
void CouplingSchemeConfiguration2::addAbsoluteConvergenceMeasure(
    const std::string &dataName,
    const std::string &meshName,
    double             limit,
    bool               suffices,
    bool               strict)
{
  PRECICE_TRACE();
  PRECICE_CHECK(math::greater(limit, 0.0),
                "Absolute convergence limit has to be greater than zero. Please check the "
                "<absolute-convergence-measure "
                    << "limit=\"" << limit << "\" "
                    << "data=\"" << dataName << "\" "
                    << "mesh=\"" << meshName << "\" "
                    << "/> subtag in your <coupling-scheme ... /> in the preCICE configuration file.");
  impl::PtrConvergenceMeasure measure(new impl::AbsoluteConvergenceMeasure(limit));
  ConvergenceMeasureDefintion convMeasureDef;
  convMeasureDef.data        = getData(dataName, meshName);
  convMeasureDef.suffices    = suffices;
  convMeasureDef.strict      = strict;
  convMeasureDef.meshName    = meshName;
  convMeasureDef.measure     = std::move(measure);
  convMeasureDef.doesLogging = true;
  _config.convergenceMeasureDefinitions.push_back(convMeasureDef);
}
/*
void CouplingSchemeConfiguration2::addRelativeConvergenceMeasure(
    const std::string &dataName,
    const std::string &meshName,
    double             limit,
    bool               suffices,
    bool               strict)
{
  PRECICE_TRACE();
  PRECICE_CHECK(math::greater(limit, 0.0) && math::greaterEquals(1.0, limit),
                "Relative convergence limit has to be in ]0;1]. Please check the "
                "<relative-convergence-measure "
                    << "limit=\"" << limit << "\" "
                    << "data=\"" << dataName << "\" "
                    << "mesh=\"" << meshName << "\" "
                    << "/> subtag in your <coupling-scheme ... /> in the preCICE configuration file.");
  impl::PtrConvergenceMeasure measure(new impl::RelativeConvergenceMeasure(limit));
  ConvergenceMeasureDefintion convMeasureDef;
  convMeasureDef.data        = getData(dataName, meshName);
  convMeasureDef.suffices    = suffices;
  convMeasureDef.strict      = strict;
  convMeasureDef.meshName    = meshName;
  convMeasureDef.measure     = std::move(measure);
  convMeasureDef.doesLogging = true;
  _config.convergenceMeasureDefinitions.push_back(convMeasureDef);
}
*/
void CouplingSchemeConfiguration2::addResidualRelativeConvergenceMeasure(
    const std::string &dataName,
    const std::string &meshName,
    double             limit,
    bool               suffices,
    bool               strict)
{
  PRECICE_TRACE();
  PRECICE_CHECK(math::greater(limit, 0.0) && math::greaterEquals(1.0, limit),
                "Relative convergence limit has to be in ]0;1]. Please check the "
                "<residual-relative-convergence-measure "
                    << "limit=\"" << limit << "\" "
                    << "data=\"" << dataName << "\" "
                    << "mesh=\"" << meshName << "\" "
                    << "/> subtag in your <coupling-scheme ... /> in the preCICE configuration file.");
  impl::PtrConvergenceMeasure measure(new impl::ResidualRelativeConvergenceMeasure(limit));
  ConvergenceMeasureDefintion convMeasureDef;
  convMeasureDef.data        = getData(dataName, meshName);
  convMeasureDef.suffices    = suffices;
  convMeasureDef.strict      = strict;
  convMeasureDef.meshName    = meshName;
  convMeasureDef.measure     = std::move(measure);
  convMeasureDef.doesLogging = true;
  _config.convergenceMeasureDefinitions.push_back(convMeasureDef);
}

void CouplingSchemeConfiguration2::addMinIterationConvergenceMeasure(
    const std::string &dataName,
    const std::string &meshName,
    int                minIterations,
    bool               suffices,
    bool               strict)
{
  PRECICE_TRACE();
  impl::PtrConvergenceMeasure measure(new impl::MinIterationConvergenceMeasure(minIterations));
  ConvergenceMeasureDefintion convMeasureDef;
  convMeasureDef.data        = getData(dataName, meshName);
  convMeasureDef.suffices    = suffices;
  convMeasureDef.strict      = strict;
  convMeasureDef.meshName    = meshName;
  convMeasureDef.measure     = std::move(measure);
  convMeasureDef.doesLogging = false;
  _config.convergenceMeasureDefinitions.push_back(convMeasureDef);
}

PtrData2 CouplingSchemeConfiguration2::getData(
    const std::string &dataName,
    const std::string &meshName) const
{
  for (PtrMesh2 mesh : _meshConfig->meshes()) {
    if (meshName == mesh->getName()) {
      for (PtrData2 data : mesh->data()) {
        if (dataName == data->getName()) {
          return data;
        }
      }
    }
  }
  PRECICE_ERROR("Data \"" << dataName << "\" used by mesh \""
                          << meshName << "\" is not configured.");
}

PtrData2 CouplingSchemeConfiguration2::findDataByID(
    int ID) const
{
  for (PtrMesh2 mesh : _meshConfig->meshes()) {
    for (PtrData2 data : mesh->data()) {
      if (data->getID() == ID) {
        return data;
      }
    }
  }
  return nullptr;
}


PtrCouplingScheme CouplingSchemeConfiguration2::createSerialExplicitCouplingScheme(
    const std::string &accessor) const
{
  PRECICE_TRACE(accessor);
  PtrM2N2 m2n = _m2nConfig->getM2N(
      _config.participants[0], _config.participants[1]);
  SerialCouplingScheme2 *scheme = new SerialCouplingScheme2(
      _config.maxTime, _config.maxTimeWindows, _config.timeWindowSize,
      _config.validDigits, _config.participants[0], _config.participants[1],
      accessor, m2n, _config.dtMethod, BaseCouplingScheme2::Explicit);

  addDataToBeExchanged(*scheme, accessor);

  return PtrCouplingScheme(scheme);
}

/*
PtrCouplingScheme CouplingSchemeConfiguration2::createParallelExplicitCouplingScheme(
    const std::string &accessor) const
{
  PRECICE_TRACE(accessor);
  m2n::PtrM2N m2n = _m2nConfig->getM2N(
      _config.participants[0], _config.participants[1]);
  ParallelCouplingScheme *scheme = new ParallelCouplingScheme(
      _config.maxTime, _config.maxTimeWindows, _config.timeWindowSize,
      _config.validDigits, _config.participants[0], _config.participants[1],
      accessor, m2n, _config.dtMethod, BaseCouplingScheme::Explicit);

  addDataToBeExchanged(*scheme, accessor);

  return PtrCouplingScheme(scheme);
}

PtrCouplingScheme CouplingSchemeConfiguration2::createSerialImplicitCouplingScheme(
    const std::string &accessor) const
{
  PRECICE_TRACE(accessor);

  m2n::PtrM2N m2n = _m2nConfig->getM2N(
      _config.participants[0], _config.participants[1]);
  SerialCouplingScheme *scheme = new SerialCouplingScheme(
      _config.maxTime, _config.maxTimeWindows, _config.timeWindowSize,
      _config.validDigits, _config.participants[0], _config.participants[1],
      accessor, m2n, _config.dtMethod, BaseCouplingScheme::Implicit, _config.maxIterations);
  scheme->setExtrapolationOrder(_config.extrapolationOrder);

  addDataToBeExchanged(*scheme, accessor);
  PRECICE_CHECK(scheme->hasAnySendData(), "No send data configured. Use explicit scheme for one-way coupling. "
                                              << "Please check your <coupling-scheme ... /> and make sure that you provide at least one <exchange .../> subtag, where "
                                              << "from=\"" << accessor << "\".");

  // Add convergence measures
  PRECICE_CHECK(not _config.convergenceMeasureDefinitions.empty(),
                "At least one convergence measure has to be defined for an implicit coupling scheme. "
                "Please check your <coupling-scheme ... /> and make sure that you provide at least one <...-convergence-measure/> subtag in the precice-config.xml.");
  for (auto &elem : _config.convergenceMeasureDefinitions) {
    _meshConfig->addNeededMesh(_config.participants[1], elem.meshName);
    checkIfDataIsExchanged(elem.data->getID());
    scheme->addConvergenceMeasure(elem.data, elem.suffices, elem.strict, elem.measure, elem.doesLogging);
  }

  // Set relaxation parameters
  if (_accelerationConfig->getAcceleration().get() != nullptr) {
    for (std::string &neededMesh : _accelerationConfig->getNeededMeshes()) {
      _meshConfig->addNeededMesh(_config.participants[1], neededMesh);
    }
    for (const int dataID : _accelerationConfig->getAcceleration()->getDataIDs()) {
      checkIfDataIsExchanged(dataID);
    }
    scheme->setAcceleration(_accelerationConfig->getAcceleration());
  }
  if (scheme->doesFirstStep() && _accelerationConfig->getAcceleration() && not _accelerationConfig->getAcceleration()->getDataIDs().empty()) {
    int dataID = *(_accelerationConfig->getAcceleration()->getDataIDs().begin());
    PRECICE_CHECK(not scheme->hasSendData(dataID),
                  "In case of serial coupling, acceleration can be defined for "
                      << "data of second participant only!");
  }

  return PtrCouplingScheme(scheme);
}

PtrCouplingScheme CouplingSchemeConfiguration2::createParallelImplicitCouplingScheme(
    const std::string &accessor) const
{
  PRECICE_TRACE(accessor);
  m2n::PtrM2N m2n = _m2nConfig->getM2N(
      _config.participants[0], _config.participants[1]);
  ParallelCouplingScheme *scheme = new ParallelCouplingScheme(
      _config.maxTime, _config.maxTimeWindows, _config.timeWindowSize,
      _config.validDigits, _config.participants[0], _config.participants[1],
      accessor, m2n, _config.dtMethod, BaseCouplingScheme::Implicit, _config.maxIterations);
  scheme->setExtrapolationOrder(_config.extrapolationOrder);

  addDataToBeExchanged(*scheme, accessor);
  PRECICE_CHECK(scheme->hasAnySendData(), "No send data configured. Use explicit scheme for one-way coupling. "
                                              << "Please check your <coupling-scheme ... /> and make sure that you provide at least one <exchange .../> subtag, where "
                                              << "from=\"" << accessor << "\".");

  // Add convergence measures
  PRECICE_CHECK(not _config.convergenceMeasureDefinitions.empty(),
                "At least one convergence measure has to be defined for an implicit coupling scheme. "
                "Please check your <coupling-scheme ... /> and make sure that you provide at least one <...-convergence-measure/> subtag in the precice-config.xml.");
  for (auto &elem : _config.convergenceMeasureDefinitions) {
    _meshConfig->addNeededMesh(_config.participants[1], elem.meshName);
    checkIfDataIsExchanged(elem.data->getID());
    scheme->addConvergenceMeasure(elem.data, elem.suffices, elem.strict, elem.measure, elem.doesLogging);
  }

  // Set relaxation parameters
  if (_accelerationConfig->getAcceleration().get() != nullptr) {
    for (std::string &neededMesh : _accelerationConfig->getNeededMeshes()) {
      _meshConfig->addNeededMesh(_config.participants[1], neededMesh);
    }
    for (const int dataID : _accelerationConfig->getAcceleration()->getDataIDs()) {
      checkIfDataIsExchanged(dataID);
    }
    scheme->setAcceleration(_accelerationConfig->getAcceleration());
  }
  return PtrCouplingScheme(scheme);
}

PtrCouplingScheme CouplingSchemeConfiguration2::createMultiCouplingScheme(
    const std::string &accessor) const
{
  PRECICE_TRACE(accessor);

  BaseCouplingScheme *scheme;

  if (accessor == _config.controller) {
    std::vector<m2n::PtrM2N> m2ns;
    for (const std::string &participant : _config.participants) {
      m2ns.push_back(_m2nConfig->getM2N(
          _config.controller, participant));
    }

    scheme = new MultiCouplingScheme(
        _config.maxTime, _config.maxTimeWindows, _config.timeWindowSize,
        _config.validDigits, accessor, m2ns, _config.dtMethod,
        _config.maxIterations);
    scheme->setExtrapolationOrder(_config.extrapolationOrder);

    MultiCouplingScheme *castedScheme = dynamic_cast<MultiCouplingScheme *>(scheme);
    PRECICE_ASSERT(castedScheme, "The dynamic cast of CouplingScheme failed.");
    addMultiDataToBeExchanged(*castedScheme, accessor);
  } else {
    m2n::PtrM2N m2n = _m2nConfig->getM2N(
        accessor, _config.controller);

    scheme = new ParallelCouplingScheme(
        _config.maxTime, _config.maxTimeWindows, _config.timeWindowSize,
        _config.validDigits, accessor, _config.controller,
        accessor, m2n, _config.dtMethod, BaseCouplingScheme::Implicit, _config.maxIterations);
    scheme->setExtrapolationOrder(_config.extrapolationOrder);

    BiCouplingScheme *castedScheme = dynamic_cast<BiCouplingScheme *>(scheme);
    addDataToBeExchanged(*castedScheme, accessor);
  }
  PRECICE_CHECK(scheme->hasAnySendData(), "No send data configured. Use explicit scheme for one-way coupling. "
                                              << "Please check your <coupling-scheme ... /> and make sure that you provide at least one <exchange .../> subtag, where "
                                              << "from=\"" << accessor << "\".");

  // Add convergence measures
  PRECICE_CHECK(not _config.convergenceMeasureDefinitions.empty(),
                "At least one convergence measure has to be defined for an implicit coupling scheme. "
                "Please check your <coupling-scheme ... /> and make sure that you provide at least one <...-convergence-measure/> subtag in the precice-config.xml.");
  for (auto &elem : _config.convergenceMeasureDefinitions) {
    _meshConfig->addNeededMesh(_config.controller, elem.meshName);
    checkIfDataIsExchanged(elem.data->getID());
    scheme->addConvergenceMeasure(elem.data, elem.suffices, elem.strict, elem.measure, elem.doesLogging);
  }

  // Set relaxation parameters
  if (_accelerationConfig->getAcceleration().get() != nullptr) {
    for (std::string &neededMesh : _accelerationConfig->getNeededMeshes()) {
      _meshConfig->addNeededMesh(_config.controller, neededMesh);
    }
    for (const int dataID : _accelerationConfig->getAcceleration()->getDataIDs()) {
      checkIfDataIsExchanged(dataID);
    }

    scheme->setAcceleration(_accelerationConfig->getAcceleration());
  }
  PRECICE_INFO(scheme->doesFirstStep());
  if (not scheme->doesFirstStep() && _accelerationConfig->getAcceleration()) {
    if (_accelerationConfig->getAcceleration()->getDataIDs().size() < 3) {
      PRECICE_WARN("Due to numerical reasons, for multi coupling, the number of coupling data vectors should be at least 3, not: "
                   << _accelerationConfig->getAcceleration()->getDataIDs().size() << ". "
                   << "Please check the <data .../> subtags in your <acceleration:.../> and make sure that you have at least 3.");
    }
  }

  return PtrCouplingScheme(scheme);
}
*/
constants::TimesteppingMethod
CouplingSchemeConfiguration2::getTimesteppingMethod(
    const std::string &method) const
{
  PRECICE_TRACE(method);
  if (method == VALUE_FIXED) {
    return constants::FIXED_TIME_WINDOW_SIZE;
  } else if (method == VALUE_FIRST_PARTICIPANT) {
    return constants::FIRST_PARTICIPANT_SETS_TIME_WINDOW_SIZE;
  } else {
    PRECICE_ASSERT(false, "Unknown timestepping method \"" << method << "\"!");
  }
}

void CouplingSchemeConfiguration2::addDataToBeExchanged(
    BiCouplingScheme2 & scheme,
    const std::string &accessor) const
{
  PRECICE_TRACE();
  using std::get;
  for (const Config::Exchange &tuple : _config.exchanges) {
    PtrData2      data = get<0>(tuple);
    PtrMesh2      mesh = get<1>(tuple);
    const std::string &from = get<2>(tuple);
    const std::string &to   = get<3>(tuple);

    PRECICE_CHECK(to != from, "You cannot define an exchange from and to the same participant. "
                                  << "Please check the <exchange "
                                  << "data=\"" << data->getName() << "\" "
                                  << "mesh=\"" << mesh->getName() << "\" "
                                  << "from=\"" << from << "\" "
                                  << "to=\"" << to << "\" "
                                  << "/> tag in the <coupling-scheme:... /> of your precice-config.xml.");

    if (not(utils::contained(from, _config.participants) || from == _config.controller)) {
      PRECICE_CHECK(false, "Participant \"" + from + "\" is not configured for coupling scheme. "
                                                     "Please check the <exchange "
                               << "data=\"" << data->getName() << "\" "
                               << "mesh=\"" << mesh->getName() << "\" "
                               << "from=\"" << from << "\" "
                               << "to=\"" << to << "\" "
                               << "/> tag in the <coupling-scheme:... /> of your precice-config.xml.");
    }

    if (not(utils::contained(to, _config.participants) || to == _config.controller)) {
      PRECICE_CHECK(false, "Participant \"" + to + "\" is not configured for coupling scheme. "
                               << "Please check the <exchange "
                               << "data=\"" << data->getName() << "\" "
                               << "mesh=\"" << mesh->getName() << "\" "
                               << "from=\"" << from << "\" "
                               << "to=\"" << to << "\" "
                               << "/> tag in the <coupling-scheme:... /> of your precice-config.xml.");
    }

    bool requiresInitialization = get<4>(tuple);
    if (from == accessor) {
      scheme.addDataToSend(data, mesh, requiresInitialization);
      if (requiresInitialization && (_config.type == VALUE_SERIAL_EXPLICIT || _config.type == VALUE_SERIAL_IMPLICIT)) {
        PRECICE_CHECK(not scheme.doesFirstStep(), "In serial coupling only second participant can initialize data and send it. "
                                                      << "Please check the <exchange "
                                                      << "data=\"" << data->getName() << "\" "
                                                      << "mesh=\"" << mesh->getName() << "\" "
                                                      << "from=\"" << from << "\" "
                                                      << "to=\"" << to << "\" "
                                                      << "initialize=\"" << requiresInitialization << "\" "
                                                      << "/> tag in the <coupling-scheme:... /> of your precice-config.xml.");
      }
    } else if (to == accessor) {
      scheme.addDataToReceive(data, mesh, requiresInitialization);
      if (requiresInitialization && (_config.type == VALUE_SERIAL_EXPLICIT || _config.type == VALUE_SERIAL_IMPLICIT)) {
        PRECICE_CHECK(scheme.doesFirstStep(), "In serial coupling only first participant can receive initial data. "
                                                  << "Please check the <exchange "
                                                  << "data=\"" << data->getName() << "\" "
                                                  << "mesh=\"" << mesh->getName() << "\" "
                                                  << "from=\"" << from << "\" "
                                                  << "to=\"" << to << "\" "
                                                  << "initialize=\"" << requiresInitialization << "\" "
                                                  << "/> tag in the <coupling-scheme:... /> of your precice-config.xml.");
      }
    } else {
      PRECICE_ASSERT(_config.type == VALUE_MULTI);
    }
  }
}
/*
void CouplingSchemeConfiguration2::addMultiDataToBeExchanged(
    MultiCouplingScheme &scheme,
    const std::string &  accessor) const
{
  PRECICE_TRACE();
  using std::get;
  for (const Config::Exchange &tuple : _config.exchanges) {
    PtrData2      data = get<0>(tuple);
    PtrMesh2      mesh = get<1>(tuple);
    const std::string &from = get<2>(tuple);
    const std::string &to   = get<3>(tuple);

    if (not(utils::contained(from, _config.participants) || from == _config.controller)) {
      throw std::runtime_error{"Participant \"" + from + "\" is not configured for coupling scheme"};
    }

    if (not(utils::contained(to, _config.participants) || to == _config.controller)) {
      throw std::runtime_error{"Participant \"" + to + "\" is not configured for coupling scheme"};
    }

    bool initialize = get<4>(tuple);
    if (from == accessor) {
      size_t index = 0;
      for (const std::string &participant : _config.participants) {
        PRECICE_DEBUG("from: " << from << ", to: " << to << ", participant: " << participant);
        if (to == participant) {
          break;
        }
        index++;
      }
      PRECICE_ASSERT(index < _config.participants.size(), index, _config.participants.size());
      scheme.addDataToSend(data, mesh, initialize, index);
    } else {
      size_t index = 0;
      for (const std::string &participant : _config.participants) {
        PRECICE_DEBUG("from: " << from << ", to: " << to << ", participant: " << participant);
        if (from == participant) {
          break;
        }
        index++;
      }
      PRECICE_ASSERT(index < _config.participants.size(), index, _config.participants.size());
      scheme.addDataToReceive(data, mesh, initialize, index);
    }
  }
}

void CouplingSchemeConfiguration2::checkIfDataIsExchanged(
    int dataID) const
{
  bool hasFound = false;
  for (const Config::Exchange &tuple : _config.exchanges) {
    PtrData2 data = std::get<0>(tuple);
    if (data->getID() == dataID) {
      hasFound = true;
    }
  }

  std::string dataName = "";
  auto        dataptr  = findDataByID(dataID);
  if (dataptr) {
    dataName = dataptr->getName();
  }

  PRECICE_CHECK(hasFound, "You need to exchange every data that you use for convergence measures "
                              << "and/or the iteration acceleration. Data \"" << dataName << "\" is "
                              << "currently not exchanged, but used for convergence measures and/or iteration "
                              << "acceleration. Please check the <exchange ... /> and "
                              << "<...-convergence-measure ... /> tags in the "
                              << "<coupling-scheme:... /> of your precice-config.xml.");
}*/

} // namespace cplscheme
} // namespace precice
