#pragma once

#include <string>
#include "logging/Logger.hpp"
//#include "logging/config/LogConfiguration.hpp"

#include "LogConfiguration2.h"

//#include "precice/config/SolverInterfaceConfiguration.hpp"

#include "SolverInterfaceConfiguration2.h"

//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"

#include <FECore/sdk.h>
#include <FECore/FECallBack.h>
#include <FECore/Callback.h>
#include <FECore/FENode.h>
#include <FECore/FEModel.h>
#include <FECore/FEMesh.h>
#include <FECore/FEAnalysis.h>
#include <precice/SolverInterface.hpp>
#include <FECore/DumpMemStream.h>
#include <rttr/variant.h>
#include <variant>

#include <FECore/log.h>


namespace precice {
namespace config {

/**
 * @brief Main class for preCICE XML Configuration2 tree.
 *
 * The Configuration2 process is triggered by fetching the root tag with method
 * getXMLTag() and calling its parse() method.
 */

class Configuration2 : public xml::XMLTag2::Listener {
//class Configuration2 : public xml::XMLTag::Listener {
public:
  Configuration2(FEModel *fem);

  /**
   * @brief Destructor, empty.
   */
  virtual ~Configuration2() {}

  /**
   * @brief Returns root xml tag to start the automatic Configuration2 process.
   */
   
  xml::XMLTag2 &getXMLTag();

/*
   xml::XMLTag &getXMLTag();
*/

  /**
   * @brief Callback function required for use of automatic Configuration2.
   *
   * @return True, if successful.
   */
   
  virtual void XMLTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag);

  /**
   * @brief Callback function required for use of automatic Configuration2.
   *
   * @return True, if successful.
   */
   
   
  virtual void xmlEndTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag);

    /**
     * @brief Callback at end of XML tag and at end of subtag.
     *
     * At this callback, the attributes and all subtags of callingTag are parsed.
     * This callback is first done for the listener, and then for the parent tag
     * listener (if existing).
     */
     /*
    virtual void xmlEndTagCallback(xml::ConfigurationContext2 const &context, xml::XMLTag2 &callingTag);
*/
  /**
   * @brief Returns solver interface Configuration2.
   */
  const SolverInterfaceConfiguration2 &getSolverInterfaceConfiguration() const;
  
  FEModel *fem1;

private:
  logging::Logger _log{"config::Configuration"};

  // @brief Root tag of preCICE Configuration2.

  xml::XMLTag2 _tag;

  LogConfiguration2 _logConfig;

  SolverInterfaceConfiguration2 _solverInterfaceConfig;
};

} // namespace config
} // namespace precice
