#include "SolverInterfaceConfiguration2.h"
#include <map>
#include <memory>
#include <ostream>
#include <vector>
//#include "ParticipantConfiguration.hpp"

#include "ParticipantConfiguration2.h"

//#include "cplscheme/config/CouplingSchemeConfiguration.hpp"

#include "CouplingSchemeConfiguration2.h"

#include "logging/LogMacros.hpp"
//#include "m2n/config/M2NConfiguration.hpp"

#include "M2NConfiguration2.h"

//#include "mesh/Mesh.hpp"

#include "Mesh2.h"

//#include "mesh/config/DataConfiguration.hpp"

#include "DataConfiguration2.h"

//#include "mesh/config/MeshConfiguration.hpp"

#include "MeshConfiguration2.h"

#include "precice/config/SharedPointer.hpp"
#include "precice/impl/MeshContext.hpp"
#include "precice/impl/Participant.hpp"
#include "precice/impl/SharedPointer.hpp"
#include "utils/assertion.hpp"
#include "xml/ConfigParser.hpp"
#include "xml/XMLAttribute.hpp"

namespace precice {
namespace config {

  using PtrParticipantConfiguration2 = std::shared_ptr<precice::config::ParticipantConfiguration2>;
  using PtrCouplingSchemeConfiguration2 = std::shared_ptr<precice::cplscheme::CouplingSchemeConfiguration2>;
  
SolverInterfaceConfiguration2::SolverInterfaceConfiguration2(xml::XMLTag2 &parent, FEModel *fem)
{

  fem1 = fem;

  using namespace xml;
  XMLTag2 tag(*this, "solver-interface", XMLTag2::OCCUR_ONCE, "", fem1);
  tag.setDocumentation("Configuration of simulation relevant features.");
  auto attrDimensions = makeXMLAttribute("dimensions", 2)
                            .setDocumentation("Determines the spatial dimensionality of the configuration")
                            .setOptions({2, 3});
  tag.addAttribute(attrDimensions);

  _dataConfiguration = PtrDataConfiguration2(
      new mesh::DataConfiguration2(tag, fem1));
  _meshConfiguration = PtrMeshConfiguration2(
      new mesh::MeshConfiguration2(tag, _dataConfiguration, fem1));
  _m2nConfiguration = m2n::M2NConfiguration2::SharedPointer2(
      new m2n::M2NConfiguration2(tag, fem1));
  _participantConfiguration = PtrParticipantConfiguration2(
      new ParticipantConfiguration2(tag, _meshConfiguration, fem1));
  _couplingSchemeConfiguration = PtrCouplingSchemeConfiguration2(
      new precice::cplscheme::CouplingSchemeConfiguration2(tag, _meshConfiguration,
                                                 _m2nConfiguration, fem1));
  parent.addSubtag(tag);
}

void SolverInterfaceConfiguration2::XMLTagCallback(
    xml::ConfigurationContext2 const &context,
    xml::XMLTag2 &                    tag)
{
  PRECICE_TRACE();
  if (tag.getName() == "solver-interface") {
    _dimensions = tag.getIntAttributeValue("dimensions");
    _dataConfiguration->setDimensions(_dimensions);
    _meshConfiguration->setDimensions(_dimensions);
    _participantConfiguration->setDimensions(_dimensions);
  } else {
    PRECICE_ASSERT(false, "Received callback from unknown tag " << tag.getName());
  }
}

void SolverInterfaceConfiguration2::xmlEndTagCallback(
    xml::ConfigurationContext2 const &context,
    xml::XMLTag2 &                    tag)
{
/*
  PRECICE_TRACE();
  if (tag.getName() == "solver-interface") {
    //test if both participants do have the exchange meshes
    typedef std::map<std::string, std::vector<std::string>>::value_type neededMeshPair;
    for (const neededMeshPair &neededMeshes : _meshConfiguration->getNeededMeshes()) {
      bool participantFound = false;
      for (const impl::PtrParticipant &participant : _participantConfiguration->getParticipants()) {
        if (participant->getName() == neededMeshes.first) {
          for (const std::string &neededMesh : neededMeshes.second) {
            const impl::MeshContext *meshContext = participant->usedMeshContextByName(neededMesh);
            PRECICE_CHECK(meshContext != nullptr,
                          "Participant \"" << neededMeshes.first << "\" needs to use the mesh \"" << neededMesh << "\" to be able to use it in the coupling scheme. "
                                           << "Please either add a use-mesh tag in this participant's configuration, or use a different mesh in the coupling scheme.");
          }
          participantFound = true;
          break;
        }
      }
      PRECICE_ASSERT(participantFound);
    }
  }
  */
}

int SolverInterfaceConfiguration2::getDimensions() const
{
  return _dimensions;
}

const PtrParticipantConfiguration2 &
SolverInterfaceConfiguration2::getParticipantConfiguration() const
{
  return _participantConfiguration;
}
} // namespace config
} // namespace precice
