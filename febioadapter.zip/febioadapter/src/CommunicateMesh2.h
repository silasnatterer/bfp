#pragma once

#include <string>
#include "com/SharedPointer.hpp"
#include "logging/Logger.hpp"
//#include "mesh/Mesh.hpp"

#include "Mesh2.h"

#include "Communication2.h"

namespace precice {
namespace mesh {
class Mesh;
} // namespace mesh

namespace com {

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;

/// Copies a Mesh object from a sender to a receiver.
class CommunicateMesh2 {
public:

  using PtrCommunication2 = std::shared_ptr<precice::com::Communication2>;
  
  /// Constructor, takes communication to be used in transfer.
  explicit CommunicateMesh2(
      PtrCommunication2 communication);

  /// Sends a constructed mesh to the receiver with given rank.
  void sendMesh(
      const mesh::Mesh2 &mesh,
      int               rankReceiver);

  /// Receives a mesh from the sender with given rank. Adds received mesh to mesh.
  void receiveMesh(
      mesh::Mesh2 &mesh,
      int         rankSender);

  void broadcastSendMesh(
      const mesh::Mesh2 &mesh);

  void broadcastReceiveMesh(
      mesh::Mesh2 &mesh);

private:
  logging::Logger _log{"com::CommunicateMesh"};

  /// Communication means used for the transfer of the geometry.
  PtrCommunication2 _communication;
};
} // namespace com
} // namespace precice
