#pragma once

//#include "DistributedComFactory.hpp"

#include "DistributedComFactory2.h"

#include "com/SharedPointer.hpp"
//#include "m2n/DistributedCommunication.hpp"

#include "DistributedCommunication2.h"

#include "mesh/SharedPointer.hpp"

#include "Communication2.h"
#include "Mesh2.h"

namespace precice {
namespace m2n {
class GatherScatterComFactory2 : public DistributedComFactory2 {
public:

  using PtrCommunication2 = std::shared_ptr<precice::com::Communication2>;
  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  
  GatherScatterComFactory2(PtrCommunication2 masterCom);

  DistributedCommunication2::SharedPointer newDistributedCommunication(
      PtrMesh2 mesh);
  
private:
  /// communication between the master processes
  PtrCommunication2 _masterCom;
};
} // namespace m2n
} // namespace precice
