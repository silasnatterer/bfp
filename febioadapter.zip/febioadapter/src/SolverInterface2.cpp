//#include "precice/SolverInterface.hpp"

#include "SolverInterface2.h"

#include "cplscheme/Constants.hpp"
//#include "precice/impl/SolverInterfaceImpl.hpp"

#include "SolverInterfaceImpl2.h"

#include "precice/impl/versions.hpp"

namespace precice {


SolverInterface2::SolverInterface2(
    const std::string &participantName,
    const std::string &configurationFileName,
    int                solverProcessIndex,
    int                solverProcessSize, 
    FEModel *fem)
    : _impl(new impl::SolverInterfaceImpl2(participantName, configurationFileName, solverProcessIndex, solverProcessSize, nullptr, fem))
{
}

/*
std::string SolverInterface::Hello() {
    return "precice test";
}
*/
/*
SolverInterface2::SolverInterface2(
    const std::string &participantName,
    const std::string &configurationFileName,
    int                solverProcessIndex,
    int                solverProcessSize,
    void *             communicator,
    FEModel *fem)
    : _impl(new impl::SolverInterfaceImpl2(participantName, configurationFileName, solverProcessIndex, solverProcessSize, communicator, fem))
{
}
*/

SolverInterface2::~SolverInterface2() = default;

double SolverInterface2::initialize()
{
  return _impl->initialize();
}

void SolverInterface2::initializeData()
{
  _impl->initializeData();
}

double SolverInterface2::advance(
    double computedTimestepLength)
{
  return _impl->advance(computedTimestepLength);
}

void SolverInterface2::finalize()
{
  return _impl->finalize();
}

int SolverInterface2::getDimensions() const
{
  return _impl->getDimensions();
}

bool SolverInterface2::isCouplingOngoing() const
{
  return _impl->isCouplingOngoing();
}

bool SolverInterface2::isReadDataAvailable() const
{
  return _impl->isReadDataAvailable();
}

bool SolverInterface2::isWriteDataRequired(
    double computedTimestepLength) const
{
  return _impl->isWriteDataRequired(computedTimestepLength);
}

bool SolverInterface2::isTimeWindowComplete() const
{
  return _impl->isTimeWindowComplete();
}

bool SolverInterface2::isActionRequired(
    const std::string &action) const
{
  return _impl->isActionRequired(action);
}

void SolverInterface2::markActionFulfilled(
    const std::string &action)
{
  _impl->markActionFulfilled(action);
}

bool SolverInterface2::hasMesh(
    const std::string &meshName) const
{
  return _impl->hasMesh(meshName);
}

int SolverInterface2::getMeshID(
    const std::string &meshName) const
{
  return _impl->getMeshID(meshName);
}

std::set<int> SolverInterface2::getMeshIDs() const
{
  return _impl->getMeshIDs();
}

bool SolverInterface2::hasData(
    const std::string &dataName, int meshID) const
{
  return _impl->hasData(dataName, meshID);
}

int SolverInterface2::getDataID(
    const std::string &dataName, int meshID) const
{
  return _impl->getDataID(dataName, meshID);
}

bool SolverInterface2::hasToEvaluateSurrogateModel() const
{
  return _impl->hasToEvaluateSurrogateModel();
}

bool SolverInterface2::hasToEvaluateFineModel() const
{
  return _impl->hasToEvaluateFineModel();
}

//void SolverInterface:: resetMesh
//(
//  int meshID )
//{
//  _impl->resetMesh(meshID);
//}

int SolverInterface2::setMeshVertex(
    int           meshID,
    const double *position)
{
  return _impl->setMeshVertex(meshID, position);
}

int SolverInterface2::getMeshVertexSize(
    int meshID) const
{
  return _impl->getMeshVertexSize(meshID);
}

void SolverInterface2::setMeshVertices(
    int           meshID,
    int           size,
    const double *positions,
    int *         ids)
{
  _impl->setMeshVertices(meshID, size, positions, ids);
}

void SolverInterface2::getMeshVertices(
    int        meshID,
    int        size,
    const int *ids,
    double *   positions) const
{
  _impl->getMeshVertices(meshID, size, ids, positions);
}

void SolverInterface2::getMeshVertexIDsFromPositions(
    int           meshID,
    int           size,
    const double *positions,
    int *         ids) const
{
  _impl->getMeshVertexIDsFromPositions(meshID, size, positions, ids);
}
/*
int SolverInterface2::setMeshEdge(
    int meshID,
    int firstVertexID,
    int secondVertexID)
{
  return _impl->setMeshEdge(meshID, firstVertexID, secondVertexID);
}

void SolverInterface2::setMeshTriangle(
    int meshID,
    int firstEdgeID,
    int secondEdgeID,
    int thirdEdgeID)
{
  _impl->setMeshTriangle(meshID, firstEdgeID, secondEdgeID, thirdEdgeID);
}

void SolverInterface2::setMeshTriangleWithEdges(
    int meshID,
    int firstVertexID,
    int secondVertexID,
    int thirdVertexID)
{
  _impl->setMeshTriangleWithEdges(meshID, firstVertexID, secondVertexID, thirdVertexID);
}

void SolverInterface2::setMeshQuad(
    int meshID,
    int firstEdgeID,
    int secondEdgeID,
    int thirdEdgeID,
    int fourthEdgeID)
{
  _impl->setMeshQuad(meshID, firstEdgeID, secondEdgeID, thirdEdgeID, fourthEdgeID);
}

void SolverInterface2::setMeshQuadWithEdges(
    int meshID,
    int firstVertexID,
    int secondVertexID,
    int thirdVertexID,
    int fourthVertexID)
{
  _impl->setMeshQuadWithEdges(meshID, firstVertexID, secondVertexID, thirdVertexID,
                              fourthVertexID);
}
*/
void SolverInterface2::mapReadDataTo(
    int toMeshID)
{
  _impl->mapReadDataTo(toMeshID);
}

void SolverInterface2::mapWriteDataFrom(
    int fromMeshID)
{
  _impl->mapWriteDataFrom(fromMeshID);
}

void SolverInterface2::writeBlockVectorData(
    int           dataID,
    int           size,
    const int *   valueIndices,
    const double *values)
{
  _impl->writeBlockVectorData(dataID, size, valueIndices, values);
}

void SolverInterface2::writeVectorData(
    int           dataID,
    int           valueIndex,
    const double *value)
{
  _impl->writeVectorData(dataID, valueIndex, value);
}

void SolverInterface2::writeBlockScalarData(
    int           dataID,
    int           size,
    const int *   valueIndices,
    const double *values)
{
  _impl->writeBlockScalarData(dataID, size, valueIndices, values);
}

void SolverInterface2::writeScalarData(
    int    dataID,
    int    valueIndex,
    double value)
{
  _impl->writeScalarData(dataID, valueIndex, value);
}

void SolverInterface2::readBlockVectorData(
    int        dataID,
    int        size,
    const int *valueIndices,
    double *   values) const
{
  _impl->readBlockVectorData(dataID, size, valueIndices, values);
}

void SolverInterface2::readVectorData(
    int     dataID,
    int     valueIndex,
    double *value) const
{
  return _impl->readVectorData(dataID, valueIndex, value);
}

void SolverInterface2::readBlockScalarData(
    int        dataID,
    int        size,
    const int *valueIndices,
    double *   values) const
{
  _impl->readBlockScalarData(dataID, size, valueIndices, values);
}

void SolverInterface2::readScalarData(
    int     dataID,
    int     valueIndex,
    double &value) const
{
  return _impl->readScalarData(dataID, valueIndex, value);
}

std::string getVersionInformation()
{
  return {precice::versionInformation};
}

namespace constants {

const std::string &actionWriteInitialData()
{
  return cplscheme::constants::actionWriteInitialData();
}

const std::string &actionWriteIterationCheckpoint()
{
  return cplscheme::constants::actionWriteIterationCheckpoint();
}

const std::string &actionReadIterationCheckpoint()
{
  return cplscheme::constants::actionReadIterationCheckpoint();
}

} // namespace constants

} // namespace precice
