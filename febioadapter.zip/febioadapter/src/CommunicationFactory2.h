#pragma once

#include <stdexcept>
#include <string>
#include "com/SharedPointer.hpp"

#include "Communication2.h"

namespace precice {
namespace com {
class CommunicationFactory2 {

public:

  using PtrCommunication2 = std::shared_ptr<Communication2>;
  
  virtual ~CommunicationFactory2(){};

  virtual PtrCommunication2 newCommunication() = 0;

  virtual std::string addressDirectory()
  {
    throw std::runtime_error("Not available!");
  }
};
} // namespace com
} // namespace precice
