#pragma once

#include <string>
#include <vector>
//#include "BaseCouplingScheme.hpp"

#include "BaseCouplingScheme2.h"

#include "cplscheme/Constants.hpp"
#include "logging/Logger.hpp"
#include "m2n/SharedPointer.hpp"
#include "mesh/SharedPointer.hpp"
#include "utils/assertion.hpp"

//#include "CouplingData.hpp"
#include "CouplingData2.h"
#include "M2N2.h"
#include "Data2.h"
#include "Mesh2.h"

namespace precice {
namespace cplscheme {

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrData2 = std::shared_ptr<precice::mesh::Data2>;
  
struct CouplingData;

/**
 * @brief Abstract base class for coupling schemes with two participants.
 *
 * ! General description
 * A BiCouplingScheme couples two participants. It is a specialization of
 * BaseCouplingScheme.
 *
 */
class BiCouplingScheme2 : public BaseCouplingScheme2 
{

public:

  using PtrM2N2 = std::shared_ptr<precice::m2n::M2N2>;
  
  typedef std::map<int, std::shared_ptr<CouplingData2>> DataMap;
  
  BiCouplingScheme2(
      double                        maxTime,
      int                           maxTimeWindows,
      double                        timeWindowSize,
      int                           validDigits,
      const std::string &           firstParticipant,
      const std::string &           secondParticipant,
      const std::string &           localParticipant,
      PtrM2N2                       m2n,
      int                           maxIterations,
      BaseCouplingScheme2::CouplingMode                  cplMode,
      constants::TimesteppingMethod dtMethod);

  /// Adds data to be sent on data exchange and possibly be modified during coupling iterations.
  void addDataToSend(
      PtrData2 data,
      PtrMesh2 mesh,
      bool          requiresInitialization);

  /// Adds data to be received on data exchange.
  void addDataToReceive(
      PtrData2 data,
      PtrMesh2 mesh,
      bool          requiresInitialization);

  /// returns list of all coupling partners
  std::vector<std::string> getCouplingPartners() const override final;

  /**
   * @returns true, if coupling scheme has any sendData
   */
  bool hasAnySendData() override final
  {
    return not getSendData().empty();
  }

  /**
   * @returns true, if coupling scheme has sendData with given DataID
   */
  bool hasSendData(int dataID)
  {
    return getSendData(dataID) != nullptr;
  }

protected:
  /// Returns all data to be sent.
  DataMap &getSendData()
  {
    return _sendData;
  }

  /// Returns all data to be received.
  DataMap &getReceiveData()
  {
    return _receiveData;
  }

  /// Sets the values
  CouplingData2 *getSendData(int dataID);

  /// Returns all data to be received with data ID as given.
  CouplingData2 *getReceiveData(int dataID);

  /// @return Communication device to the other coupling participant.
  PtrM2N2 getM2N() const
  {
    PRECICE_ASSERT(_m2n);
    return _m2n;
  }

  /// @brief Receive from coupling partner and return whether coupling scheme has converged
  bool receiveConvergence();

private:
  mutable logging::Logger _log{"cplscheme::BiCouplingScheme"};

  /// Communication to the other coupling participant.
  PtrM2N2 _m2n;

  /// All send data as a map "data ID -> data"
  DataMap _sendData;

  /// All receive data as a map "data ID -> data"
  DataMap _receiveData;

  /// First participant name.
  std::string _firstParticipant = "unknown";

  /// Second participant name.
  std::string _secondParticipant = "unknown";

  /// Implements functionality for setupConvergenceMeasures
  void assignDataToConvergenceMeasure(ConvergenceMeasureContext *convMeasure, int dataID) override
  {/*									//auskommentiert
    if ((getSendData(dataID) != nullptr)) {
      convMeasure->couplingData = getSendData(dataID);
    } else {
      convMeasure->couplingData = getReceiveData(dataID);
      PRECICE_ASSERT(convMeasure->couplingData != nullptr);
    }*/
  }

  /**
   * @brief BiCouplingScheme has to call store for receive and send data
   */
  void storeData() override
  {
    store(getSendData());
    store(getReceiveData());
  }
};

} // namespace cplscheme
} // namespace precice
