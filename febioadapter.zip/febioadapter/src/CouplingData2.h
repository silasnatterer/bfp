#pragma once

#include <Eigen/Core>
//#include "mesh/Data.hpp"

#include "Data2.h"
#include "Mesh2.h"

#include "mesh/SharedPointer.hpp"
#include "utils/assertion.hpp"

namespace precice {
namespace cplscheme {

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrData2 = std::shared_ptr<precice::mesh::Data2>;

struct CouplingData2 {
  using DataMatrix = Eigen::MatrixXd;

  /// Data values of current iteration.
  Eigen::VectorXd *values;

  /// Data values of previous iteration (1st col) and previous time windows.
  DataMatrix oldValues;

  PtrMesh2 mesh;

  ///  True, if the data values if this CouplingData requires to be initialized by a participant.
  bool requiresInitialization;

  /// dimension of one data value (scalar=1, or vectorial=interface-dimension)
  int dimension;

  /**
   * @brief Default constructor, not to be used!
   *
   * Necessary when compiler creates template code for std::map::operator[].
   */
  CouplingData2()
  {
    PRECICE_ASSERT(false);
  }

  CouplingData2(
      Eigen::VectorXd *values,
      PtrMesh2    mesh,
      bool             requiresInitialization,
      int              dimension)
      : values(values),
        mesh(mesh),
        requiresInitialization(requiresInitialization),
        dimension(dimension)
  {
    PRECICE_ASSERT(values != NULL);
    PRECICE_ASSERT(mesh.use_count() > 0);
  }
};

} // namespace cplscheme
} // namespace precice
