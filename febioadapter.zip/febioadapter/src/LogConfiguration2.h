#pragma once

#include <string>
#include "logging/LogConfiguration.hpp"
#include "logging/Logger.hpp"
#include <FECore/FEModel.h>
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"

namespace precice {
namespace config {

/// Configures the log config file to use
class LogConfiguration2 : public xml::XMLTag2::Listener {
public:
  LogConfiguration2(xml::XMLTag2 &parent, FEModel *fem);
  
  FEModel *fem1;

  virtual void XMLTagCallback(const xml::ConfigurationContext2 &context, xml::XMLTag2 &tag);

  virtual void xmlEndTagCallback(const xml::ConfigurationContext2 &context, xml::XMLTag2 &tag);

private:
  precice::logging::Logger _log{"logging::config::LogConfiguration"};

  precice::logging::LoggingConfiguration _logconfig;
};

} // namespace config
} // namespace precice
