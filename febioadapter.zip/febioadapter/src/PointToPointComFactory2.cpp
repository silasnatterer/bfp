//#include "PointToPointComFactory.hpp"

#include "PointToPointComFactory2.h"

//#include "PointToPointCommunication.hpp"

#include "PointToPointCommunication2.h"

#include "com/SharedPointer.hpp"

namespace precice {
namespace m2n {

PointToPointComFactory2::PointToPointComFactory2(PtrCommunicationFactory2 comFactory)
    : _comFactory(comFactory) {}

DistributedCommunication2::SharedPointer
PointToPointComFactory2::newDistributedCommunication(PtrMesh2 mesh)
{
  return DistributedCommunication2::SharedPointer(new PointToPointCommunication2(_comFactory, mesh));
}

} // namespace m2n
} // namespace precice
