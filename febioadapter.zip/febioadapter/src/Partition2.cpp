//#include "partition/Partition.hpp"

#include "Partition2.h"

#include "Mesh2.h"

namespace precice {
namespace partition {

using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  
Partition2::Partition2(PtrMesh2 mesh)
    : _mesh(mesh)
{
}

} // namespace partition
} // namespace precice
