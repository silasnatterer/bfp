#pragma once

#include <Eigen/Core>
#include <string>
#include <vector>
#include "action/SharedPointer.hpp"
#include "io/SharedPointer.hpp"
#include "logging/Logger.hpp"
#include "mapping/SharedPointer.hpp"
#include "mesh/SharedPointer.hpp"
#include "partition/ReceivedPartition.hpp"
//#include "precice/impl/Participant.hpp"
#include "precice/impl/SharedPointer.hpp"
#include "utils/networking.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"
#include "MeshConfiguration2.h"
#include "Participant2.h"
#include "MappingConfiguration2.h"
//#include "ActionConfiguration2.h"
#include "ExportConfiguration2.h"
#include "Mesh2.h"
#include "Data2.h"

namespace precice {
namespace config {

/**
 * @brief Performs XML configuration of a participant.
 */
class ParticipantConfiguration2 : public xml::XMLTag2::Listener {
public:

  using PtrMeshConfiguration2 = std::shared_ptr<precice::mesh::MeshConfiguration2>;
  using PtrParticipant2 = std::shared_ptr<precice::impl::Participant2>;
  using PtrMappingConfiguration2 = std::shared_ptr<precice::mapping::MappingConfiguration2>;
//  using PtrActionConfiguration2 = std::shared_ptr<precice::action::ActionConfiguration2>;
  using PtrExportConfiguration2 = std::shared_ptr<precice::io::ExportConfiguration2>;
  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrData2 = std::shared_ptr<precice::mesh::Data2>;
  
  FEModel *fem1;
     
  ParticipantConfiguration2(
      xml::XMLTag2 &                     parent,
      const PtrMeshConfiguration2 &meshConfiguration, 
      FEModel *fem);

  virtual ~ParticipantConfiguration2();
  
  void setDimensions(int dimensions);

  /**
   * @brief Callback function required for use of automatic configuration.
   *
   * @return True, if successful.
   */
  virtual void XMLTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);

  /**
   * @brief Callback function required for use of automatic configuration.
   *
   * @return True, if successful.
   */
  virtual void xmlEndTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);

  /// Returns all configured participants.
  const std::vector<PtrParticipant2> &getParticipants() const;

private:
  struct WatchPointConfig {
    std::string     name;
    std::string     nameMesh;
    Eigen::VectorXd coordinates;
  };

  mutable logging::Logger _log{"config::ParticipantConfiguration2"};

  const std::string TAG             = "participant";
  const std::string TAG_WRITE       = "write-data";
  const std::string TAG_READ        = "read-data";
  const std::string TAG_DATA_ACTION = "data-action";
  const std::string TAG_USE_MESH    = "use-mesh";
  const std::string TAG_WATCH_POINT = "watch-point";
  const std::string TAG_MASTER      = "master";

  const std::string ATTR_NAME               = "name";
  const std::string ATTR_SOURCE_DATA        = "source-data";
  const std::string ATTR_TARGET_DATA        = "target-data";
  const std::string ATTR_TIMING             = "timing";
  const std::string ATTR_LOCAL_OFFSET       = "offset";
  const std::string ATTR_ACTION_TYPE        = "type";
  const std::string ATTR_FROM               = "from";
  const std::string ATTR_SAFETY_FACTOR      = "safety-factor";
  const std::string ATTR_GEOMETRIC_FILTER   = "geometric-filter";
  const std::string ATTR_PROVIDE            = "provide";
  const std::string ATTR_MESH               = "mesh";
  const std::string ATTR_COORDINATE         = "coordinate";
  const std::string ATTR_COMMUNICATION      = "communication";
  const std::string ATTR_CONTEXT            = "context";
  const std::string ATTR_NETWORK            = "network";
  const std::string ATTR_EXCHANGE_DIRECTORY = "exchange-directory";

  const std::string VALUE_FILTER_ON_SLAVES = "on-slaves";
  const std::string VALUE_FILTER_ON_MASTER = "on-master";
  const std::string VALUE_NO_FILTER        = "no-filter";

  const std::string VALUE_VTK = "vtk";

  int _dimensions = 0;

  PtrMeshConfiguration2 _meshConfig;

  PtrMappingConfiguration2 _mappingConfig;

//  PtrActionConfiguration2 _actionConfig;

  PtrExportConfiguration2 _exportConfig;

  std::vector<PtrParticipant2> _participants;

  std::vector<WatchPointConfig> _watchPointConfigs;

  partition::ReceivedPartition::GeometricFilter getGeoFilter(const std::string &geoFilter) const;

  PtrMesh2 copy(const PtrMesh2 &mesh) const;

  const PtrData2 &getData(
      const PtrMesh2 &mesh,
      const std::string &  nameData) const;

  mapping::PtrMapping getMapping(const std::string &mappingName);

  // Does this participant already define a master tag?
  // This context information is needed in xmlEndTagCallback to create a default
  // master com if required (i.e. no solution yet defined and parallel).
  bool _isMasterDefined = false;


  void finishParticipantConfiguration2(
      const xml::ConfigurationContext2 &context,
      const PtrParticipant2 &     participant);
};

} // namespace config
} // namespace precice
