//#include "precice/impl/DataContext.hpp"

#include "DataContext2.h"

#include <memory>
#include "mesh/Data.hpp"


namespace precice {
namespace impl {

std::string DataContext2::getName() const
{
  return fromData->getName();
}

} // namespace impl
} // namespace precice
