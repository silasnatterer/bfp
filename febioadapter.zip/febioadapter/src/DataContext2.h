#pragma once

#include <string>
//#include "MappingContext2.hpp"

#include "MappingContext2.h"

#include "mesh/SharedPointer.hpp"

#include "Mesh2.h"
#include "Data2.h"

namespace precice {
namespace impl {

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrData2 = std::shared_ptr<precice::mesh::Data2>;
    
/**
 * @brief Stores one Data object with related context. If this dataContext is not associated with a mapping,
 * fromData and toData refer to the same data object.
 */
struct DataContext2 {
  bool used = false;

  std::string getName() const;

  PtrData2 fromData;

  PtrData2 toData;

  PtrMesh2 mesh;

  MappingContext2 mappingContext;
};

} // namespace impl
} // namespace precice
