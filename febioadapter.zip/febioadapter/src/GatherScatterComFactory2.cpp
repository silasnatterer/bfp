//#include "GatherScatterCommunication.hpp"

#include "GatherScatterCommunication2.h"

//#include "GatherScatterComFactory.hpp"

#include "GatherScatterComFactory2.h"

namespace precice {
namespace m2n {
GatherScatterComFactory2::GatherScatterComFactory2(
    PtrCommunication2 masterCom)
    : _masterCom(masterCom)
{
}

DistributedCommunication2::SharedPointer
GatherScatterComFactory2::newDistributedCommunication(PtrMesh2 mesh)
{
  return DistributedCommunication2::SharedPointer(
      new GatherScatterCommunication2(_masterCom, mesh));
}
} // namespace m2n
} // namespace precice
