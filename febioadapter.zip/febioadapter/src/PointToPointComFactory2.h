#pragma once

//#include "DistributedComFactory.hpp"

#include "DistributedComFactory2.h"

#include "com/SharedPointer.hpp"
//#include "m2n/DistributedCommunication.hpp"

#include "DistributedCommunication2.h"

//#include "mesh/SharedPointer.hpp"
#include "Mesh2.h"

#include "CommunicationFactory2.h"

namespace precice {
namespace m2n {

class PointToPointComFactory2 : public DistributedComFactory2 {

public:

  using PtrCommunicationFactory2 = std::shared_ptr<precice::com::CommunicationFactory2>;
  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  
  explicit PointToPointComFactory2(PtrCommunicationFactory2 comFactory);
  
  DistributedCommunication2::SharedPointer newDistributedCommunication(
      PtrMesh2 mesh);

private:
  /// communication factory for 1:M communications
  PtrCommunicationFactory2 _comFactory;
};

} // namespace m2n
} // namespace precice
