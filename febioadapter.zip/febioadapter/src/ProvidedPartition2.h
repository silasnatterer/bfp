#pragma once

#include <string>
#include "Partition.hpp"
#include "logging/Logger.hpp"
#include "mesh/SharedPointer.hpp"

#include "Mesh2.h"
#include "Partition2.h"

namespace precice {
namespace partition {

/**
 * @brief A partition that is provided by the participant.
 *
 * The participant already provides a partition by calling setMeshVertices etc.
 * If required the mesh needs to be sent to another participant.
 * Furthermore, distribution data structures need to be set up.
 */
class ProvidedPartition2 : public Partition2 {
public:

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  
  ProvidedPartition2(PtrMesh2 mesh);

  virtual ~ProvidedPartition2() {}

  /// The mesh is gathered and sent to another participant (if required)
  void communicate() override;

  /// All distribution data structures are set up.
  void compute() override;

  void compareBoundingBoxes() override;

private:
  void prepare();

  logging::Logger _log{"partition::ProvidedPartition"};
};

} // namespace partition
} // namespace precice
