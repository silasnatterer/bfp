#pragma once

#include <list>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>
#include "logging/Logger.hpp"
#include "mesh/SharedPointer.hpp"
#include "utils/ManageUniqueIDs.hpp"
//#include "xml/XMLTag.hpp"

#include "DataConfiguration2.h"
#include "XMLTag2.h"
#include "Mesh2.h"

namespace precice {
namespace mesh {
class DataConfiguration2;
}
} // namespace precice

// ----------------------------------------------------------- CLASS DEFINITION

namespace precice {
namespace mesh {

class MeshConfiguration2 : public xml::XMLTag2::Listener {
public:

   using PtrDataConfiguration2 = std::shared_ptr<DataConfiguration2>;
   using PtrMesh2              = std::shared_ptr<Mesh2>;
        
   FEModel *fem1;
          
  /// Constructor, takes a valid data configuration as argument.
  MeshConfiguration2(
      xml::XMLTag2 &        parent,
      PtrDataConfiguration2 config, 
      FEModel *fem);

  void setDimensions(int dimensions);

  /// Returns all configured meshes.
  const std::vector<PtrMesh2> &meshes() const;

  /// Returns all configured meshes.
  std::vector<PtrMesh2> &meshes();

  /// Returns the configured mesh with given name, or NULL.
  PtrMesh2 getMesh(const std::string &meshName) const;

  virtual void XMLTagCallback(const xml::ConfigurationContext2 &context, xml::XMLTag2 &callingTag);

  virtual void xmlEndTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);

  const PtrDataConfiguration2 &getDataConfiguration() const;

  void addMesh(const PtrMesh2 &mesh);

  std::map<std::string, std::vector<std::string>> &getNeededMeshes()
  {
    return _neededMeshes;
  }

  void addNeededMesh(
      const std::string &participant,
      const std::string &mesh);

  std::unique_ptr<utils::ManageUniqueIDs> extractMeshIdManager()
  {
    return std::move(_meshIdManager);
  }

private:
  logging::Logger _log{"mesh::MeshConfiguration"};

  const std::string TAG;
  const std::string ATTR_NAME;
  const std::string ATTR_FLIP_NORMALS;
  const std::string TAG_DATA;
  const std::string ATTR_SIDE_INDEX;

  int _dimensions;

  /// Data configuration.
  PtrDataConfiguration2 _dataConfig;

  /// Configured meshes.
  std::vector<PtrMesh2> _meshes;

  /// to check later if all meshes that any coupling scheme needs are actually used by the participants
  std::map<std::string, std::vector<std::string>> _neededMeshes;

  std::unique_ptr<utils::ManageUniqueIDs> _meshIdManager;
};

} // namespace mesh
} // namespace precice
