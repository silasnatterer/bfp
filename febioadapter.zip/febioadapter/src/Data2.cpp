#include "Data2.h"
#include <algorithm>
#include "utils/assertion.hpp"

namespace precice {
namespace mesh {

size_t Data2::_dataCount = 0;

Data2::Data2()
    : _name(""),
      _id(-1),
      _dimensions(0)
{
  PRECICE_ASSERT(false);
}

Data2::Data2(
    const std::string &name,
    int                id,
    int                dimensions)
    : _values(),
      _name(name),
      _id(id),
      _dimensions(dimensions)
{
  PRECICE_ASSERT(dimensions > 0, dimensions);
  _dataCount++;
}

Data2::~Data2()
{
  _dataCount--;
}

Eigen::VectorXd &Data2::values()
{
  return _values;
}

const Eigen::VectorXd &Data2::values() const
{
  return _values;
}

const std::string &Data2::getName() const
{
  return _name;
}

int Data2::getID() const
{
  return _id;
}

void Data2::toZero()
{
  auto begin = _values.data();
  auto end   = begin + _values.size();
  std::fill(begin, end, 0.0);
}

int Data2::getDimensions() const
{
  return _dimensions;
}

size_t Data2::getDataCount()
{
  return _dataCount;
}

void Data2::resetDataCount()
{
  _dataCount = 0;
}

} // namespace mesh
} // namespace precice
