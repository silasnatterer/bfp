#include "DataConfiguration2.h"
#include <ostream>
#include "logging/LogMacros.hpp"
#include "utils/assertion.hpp"
//#include "xml/ConfigParser.hpp"

#include "ConfigParser2.h"

#include "xml/XMLAttribute.hpp"

namespace precice {
namespace mesh {

DataConfiguration2::DataConfiguration2(xml::XMLTag2 &parent, FEModel *fem)
{
  using namespace xml;
  
  fem1 = fem;
    
  std::string doc;
  XMLTag2      tagScalar(*this, VALUE_SCALAR, XMLTag2::OCCUR_ARBITRARY, TAG, fem1);
  doc = "Defines a scalar data set to be assigned to meshes.";
  tagScalar.setDocumentation(doc);
  XMLTag2 tagVector(*this, VALUE_VECTOR, XMLTag2::OCCUR_ARBITRARY, TAG, fem1);
  doc = "Defines a vector data set to be assigned to meshes. The number of ";
  doc += "components of each data entry depends on the spatial dimensions set ";
  doc += "in tag <solver-interface>.";
  tagVector.setDocumentation(doc);

  auto attrName = XMLAttribute<std::string>(ATTR_NAME)
                      .setDocumentation("Unique name for the data set.");
  tagScalar.addAttribute(attrName);
  tagVector.addAttribute(attrName);

  parent.addSubtag(tagScalar);
  parent.addSubtag(tagVector);
}

void DataConfiguration2::setDimensions(
    int dimensions)
{
  PRECICE_TRACE(dimensions);
  PRECICE_ASSERT((dimensions == 2) || (dimensions == 3), dimensions);
  _dimensions = dimensions;
}

const std::vector<DataConfiguration2::ConfiguredData> &
DataConfiguration2::data() const
{
  return _data;
}

DataConfiguration2::ConfiguredData DataConfiguration2::getRecentlyConfiguredData() const
{
  PRECICE_ASSERT(_data.size() > 0);
  PRECICE_ASSERT(_indexLastConfigured >= 0);
  PRECICE_ASSERT(_indexLastConfigured < (int) _data.size());
  return _data[_indexLastConfigured];
}

void DataConfiguration2::XMLTagCallback(
    const xml::ConfigurationContext2 &context,
    xml::XMLTag2 &                    tag)
{
  if (tag.getNamespace() == TAG) {
    PRECICE_ASSERT(_dimensions != 0);
    std::string name           = tag.getStringAttributeValue(ATTR_NAME);
    std::string typeName       = tag.getName();
    int         dataDimensions = getDataDimensions(typeName);
    addData(name, dataDimensions);
  } else {
    PRECICE_ASSERT(false, "Received callback from unknown tag " << tag.getName());
  }
}

void DataConfiguration2::xmlEndTagCallback(
    const xml::ConfigurationContext2 &context,
    xml::XMLTag2 &                    tag)
{
}

void DataConfiguration2::addData(
    const std::string &name,
    int                dataDimensions)
{
  ConfiguredData data(name, dataDimensions);

  // Check if data with same name has been added already
  for (auto &elem : _data) {
    PRECICE_CHECK(elem.name != data.name, "Data \"" << data.name << "\" has already been defined. Please rename or remove one of the data tags with name=\"" << data.name << "\".");
  }
  _data.push_back(data);
}

int DataConfiguration2::getDataDimensions(
    const std::string &typeName) const
{
  if (typeName == VALUE_VECTOR) {
    return _dimensions;
  } else if (typeName == VALUE_SCALAR) {
    return 1;
  }
  PRECICE_ASSERT(false, "Unknown data type \"" << typeName << "\". Known data types: " << VALUE_SCALAR << ", " << VALUE_VECTOR << ".");
}

} // namespace mesh
} // namespace precice
