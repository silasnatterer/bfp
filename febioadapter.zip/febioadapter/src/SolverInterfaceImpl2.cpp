#include "SolverInterfaceImpl2.h"
#include "ConfigParser2.h"


#include <Eigen/Core>
#include <algorithm>
#include <array>
#include <deque>
#include <functional>
#include <iterator>
#include <math.h>
#include <memory>
#include <ostream>
#include <tuple>
#include <utility>
#include "action/SharedPointer.hpp"
#include "com/Communication.hpp"
#include "com/SharedPointer.hpp"
#include "cplscheme/CouplingScheme.hpp"
//#include "cplscheme/config/CouplingSchemeConfiguration.hpp"

#include "CouplingSchemeConfiguration2.h"

#include "io/Export.hpp"
#include "io/ExportContext.hpp"
#include "io/SharedPointer.hpp"
#include "logging/LogConfiguration.hpp"
#include "logging/LogMacros.hpp"
#include "m2n/BoundM2N.hpp"
//#include "m2n/M2N.hpp"

#include "M2N2.h"

#include "m2n/SharedPointer.hpp"
//#include "m2n/config/M2NConfiguration.hpp"

#include "M2NConfiguration2.h"

#include "mapping/Mapping.hpp"
#include "mapping/SharedPointer.hpp"
//#include "mapping/config/MappingConfiguration.hpp"

#include "MappingConfiguration2.h"

#include "math/differences.hpp"
#include "math/geometry.hpp"
//#include "mesh/Data.hpp"

#include "Data2.h"

#include "mesh/Edge.hpp"
//#include "mesh/Mesh.hpp"

#include "Mesh2.h"

#include "mesh/SharedPointer.hpp"
#include "mesh/Utils.hpp"
#include "mesh/Vertex.hpp"
//#include "mesh/config/MeshConfiguration.hpp"

#include "MeshConfiguration2.h"

//#include "partition/Partition.hpp"
//#include "partition/ProvidedPartition.hpp"
//#include "partition/ReceivedPartition.hpp"
#include "partition/SharedPointer.hpp"
//#include "precice/config/Configuration.hpp"

#include "Configuration2.h"

//#include "precice/config/ParticipantConfiguration.hpp"

#include "ParticipantConfiguration2.h"

#include "precice/config/SharedPointer.hpp"
#include "precice/config/SolverInterfaceConfiguration.hpp"
#include "precice/impl/CommonErrorMessages.hpp"
//#include "precice/impl/DataContext.hpp"

#include "DataContext2.h"

//#include "precice/impl/MappingContext.hpp"

#include "MappingContext2.h"

//#include "precice/impl/MeshContext.hpp"

#include "MeshContext2.h"

//#include "precice/impl/Participant.hpp"

#include "Participant2.h"

#include "precice/impl/ValidationMacros.hpp"
#include "precice/impl/WatchPoint.hpp"
#include "precice/impl/versions.hpp"
#include "utils/EigenHelperFunctions.hpp"
#include "utils/Event.hpp"
#include "utils/EventUtils.hpp"
#include "utils/Helpers.hpp"
#include "utils/MasterSlave.hpp"
#include "utils/Parallel.hpp"
//#include "utils/Petsc.hpp"
#include "utils/PointerVector.hpp"
#include "utils/algorithm.hpp"
#include "utils/assertion.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"
#include "Event2.h"
#include "MasterSlave2.h"
#include "MeshContext2.h"
#include "ProvidedPartition2.h"
#include "ReceivedPartition2.h"
#include "Partition2.h"

//#include "xml/ConfigParser.hpp"

#ifndef PRECICE_NO_MPI
#include <mpi.h>
#endif // not PRECICE_NO_MPI

using precice::utils::Event2;
using precice::utils::EventRegistry;

namespace precice {

/// Enabled further inter- and intra-solver synchronisation
bool syncMode = false;

namespace impl {

using PtrParticipant2 = std::shared_ptr<precice::impl::Participant2>;
using PtrPartition2 = std::shared_ptr<precice::partition::Partition2>;
using PtrM2N2 = std::shared_ptr<precice::m2n::M2N2>;
using PtrCouplingSchemeConfiguration2 = std::shared_ptr<precice::cplscheme::CouplingSchemeConfiguration2>;
using PtrMeshConfiguration2 = std::shared_ptr<precice::mesh::MeshConfiguration2>;
using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
using PtrData2 = std::shared_ptr<precice::mesh::Data2>;
          
SolverInterfaceImpl2::SolverInterfaceImpl2(FEModel *fem) 
{
    write_log(fem, 3,"inside");
}

SolverInterfaceImpl2::SolverInterfaceImpl2(
    std::string        participantName,
    const std::string &configurationFileName,
    int                accessorProcessRank,
    int                accessorCommunicatorSize,
    void *             communicator,
    FEModel *fem)
      : _accessorName(std::move(participantName)),
        _accessorProcessRank(accessorProcessRank),
        _accessorCommunicatorSize(accessorCommunicatorSize)
{
  

  PRECICE_CHECK(!_accessorName.empty(), "This participant's name is an empty string. When constructing a preCICE interface "
                                        "you need to pass the name of the participant as first argument to the constructor.");
  PRECICE_CHECK(_accessorProcessRank >= 0,
                "The solver process index needs to be a non-negative number, not: "
                    << _accessorProcessRank << ". Please check the value given when constructing a preCICE interface.");
  PRECICE_CHECK(_accessorCommunicatorSize >= 1,
                "The solver process size needs to be a positive number, not: "
                    << _accessorCommunicatorSize << ". Please check the value given when constructing a preCICE interface.");
  PRECICE_CHECK(_accessorProcessRank < _accessorCommunicatorSize,
                "The solver process index, currently: "
                    << _accessorProcessRank
                    << " needs to be smaller than the solver process size, currently: " << _accessorCommunicatorSize
                    << ". Please check the values given when constructing a preCICE interface.");

	fem1 = fem;
	write_log(fem1, 3,"here precice");

// Set the global communicator to the passed communicator.
// This is a noop if preCICE is not configured with MPI.
// nullpointer signals to use MPI_COMM_WORLD
#ifndef PRECICE_NO_MPI
  if (communicator != nullptr) {
    auto commptr = static_cast<utils::Parallel::Communicator *>(communicator);
    utils::Parallel::registerUserProvidedComm(*commptr);
  }
#endif

	write_log(fem, 3,"here precice2");

  logging::setParticipant(_accessorName);

  configure(configurationFileName);

// This block cannot be merge with the one above as only configure calls
// utils::Parallel::initializeMPI, which is needed for getProcessRank.
#ifndef PRECICE_NO_MPI
  if (communicator != nullptr) {
    const auto currentRank = utils::Parallel::current()->rank();
    PRECICE_CHECK(_accessorProcessRank == currentRank,
                  "The solver process index given in the preCICE interface constructor("
                      << _accessorProcessRank << ") does not match the rank of the passed MPI communicator ("
                      << currentRank << ").");
    const auto currentSize = utils::Parallel::current()->size();
    PRECICE_CHECK(_accessorCommunicatorSize == currentSize,
                  "The solver process size given in the preCICE interface constructor("
                      << _accessorCommunicatorSize << ") does not match the size of the passed MPI communicator ("
                      << currentSize << ").");
  }
#endif

	write_log(fem, 3,"here precice3");


}

/*
SolverInterfaceImpl2::SolverInterfaceImpl2(
    std::string        participantName,
    const std::string &configurationFileName,
    int                accessorProcessRank,
    int                accessorCommunicatorSize)
    : SolverInterfaceImpl2::SolverInterfaceImpl2(std::move(participantName), configurationFileName, accessorProcessRank, accessorCommunicatorSize, nullptr)
{
}
 
SolverInterfaceImpl2::~SolverInterfaceImpl2()
{
  if (_state != State::Finalized) {
    PRECICE_INFO("Implicitly finalizing in destructor");
    finalize();
  }
}
*/

void SolverInterfaceImpl2::configure(
    const std::string &configurationFileName)
{


  write_log(fem1, 3,"here precice 4.0");

  config::Configuration2 config(fem1);
  
   write_log(fem1, 3,"here precice 4.1.0");
  
   
   utils::Parallel::initializeManagedMPI(nullptr, nullptr);
  /*
   write_log(fem1, 3,"here precice 4.1.1");
   
  //logging::setMPIRank(utils::Parallel::current()->rank());
  
   write_log(fem1, 3,"here precice 4.1.2");
   */
   
  xml::ConfigurationContext2 context{
      _accessorName,
      _accessorProcessRank,
      _accessorCommunicatorSize};
      
      write_log(fem1, 3,"here precice 4.1");
      
  xml::configure(config.getXMLTag(), context, configurationFileName, fem1);
  
  
  write_log(fem1, 3,"here precice after");
  
  if (_accessorProcessRank == 0) {
    PRECICE_INFO("This is preCICE version " << PRECICE_VERSION);
    PRECICE_INFO("Revision info: " << precice::preciceRevision);
    PRECICE_INFO("Configuring preCICE with configuration \"" << configurationFileName << "\"");
    PRECICE_INFO("I am participant \"" << _accessorName << "\"");
  }
  
  write_log(fem1, 3,"here precice 4");
  
  configure(config.getSolverInterfaceConfiguration());
  
}

void SolverInterfaceImpl2::configure(
    const precice::config::SolverInterfaceConfiguration2 &config)
{
  PRECICE_TRACE();
  
  write_log(fem1, 3,"here precice 5");
  
   
  Event2                    e("configure"); // no precice::syncMode as this is not yet configured here
  utils::ScopedEventPrefix sep("configure/");

  //mesh::Data::resetDataCount();
  _meshLock.clear();

  _dimensions = config.getDimensions();
  _accessor   = determineAccessingParticipant(config);
  _accessor->setMeshIdManager(config.getMeshConfiguration()->extractMeshIdManager());
  
    write_log(fem1, 3,"here precice 6");
    
    
  
  PRECICE_ASSERT(_accessorCommunicatorSize == 1 || _accessor->useMaster(),
                 "A parallel participant needs a master communication");
  PRECICE_CHECK(not(_accessorCommunicatorSize == 1 && _accessor->useMaster()),
                "You cannot use a master communication with a serial participant. "
                "If you do not know exactly what a master communication is and why you want to use it "
                "you probably just want to remove the master tag from the preCICE configuration.");

  utils::MasterSlave2::configure(_accessorProcessRank, _accessorCommunicatorSize);

  _participants = config.getParticipantConfiguration()->getParticipants();
  
   write_log(fem1, 3,"here precice 6.5");
   
  configureM2Ns(config.getM2NConfiguration());

  PRECICE_CHECK(_participants.size() > 1, "In the preCICE configuration, only one participant is defined. "
                                          "One participant makes no coupled simulation. Please add at least "
                                          "another one.");
                                          
  write_log(fem1, 3,"here precice 7");
                                           
  configurePartitions(config.getM2NConfiguration());

  PtrCouplingSchemeConfiguration2 cplSchemeConfig =
      config.getCouplingSchemeConfiguration();
  _couplingScheme = cplSchemeConfig->getCouplingScheme(_accessorName);

  // Add meshIDs and data IDs
  for (const MeshContext2 *meshContext : _accessor->usedMeshContexts()) {
    const PtrMesh2 &mesh   = meshContext->mesh;
    const auto           meshID = mesh->getID();
    _meshIDs[mesh->getName()]   = meshID;
    PRECICE_ASSERT(_dataIDs.find(meshID) == _dataIDs.end());
    _dataIDs[meshID] = std::map<std::string, int>();
    PRECICE_ASSERT(_dataIDs.find(meshID) != _dataIDs.end());
    for (const PtrData2 &data : mesh->data()) {
      PRECICE_ASSERT(_dataIDs[meshID].find(data->getName()) == _dataIDs[meshID].end());
      _dataIDs[meshID][data->getName()] = data->getID();
    }
    std::string                meshName   = mesh->getName();
    PtrMeshConfiguration2 meshConfig = config.getMeshConfiguration();
  }
  
   write_log(fem1, 3,"here precice 8");
   
  // Register all MeshIds to the lock, but unlock them straight away as
  // writing is allowed after configuration.
  for (const auto &meshID : _meshIDs) {
    _meshLock.add(meshID.second, false);
  }

  utils::EventRegistry::instance().initialize("precice-" + _accessorName, "", utils::Parallel::current()->comm);

  PRECICE_DEBUG("Initialize master-slave communication");
  if (utils::MasterSlave2::isMaster() || utils::MasterSlave2::isSlave()) {
    initializeMasterSlaveCommunication();
  }

  auto &solverInitEvent = EventRegistry::instance().getStoredEvent("solver.initialize");
  solverInitEvent.start(precice::syncMode);
  
   write_log(fem1, 3,"here precice 9");
}

double SolverInterfaceImpl2::initialize()
{

   write_log(fem1, 3,"here precice inside intialize 1.0");
   
  PRECICE_TRACE();
  PRECICE_CHECK(_state != State::Finalized, "initialize() cannot be called after finalize().")
  PRECICE_CHECK(_state != State::Initialized, "initialize() may only be called once.");
  PRECICE_ASSERT(not _couplingScheme->isInitialized());
  auto &solverInitEvent = EventRegistry::instance().getStoredEvent("solver.initialize");
  solverInitEvent.pause(precice::syncMode);
  Event2                    e("initialize", precice::syncMode);
  utils::ScopedEventPrefix sep("initialize/");

  // Setup communication

   write_log(fem1, 3,"here precice inside intialize 2.0");
   
  PRECICE_INFO("Setting up master communication to coupling partner/s");
  for (auto &m2nPair : _m2ns) {
    auto &bm2n = m2nPair.second;
    PRECICE_DEBUG((bm2n.isRequesting ? "Awaiting master connection from " : "Establishing master connection to ") << bm2n.remoteName);
    bm2n.prepareEstablishment();
    
       write_log(fem1, 3,"here precice inside intialize 2.1");
    
    bm2n.connectMasters();
    PRECICE_DEBUG("Established master connection " << (bm2n.isRequesting ? "from " : "to ") << bm2n.remoteName);
  }

  PRECICE_INFO("Masters are connected");

   write_log(fem1, 3,"here precice inside intialize 3.0");
   
  compareBoundingBoxes();

  PRECICE_INFO("Setting up preliminary slaves communication to coupling partner/s");
  for (auto &m2nPair : _m2ns) {
    auto &bm2n = m2nPair.second;
    bm2n.preConnectSlaves();
  }

   write_log(fem1, 3,"here precice inside intialize 4.0");
   
  computePartitions();

  PRECICE_INFO("Setting up slaves communication to coupling partner/s");
  for (auto &m2nPair : _m2ns) {
    auto &bm2n = m2nPair.second;
    bm2n.connectSlaves();
    PRECICE_DEBUG("Established slaves connection " << (bm2n.isRequesting ? "from " : "to ") << bm2n.remoteName);
  }
  PRECICE_INFO("Slaves are connected");

   write_log(fem1, 3,"here precice inside intialize 5.0");
   
  for (auto &m2nPair : _m2ns) {
    m2nPair.second.cleanupEstablishment();
  }

  PRECICE_DEBUG("Initialize watchpoints");
  for (PtrWatchPoint &watchPoint : _accessor->watchPoints()) {
    watchPoint->initialize();
  }

  // Initialize coupling state, overwrite these values for restart
  double time       = 0.0;
  int    timeWindow = 1;

  PRECICE_DEBUG("Initialize coupling schemes");
  _couplingScheme->initialize(time, timeWindow);
  PRECICE_ASSERT(_couplingScheme->isInitialized());

  double dt = 0.0;

   write_log(fem1, 3,"here precice inside intialize 6.0");
   
  dt = _couplingScheme->getNextTimestepMaxLength();

  if (_couplingScheme->hasDataBeenReceived()) {
    performDataActions({action::Action::READ_MAPPING_PRIOR}, 0.0, 0.0, 0.0, dt);
    
       write_log(fem1, 3,"here precice inside intialize 6.1");
    
    mapReadData();
    
       write_log(fem1, 3,"here precice inside intialize 6.2");
       
    performDataActions({action::Action::READ_MAPPING_POST}, 0.0, 0.0, 0.0, dt);
  }

  PRECICE_INFO(_couplingScheme->printCouplingState());

  solverInitEvent.start(precice::syncMode);

  _meshLock.lockAll();

  _state = State::Initialized;
  
     write_log(fem1, 3,"here precice inside intialize 7.0");

  return _couplingScheme->getNextTimestepMaxLength();
}

void SolverInterfaceImpl2::initializeData()
{

   write_log(fem1, 3,"here precice inside intializadata 1.0");
   
  PRECICE_TRACE();
  PRECICE_CHECK(!_hasInitializedData, "initializeData() may only be called once.");
  PRECICE_CHECK(_state != State::Finalized, "initializeData() cannot be called after finalize().")
  PRECICE_CHECK(_state == State::Initialized, "initialize() has to be called before initializeData()");
  PRECICE_ASSERT(_couplingScheme->isInitialized());
  PRECICE_CHECK(not(_couplingScheme->sendsInitializedData() && isActionRequired(constants::actionWriteInitialData())),
                "Initial data has to be written to preCICE by calling an appropriate write...Data() function before calling initializeData(). "
                "Did you forget to call markActionFulfilled(precice::constants::actionWriteInitialData()) after writing initial data?");

   write_log(fem1, 3,"here precice inside intializadata 2.0");
   
  auto &solverInitEvent = EventRegistry::instance().getStoredEvent("solver.initialize");
  solverInitEvent.pause(precice::syncMode);

  Event2                    e("initializeData", precice::syncMode);
  utils::ScopedEventPrefix sep("initializeData/");

  PRECICE_DEBUG("Initialize data");
  double dt = _couplingScheme->getNextTimestepMaxLength();

   write_log(fem1, 3,"here precice inside intializadata 3.0");
   
  performDataActions({action::Action::WRITE_MAPPING_PRIOR}, 0.0, 0.0, 0.0, dt);
  mapWrittenData();
  performDataActions({action::Action::WRITE_MAPPING_POST}, 0.0, 0.0, 0.0, dt);

   write_log(fem1, 3,"here precice inside intializadata 4.0");
   
  _couplingScheme->initializeData();
  
     write_log(fem1, 3,"here precice inside intializadata 5.0");

  if (_couplingScheme->hasDataBeenReceived()) {
    performDataActions({action::Action::READ_MAPPING_PRIOR}, 0.0, 0.0, 0.0, dt);
    mapReadData();
    performDataActions({action::Action::READ_MAPPING_POST}, 0.0, 0.0, 0.0, dt);
  }
  
     write_log(fem1, 3,"here precice inside intializadata 6.0");
  
  resetWrittenData();
  PRECICE_DEBUG("Plot output");
  for (const io::ExportContext &context : _accessor->exportContexts()) {
    if (context.everyNTimeWindows != -1) {
      std::ostringstream suffix;
      suffix << _accessorName << ".init";
      //exportMesh(suffix.str());						//auskommentiert
      if (context.triggerSolverPlot) {
        _couplingScheme->requireAction(std::string("plot-output"));
      }
    }
  }
  solverInitEvent.start(precice::syncMode);

  _hasInitializedData = true;
  
     write_log(fem1, 3,"here precice inside intializadata 7.0");
     
}

double SolverInterfaceImpl2::advance(
    double computedTimestepLength)
{

  PRECICE_TRACE(computedTimestepLength);

  // Events for the solver time, stopped when we enter, restarted when we leave advance
  auto &solverEvent = EventRegistry::instance().getStoredEvent("solver.advance");
  solverEvent.stop(precice::syncMode);
  auto &solverInitEvent = EventRegistry::instance().getStoredEvent("solver.initialize");
  solverInitEvent.stop(precice::syncMode);

  Event2                    e("advance", precice::syncMode);
  utils::ScopedEventPrefix sep("advance/");

  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before advance().");
  PRECICE_CHECK(_state != State::Finalized, "advance() cannot be called after finalize().")
  PRECICE_ASSERT(_couplingScheme->isInitialized());
  PRECICE_CHECK(isCouplingOngoing(), "advance() cannot be called when isCouplingOngoing() returns false.");
  PRECICE_CHECK((not _couplingScheme->receivesInitializedData() && not _couplingScheme->sendsInitializedData()) || (_hasInitializedData),
                "initializeData() needs to be called before advance if data has to be initialized.");
  _numberAdvanceCalls++;

#ifndef NDEBUG
  PRECICE_DEBUG("Synchronize timestep length");
  if (utils::MasterSlave2::isMaster() || utils::MasterSlave2::isSlave()) {
    syncTimestep(computedTimestepLength);
  }
#endif

  double timeWindowSize         = 0.0; // Length of (full) current time window
  double timeWindowComputedPart = 0.0; // Length of computed part of (full) current time window
  double time                   = 0.0; // Current time

  // Update the coupling scheme time state. Necessary to get correct remainder.
  _couplingScheme->addComputedTime(computedTimestepLength);

  if (_couplingScheme->hasTimeWindowSize()) {
    timeWindowSize = _couplingScheme->getTimeWindowSize();
  } else {
    timeWindowSize = computedTimestepLength;
  }
  timeWindowComputedPart = timeWindowSize - _couplingScheme->getThisTimeWindowRemainder();
  time                   = _couplingScheme->getTime();

  if (_couplingScheme->willDataBeExchanged(0.0)) {
    performDataActions({action::Action::WRITE_MAPPING_PRIOR}, time, computedTimestepLength, timeWindowComputedPart, timeWindowSize);
    mapWrittenData();
    performDataActions({action::Action::WRITE_MAPPING_POST}, time, computedTimestepLength, timeWindowComputedPart, timeWindowSize);
  }

  PRECICE_DEBUG("Advance coupling scheme");
  _couplingScheme->advance();

  if (_couplingScheme->hasDataBeenReceived()) {
    performDataActions({action::Action::READ_MAPPING_PRIOR}, time, computedTimestepLength, timeWindowComputedPart, timeWindowSize);
    mapReadData();
    performDataActions({action::Action::READ_MAPPING_POST}, time, computedTimestepLength, timeWindowComputedPart, timeWindowSize);
  }

  if (_couplingScheme->isTimeWindowComplete()) {
    performDataActions({action::Action::ON_TIME_WINDOW_COMPLETE_POST}, time, computedTimestepLength, timeWindowComputedPart, timeWindowSize);
  }

  PRECICE_INFO(_couplingScheme->printCouplingState());

  PRECICE_DEBUG("Handle exports");
  handleExports();

  resetWrittenData();

  _meshLock.lockAll();
  solverEvent.start(precice::syncMode);
  return _couplingScheme->getNextTimestepMaxLength();
}

void SolverInterfaceImpl2::finalize()
{
  PRECICE_TRACE();
  PRECICE_CHECK(_state != State::Finalized, "finalize() may only be called once.")

  // Events for the solver time, finally stopped here
  auto &solverEvent = EventRegistry::instance().getStoredEvent("solver.advance");
  solverEvent.stop(precice::syncMode);

  Event2                    e("finalize"); // no precice::syncMode here as MPI is already finalized at destruction of this event
  utils::ScopedEventPrefix sep("finalize/");

  if (_state == State::Initialized) {

    PRECICE_ASSERT(_couplingScheme->isInitialized());
    PRECICE_DEBUG("Finalize coupling scheme");
    _couplingScheme->finalize();

    PRECICE_DEBUG("Handle exports");
    for (const io::ExportContext &context : _accessor->exportContexts()) {
      if (context.everyNTimeWindows != -1) {
        std::ostringstream suffix;
        suffix << _accessorName << ".final";
        //exportMesh(suffix.str());						/auskommentiert
        if (context.triggerSolverPlot) {
          _couplingScheme->requireAction(std::string("plot-output"));
        }
      }
    }
    // Apply some final ping-pong to synch solver that run e.g. with a uni-directional coupling only
    // afterwards close connections
    PRECICE_DEBUG("Synchronize participants and close communication channels");
    std::string ping = "ping";
    std::string pong = "pong";
    for (auto &iter : _m2ns) {
      if (not utils::MasterSlave2::isSlave()) {
        if (iter.second.isRequesting) {
          iter.second.m2n->getMasterCommunication()->send(ping, 0);
          std::string receive = "init";
          iter.second.m2n->getMasterCommunication()->receive(receive, 0);
          PRECICE_ASSERT(receive == pong);
        } else {
          std::string receive = "init";
          iter.second.m2n->getMasterCommunication()->receive(receive, 0);
          PRECICE_ASSERT(receive == ping);
          iter.second.m2n->getMasterCommunication()->send(pong, 0);
        }
      }
      iter.second.m2n->closeConnection();
    }
  }

  // Release ownership
  _couplingScheme.reset();
  _participants.clear();
  _accessor.reset();

  // Close Connections
  PRECICE_DEBUG("Close master-slave communication");
  if (utils::MasterSlave2::isSlave() || utils::MasterSlave2::isMaster()) {
    utils::MasterSlave2::_communication->closeConnection();
    utils::MasterSlave2::_communication = nullptr;
  }
  _m2ns.clear();

  // Stop and print Event logging
  e.stop();

  // Finalize PETSc and Events first
  //utils::Petsc::finalize();
  utils::EventRegistry::instance().finalize();

  // Printing requires finalization
  if (not precice::utils::MasterSlave2::isSlave()) {
    utils::EventRegistry::instance().printAll();
  }

  // Finally clear events and finalize MPI
  utils::EventRegistry::instance().clear();
  utils::Parallel::finalizeManagedMPI();
  _state = State::Finalized;
}

int SolverInterfaceImpl2::getDimensions() const
{
  PRECICE_TRACE(_dimensions);
  return _dimensions;
}

bool SolverInterfaceImpl2::isCouplingOngoing() const
{
  PRECICE_TRACE();
  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before isCouplingOngoing() can be evaluated.");
  PRECICE_CHECK(_state != State::Finalized, "isCouplingOngoing() cannot be called after finalize().");
  return _couplingScheme->isCouplingOngoing();
}

bool SolverInterfaceImpl2::isReadDataAvailable() const
{
  PRECICE_TRACE();
  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before isReadDataAvailable().");
  PRECICE_CHECK(_state != State::Finalized, "isReadDataAvailable() cannot be called after finalize().");
  return _couplingScheme->hasDataBeenReceived();
}

bool SolverInterfaceImpl2::isWriteDataRequired(
    double computedTimestepLength) const
{
  PRECICE_TRACE(computedTimestepLength);
  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before isWriteDataRequired().");
  PRECICE_CHECK(_state != State::Finalized, "isWriteDataRequired() cannot be called after finalize().");
  return _couplingScheme->willDataBeExchanged(computedTimestepLength);
}

bool SolverInterfaceImpl2::isTimeWindowComplete() const
{
  PRECICE_TRACE();
  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before isTimeWindowComplete().");
  PRECICE_CHECK(_state != State::Finalized, "isTimeWindowComplete() cannot be called after finalize().");
  return _couplingScheme->isTimeWindowComplete();
}

bool SolverInterfaceImpl2::isActionRequired(
    const std::string &action) const
{
  PRECICE_TRACE(action, _couplingScheme->isActionRequired(action));
  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before isActionRequired(...).");
  PRECICE_CHECK(_state != State::Finalized, "isActionRequired(...) cannot be called after finalize().");
  return _couplingScheme->isActionRequired(action);
}

void SolverInterfaceImpl2::markActionFulfilled(
    const std::string &action)
{
  PRECICE_TRACE(action);
  PRECICE_CHECK(_state != State::Constructed, "initialize() has to be called before markActionFulfilled(...).");
  PRECICE_CHECK(_state != State::Finalized, "markActionFulfilled(...) cannot be called after finalize().");
  _couplingScheme->markActionFulfilled(action);
}

bool SolverInterfaceImpl2::hasToEvaluateSurrogateModel() const
{
  return false;
}

bool SolverInterfaceImpl2::hasToEvaluateFineModel() const
{
  return true;
}

bool SolverInterfaceImpl2::hasMesh(
    const std::string &meshName) const
{
  PRECICE_TRACE(meshName);
  return utils::contained(meshName, _meshIDs);
}

int SolverInterfaceImpl2::getMeshID(
    const std::string &meshName) const
{
  PRECICE_TRACE(meshName);
  const auto pos = _meshIDs.find(meshName);
  PRECICE_CHECK(pos != _meshIDs.end(), "The given mesh name \"" << meshName << "\" is unknown to preCICE. Please check the mesh definitions in the configuration.");
  return pos->second;
}

std::set<int> SolverInterfaceImpl2::getMeshIDs() const
{
  PRECICE_TRACE();
  std::set<int> ids;
  for (const impl::MeshContext2 *context : _accessor->usedMeshContexts()) {
    ids.insert(context->mesh->getID());
  }
  return ids;
}

bool SolverInterfaceImpl2::hasData(
    const std::string &dataName, int meshID) const
{
  PRECICE_TRACE(dataName, meshID);
  PRECICE_VALIDATE_MESH_ID(meshID);
  const auto &sub_dataIDs = _dataIDs.at(meshID);
  return sub_dataIDs.find(dataName) != sub_dataIDs.end();
}

int SolverInterfaceImpl2::getDataID(
    const std::string &dataName, int meshID) const
{
  PRECICE_TRACE(dataName, meshID);
  PRECICE_VALIDATE_MESH_ID(meshID);
  impl::MeshContext2 &context = _accessor->meshContext(meshID);
  PRECICE_CHECK(hasData(dataName, meshID),
                "Data with name \"" << dataName << "\" is not defined on mesh \"" << context.mesh->getName() << "\". "
                                    << "Please add <use-data name=\"" << dataName << "\"/> under <mesh name=\"" << context.mesh->getName() << "\"/>.");
  return _dataIDs.at(meshID).at(dataName);
}

int SolverInterfaceImpl2::getMeshVertexSize(
    int meshID) const
{
  PRECICE_TRACE(meshID);
  int size = 0;
  //PRECICE_REQUIRE_MESH_USE(meshID);
  MeshContext2 &context = _accessor->meshContext(meshID);
  PRECICE_ASSERT(context.mesh.get() != nullptr);
  size = context.mesh->vertices().size();
  PRECICE_DEBUG("Return mesh size of " << size);
  return size;
}

/// @todo Currently not supported as we would need to re-compute the re-partition
void SolverInterfaceImpl2::resetMesh(
    int meshID)
{
  PRECICE_TRACE(meshID);
  PRECICE_VALIDATE_MESH_ID(meshID);
  impl::MeshContext2 &context = _accessor->meshContext(meshID);
  /*
  bool               hasMapping = context.fromMappingContext.mapping || context.toMappingContext.mapping;
  bool               isStationary =
      context.fromMappingContext.timing == mapping::MappingConfiguration::INITIAL &&
      context.toMappingContext.timing == mapping::MappingConfiguration::INITIAL;
  */

  PRECICE_DEBUG("Clear mesh positions for mesh \"" << context.mesh->getName() << "\"");
  _meshLock.unlock(meshID);
  context.mesh->clear();
}

int SolverInterfaceImpl2::setMeshVertex(
    int           meshID,
    const double *position)
{
  PRECICE_TRACE(meshID);
  Eigen::VectorXd internalPosition{
      Eigen::Map<const Eigen::VectorXd>{position, _dimensions}};
  PRECICE_DEBUG("Position = " << internalPosition);
  int index = -1;
  //PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext2 & context = _accessor->meshContext(meshID);
  PtrMesh2 mesh(context.mesh);
  PRECICE_DEBUG("MeshRequirement: " << context.meshRequirement);
  index = mesh->createVertex(internalPosition).getID();
  mesh->allocateDataValues();
  return index;
}

void SolverInterfaceImpl2::setMeshVertices(
    int           meshID,
    int           size,
    const double *positions,
    int *         ids)
{
  PRECICE_TRACE(meshID, size);
  //PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext2 & context = _accessor->meshContext(meshID);
  PtrMesh2 mesh(context.mesh);
  PRECICE_DEBUG("Set positions");
  const Eigen::Map<const Eigen::MatrixXd> posMatrix{
      positions, _dimensions, static_cast<EIGEN_DEFAULT_DENSE_INDEX_TYPE>(size)};
  for (int i = 0; i < size; ++i) {
    Eigen::VectorXd current(posMatrix.col(i));
    ids[i] = mesh->createVertex(current).getID();
  }
  mesh->allocateDataValues();
}

void SolverInterfaceImpl2::getMeshVertices(
    int        meshID,
    size_t     size,
    const int *ids,
    double *   positions) const
{
  PRECICE_TRACE(meshID, size);
  //PRECICE_REQUIRE_MESH_USE(meshID);
  MeshContext2 & context = _accessor->meshContext(meshID);
  PtrMesh2 mesh(context.mesh);
  PRECICE_DEBUG("Get positions");
  auto &vertices = mesh->vertices();
  PRECICE_ASSERT(size <= vertices.size(), size, vertices.size());
  Eigen::Map<Eigen::MatrixXd> posMatrix{
      positions, _dimensions, static_cast<EIGEN_DEFAULT_DENSE_INDEX_TYPE>(size)};
  for (size_t i = 0; i < size; i++) {
    const size_t id = ids[i];
    PRECICE_ASSERT(id < vertices.size(), id, vertices.size());
    posMatrix.col(i) = vertices[id].getCoords();
  }
}

void SolverInterfaceImpl2::getMeshVertexIDsFromPositions(
    int           meshID,
    size_t        size,
    const double *positions,
    int *         ids) const
{
  PRECICE_TRACE(meshID, size);
  //PRECICE_REQUIRE_MESH_USE(meshID);
  MeshContext2 & context = _accessor->meshContext(meshID);
  PtrMesh2 mesh(context.mesh);
  PRECICE_DEBUG("Get IDs");
  const auto &                      vertices = mesh->vertices();
  Eigen::Map<const Eigen::MatrixXd> posMatrix{
      positions, _dimensions, static_cast<EIGEN_DEFAULT_DENSE_INDEX_TYPE>(size)};
  const auto vsize = vertices.size();
  for (size_t i = 0; i < size; i++) {
    size_t j = 0;
    for (; j < vsize; j++) {
      if (math::equals(posMatrix.col(i), vertices[j].getCoords())) {
        break;
      }
    }
    if (j == vsize) {
      std::ostringstream err;
      err << "Unable to find a vertex on mesh \"" << mesh->getName() << "\" at position (";
      err << posMatrix.col(i)[0] << ", " << posMatrix.col(i)[1];
      if (_dimensions == 3) {
        err << ", " << posMatrix.col(i)[2];
      }
      err << "). The request failed for query " << i + 1 << " out of " << size << '.';
      PRECICE_ERROR(err.str());
    }
    ids[i] = j;
  }
}
/*
int SolverInterfaceImpl2::setMeshEdge(
    int meshID,
    int firstVertexID,
    int secondVertexID)
{
  PRECICE_TRACE(meshID, firstVertexID, secondVertexID);
  PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext &context = _accessor->meshContext(meshID);
  if (context.meshRequirement == mapping::Mapping::MeshRequirement::FULL) {
    mesh::PtrMesh &mesh = context.mesh;
    using impl::errorInvalidVertexID;
    PRECICE_CHECK(mesh->isValidVertexID(firstVertexID), errorInvalidVertexID(firstVertexID));
    PRECICE_CHECK(mesh->isValidVertexID(secondVertexID), errorInvalidVertexID(secondVertexID));
    mesh::Vertex &v0 = mesh->vertices()[firstVertexID];
    mesh::Vertex &v1 = mesh->vertices()[secondVertexID];
    return mesh->createEdge(v0, v1).getID();
  }
  return -1;
}

void SolverInterfaceImpl2::setMeshTriangle(
    int meshID,
    int firstEdgeID,
    int secondEdgeID,
    int thirdEdgeID)
{
  PRECICE_TRACE(meshID, firstEdgeID,
                secondEdgeID, thirdEdgeID);
  PRECICE_CHECK(_dimensions == 3, "setMeshTriangle is only possible for 3D cases."
                                  " Please set the dimension to 3 in the preCICE configuration file.");
  PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext &context = _accessor->meshContext(meshID);
  if (context.meshRequirement == mapping::Mapping::MeshRequirement::FULL) {
    mesh::PtrMesh &mesh = context.mesh;
    using impl::errorInvalidEdgeID;
    PRECICE_CHECK(mesh->isValidEdgeID(firstEdgeID), errorInvalidEdgeID(firstEdgeID));
    PRECICE_CHECK(mesh->isValidEdgeID(secondEdgeID), errorInvalidEdgeID(secondEdgeID));
    PRECICE_CHECK(mesh->isValidEdgeID(thirdEdgeID), errorInvalidEdgeID(thirdEdgeID));
    PRECICE_CHECK(utils::unique_elements(utils::make_array(firstEdgeID, secondEdgeID, thirdEdgeID)),
                  "setMeshTriangle() was called with repeated Edge IDs (" << firstEdgeID << ',' << secondEdgeID << ',' << thirdEdgeID << ").");
    mesh::Edge &e0 = mesh->edges()[firstEdgeID];
    mesh::Edge &e1 = mesh->edges()[secondEdgeID];
    mesh::Edge &e2 = mesh->edges()[thirdEdgeID];
    PRECICE_CHECK(e0.connectedTo(e1) && e1.connectedTo(e2) && e2.connectedTo(e0),
                  "setMeshTriangle() was called with Edge IDs ("
                      << firstEdgeID << ',' << secondEdgeID << ',' << thirdEdgeID
                      << "), which identify unconnected Edges.");
    mesh->createTriangle(e0, e1, e2);
  }
}

void SolverInterfaceImpl2::setMeshTriangleWithEdges(
    int meshID,
    int firstVertexID,
    int secondVertexID,
    int thirdVertexID)
{
  PRECICE_TRACE(meshID, firstVertexID,
                secondVertexID, thirdVertexID);
  PRECICE_CHECK(_dimensions == 3, "setMeshTriangleWithEdges is only possible for 3D cases."
                                  " Please set the dimension to 3 in the preCICE configuration file.");
  PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext &context = _accessor->meshContext(meshID);
  if (context.meshRequirement == mapping::Mapping::MeshRequirement::FULL) {
    mesh::PtrMesh &mesh = context.mesh;
    using impl::errorInvalidVertexID;
    PRECICE_CHECK(mesh->isValidVertexID(firstVertexID), errorInvalidVertexID(firstVertexID));
    PRECICE_CHECK(mesh->isValidVertexID(secondVertexID), errorInvalidVertexID(secondVertexID));
    PRECICE_CHECK(mesh->isValidVertexID(thirdVertexID), errorInvalidVertexID(thirdVertexID));
    PRECICE_CHECK(utils::unique_elements(utils::make_array(firstVertexID, secondVertexID, thirdVertexID)),
                  "setMeshTriangleWithEdges() was called with repeated Vertex IDs (" << firstVertexID << ',' << secondVertexID << ',' << thirdVertexID << ").");
    mesh::Vertex *vertices[3];
    vertices[0] = &mesh->vertices()[firstVertexID];
    vertices[1] = &mesh->vertices()[secondVertexID];
    vertices[2] = &mesh->vertices()[thirdVertexID];
    PRECICE_CHECK(utils::unique_elements(utils::make_array(vertices[0]->getCoords(),
                                                           vertices[1]->getCoords(), vertices[2]->getCoords())),
                  "setMeshTriangleWithEdges() was called with vertices located at identical coordinates (IDs: " << firstVertexID << ',' << secondVertexID << ',' << thirdVertexID << ").");
    mesh::Edge *edges[3];
    edges[0] = &mesh->createUniqueEdge(*vertices[0], *vertices[1]);
    edges[1] = &mesh->createUniqueEdge(*vertices[1], *vertices[2]);
    edges[2] = &mesh->createUniqueEdge(*vertices[2], *vertices[0]);

    mesh->createTriangle(*edges[0], *edges[1], *edges[2]);
  }
}

void SolverInterfaceImpl2::setMeshQuad(
    int meshID,
    int firstEdgeID,
    int secondEdgeID,
    int thirdEdgeID,
    int fourthEdgeID)
{
  PRECICE_TRACE(meshID, firstEdgeID, secondEdgeID, thirdEdgeID,
                fourthEdgeID);
  PRECICE_CHECK(_dimensions == 3, "setMeshQuad is only possible for 3D cases."
                                  " Please set the dimension to 3 in the preCICE configuration file.");
  PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext &context = _accessor->meshContext(meshID);
  if (context.meshRequirement == mapping::Mapping::MeshRequirement::FULL) {
    mesh::PtrMesh &mesh = context.mesh;
    using impl::errorInvalidEdgeID;
    PRECICE_CHECK(mesh->isValidEdgeID(firstEdgeID), errorInvalidEdgeID(firstEdgeID));
    PRECICE_CHECK(mesh->isValidEdgeID(secondEdgeID), errorInvalidEdgeID(secondEdgeID));
    PRECICE_CHECK(mesh->isValidEdgeID(thirdEdgeID), errorInvalidEdgeID(thirdEdgeID));
    PRECICE_CHECK(mesh->isValidEdgeID(fourthEdgeID), errorInvalidEdgeID(fourthEdgeID));

    PRECICE_CHECK(utils::unique_elements(utils::make_array(firstEdgeID, secondEdgeID, thirdEdgeID, fourthEdgeID)),
                  "The four edge ID's are not unique. Please check that the edges that form the quad are correct.");

    auto chain = mesh::asChain(utils::make_array(
        &mesh->edges()[firstEdgeID], &mesh->edges()[secondEdgeID],
        &mesh->edges()[thirdEdgeID], &mesh->edges()[fourthEdgeID]));
    PRECICE_CHECK(chain.connected, "The four edges are not connect. Please check that the edges that form the quad are correct.");

    auto coords = mesh::coordsFor(chain.vertices);
    PRECICE_CHECK(utils::unique_elements(coords),
                  "The four vertices that form the quad are not unique. The resulting shape may be a point, line or triangle."
                  "Please check that the adapter sends the four unique vertices that form the quad, or that the mesh on the interface "
                  "is composed of planar quads.");

    auto convexity = math::geometry::isConvexQuad(coords);
    PRECICE_CHECK(convexity.convex, "The given quad is not convex. "
                                    "Please check that the adapter send the four correct vertices or that the interface is composed of planar quads.");

    // Use the shortest diagonal to split the quad into 2 triangles.
    // The diagonal to be used with edges (1, 2) and (0, 3) of the chain
    double distance1 = (coords[0] - coords[2]).norm();
    // The diagonal to be used with edges (0, 1) and (2, 3) of the chain
    double distance2 = (coords[1] - coords[3]).norm();

    // The new edge, e[4], is the shortest diagonal of the quad
    if (distance1 <= distance2) {
      auto &diag = mesh->createUniqueEdge(*chain.vertices[0], *chain.vertices[2]);
      mesh->createTriangle(*chain.edges[3], *chain.edges[0], diag);
      mesh->createTriangle(*chain.edges[1], *chain.edges[2], diag);
    } else {
      auto &diag = mesh->createUniqueEdge(*chain.vertices[1], *chain.vertices[3]);
      mesh->createTriangle(*chain.edges[0], *chain.edges[1], diag);
      mesh->createTriangle(*chain.edges[2], *chain.edges[3], diag);
    }
  }
}

void SolverInterfaceImpl2::setMeshQuadWithEdges(
    int meshID,
    int firstVertexID,
    int secondVertexID,
    int thirdVertexID,
    int fourthVertexID)
{
  PRECICE_TRACE(meshID, firstVertexID,
                secondVertexID, thirdVertexID, fourthVertexID);
  PRECICE_CHECK(_dimensions == 3, "setMeshQuadWithEdges is only possible for 3D cases."
                                  " Please set the dimension to 3 in the preCICE configuration file.");
  PRECICE_REQUIRE_MESH_MODIFY(meshID);
  MeshContext &context = _accessor->meshContext(meshID);
  if (context.meshRequirement == mapping::Mapping::MeshRequirement::FULL) {
    PRECICE_ASSERT(context.mesh);
    mesh::Mesh &mesh = *(context.mesh);
    using impl::errorInvalidVertexID;
    PRECICE_CHECK(mesh.isValidVertexID(firstVertexID), errorInvalidVertexID(firstVertexID));
    PRECICE_CHECK(mesh.isValidVertexID(secondVertexID), errorInvalidVertexID(secondVertexID));
    PRECICE_CHECK(mesh.isValidVertexID(thirdVertexID), errorInvalidVertexID(thirdVertexID));
    PRECICE_CHECK(mesh.isValidVertexID(fourthVertexID), errorInvalidVertexID(fourthVertexID));

    auto vertexIDs = utils::make_array(firstVertexID, secondVertexID, thirdVertexID, fourthVertexID);
    PRECICE_CHECK(utils::unique_elements(vertexIDs), "The four vertex ID's are not unique. Please check that the vertices that form the quad are correct.");

    auto coords = mesh::coordsFor(mesh, vertexIDs);
    PRECICE_CHECK(utils::unique_elements(coords),
                  "The four vertices that form the quad are not unique. The resulting shape may be a point, line or triangle."
                  "Please check that the adapter sends the four unique vertices that form the quad, or that the mesh on the interface "
                  "is composed of quads. A mix of triangles and quads are not supported.");

    auto convexity = math::geometry::isConvexQuad(coords);
    PRECICE_CHECK(convexity.convex, "The given quad is not convex. "
                                    "Please check that the adapter send the four correct vertices or that the interface is composed of quads. "
                                    "A mix of triangles and quads are not supported.");
    auto reordered = utils::reorder_array(convexity.vertexOrder, mesh::vertexPtrsFor(mesh, vertexIDs));

    // Vertices are now in the order: V0-V1-V2-V3-V0.
    // The order now identifies all outer edges of the quad.
    auto &edge0 = mesh.createUniqueEdge(*reordered[0], *reordered[1]);
    auto &edge1 = mesh.createUniqueEdge(*reordered[1], *reordered[2]);
    auto &edge2 = mesh.createUniqueEdge(*reordered[2], *reordered[3]);
    auto &edge3 = mesh.createUniqueEdge(*reordered[3], *reordered[0]);

    // Use the shortest diagonal to split the quad into 2 triangles.
    // Vertices are now in V0-V1-V2-V3-V0 order. The new edge, e[4] is either 0-2 or 1-3
    double distance1 = (reordered[0]->getCoords() - reordered[2]->getCoords()).norm();
    double distance2 = (reordered[1]->getCoords() - reordered[3]->getCoords()).norm();

    // The new edge, e[4], is the shortest diagonal of the quad
    if (distance1 <= distance2) {
      auto &diag = mesh.createUniqueEdge(*reordered[0], *reordered[2]);
      mesh.createTriangle(edge0, edge1, diag);
      mesh.createTriangle(edge2, edge3, diag);
    } else {
      auto &diag = mesh.createUniqueEdge(*reordered[1], *reordered[3]);
      mesh.createTriangle(edge3, edge0, diag);
      mesh.createTriangle(edge1, edge2, diag);
    }
  }
}
*/
void SolverInterfaceImpl2::mapWriteDataFrom(
    int fromMeshID)
{
  PRECICE_TRACE(fromMeshID);
  PRECICE_VALIDATE_MESH_ID(fromMeshID);
  impl::MeshContext2 &   context        = _accessor->meshContext(fromMeshID);
  impl::MappingContext2 &mappingContext = context.fromMappingContext;
  if (not mappingContext.mapping) {
    PRECICE_ERROR("You attempt to \"mapWriteDataFrom\" mesh "
                  << context.mesh->getName()
                  << ", but there is no mapping from this mesh configured."
                     "Maybe you don't want to call this function at all or you forgot to configure the mapping.");
    return;
  }
  double time = _couplingScheme->getTime();
  performDataActions({action::Action::WRITE_MAPPING_PRIOR}, time, 0, 0, 0);
  if (not mappingContext.mapping->hasComputedMapping()) {
    PRECICE_DEBUG("Compute mapping from mesh \"" << context.mesh->getName() << "\"");
    mappingContext.mapping->computeMapping();
  }
  for (impl::DataContext2 &context : _accessor->writeDataContexts()) {
    if (context.mesh->getID() == fromMeshID) {
      int inDataID             = context.fromData->getID();
      int outDataID            = context.toData->getID();
      context.toData->values() = Eigen::VectorXd::Zero(context.toData->values().size());
      PRECICE_DEBUG("Map data \"" << context.fromData->getName()
                                  << "\" from mesh \"" << context.mesh->getName() << "\"");
      PRECICE_ASSERT(mappingContext.mapping == context.mappingContext.mapping);
      mappingContext.mapping->map(inDataID, outDataID);
    }
  }
  mappingContext.hasMappedData = true;
  performDataActions({action::Action::WRITE_MAPPING_POST}, time, 0, 0, 0);
}

void SolverInterfaceImpl2::mapReadDataTo(
    int toMeshID)
{
  PRECICE_TRACE(toMeshID);
  PRECICE_VALIDATE_MESH_ID(toMeshID);
  impl::MeshContext2 &   context        = _accessor->meshContext(toMeshID);
  impl::MappingContext2 &mappingContext = context.toMappingContext;
  if (mappingContext.mapping.use_count() == 0) {
    PRECICE_ERROR("You attempt to \"mapReadDataTo\" mesh "
                  << context.mesh->getName()
                  << ", but there is no mapping to this mesh configured."
                     "Maybe you don't want to call this function at all or you forgot to configure the mapping.");
    return;
  }
  double time = _couplingScheme->getTime();
  performDataActions({action::Action::READ_MAPPING_PRIOR}, time, 0, 0, 0);
  if (not mappingContext.mapping->hasComputedMapping()) {
    PRECICE_DEBUG("Compute mapping from mesh \"" << context.mesh->getName() << "\"");
    mappingContext.mapping->computeMapping();
  }
  for (impl::DataContext2 &context : _accessor->readDataContexts()) {
    if (context.mesh->getID() == toMeshID) {
      int inDataID             = context.fromData->getID();
      int outDataID            = context.toData->getID();
      context.toData->values() = Eigen::VectorXd::Zero(context.toData->values().size());
      PRECICE_DEBUG("Map data \"" << context.fromData->getName()
                                  << "\" to mesh \"" << context.mesh->getName() << "\"");
      PRECICE_ASSERT(mappingContext.mapping == context.mappingContext.mapping);
      mappingContext.mapping->map(inDataID, outDataID);
      PRECICE_DEBUG("Mapped values = " << utils::previewRange(3, context.toData->values()));
    }
  }
  mappingContext.hasMappedData = true;
  performDataActions({action::Action::READ_MAPPING_POST}, time, 0, 0, 0);
}

void SolverInterfaceImpl2::writeBlockVectorData(
    int           fromDataID,
    int           size,
    const int *   valueIndices,
    const double *values)
{
  PRECICE_TRACE(fromDataID, size);
  PRECICE_CHECK(_state != State::Finalized, "writeBlockVectorData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(fromDataID);
  if (size == 0)
    return;
  PRECICE_ASSERT(valueIndices != nullptr);
  PRECICE_ASSERT(values != nullptr);
  //PRECICE_REQUIRE_DATA_WRITE(fromDataID);
  DataContext2 &context = _accessor->dataContext(fromDataID);
  PRECICE_CHECK(context.fromData->getDimensions() == _dimensions,
                "You cannot call writeBlockVectorData on the scalar data type \"" << context.fromData->getName()
                                                                                  << "\". Use writeBlockScalarData or change the data type for \""
                                                                                  << context.fromData->getName() << "\" to vector.");
  PRECICE_ASSERT(context.toData.get() != nullptr);
  auto &valuesInternal = context.fromData->values();
  for (int i = 0; i < size; i++) {
    const auto valueIndex = valueIndices[i];
    PRECICE_CHECK(0 <= valueIndex && valueIndex < valuesInternal.size() / context.fromData->getDimensions(), "Value index out of range. Please check that the size of "
                                                                                                                 << context.fromData->getName() << " is correct.");
    int offsetInternal = valueIndex * _dimensions;
    int offset         = i * _dimensions;
    for (int dim = 0; dim < _dimensions; dim++) {
      PRECICE_ASSERT(offset + dim < valuesInternal.size(),
                     offset + dim, valuesInternal.size());
      valuesInternal[offsetInternal + dim] = values[offset + dim];
    }
  }
}

void SolverInterfaceImpl2::writeVectorData(
    int           fromDataID,
    int           valueIndex,
    const double *value)
{
  PRECICE_TRACE(fromDataID, valueIndex);
  PRECICE_CHECK(_state != State::Finalized, "writeVectorData(...) cannot be called before finalize().");
  //PRECICE_VALIDATE_DATA_ID(fromDataID);
  PRECICE_DEBUG("value = " << Eigen::Map<const Eigen::VectorXd>(value, _dimensions));
  //PRECICE_REQUIRE_DATA_WRITE(fromDataID);
  DataContext2 &context = _accessor->dataContext(fromDataID);
  PRECICE_CHECK(context.fromData->getDimensions() == _dimensions,
                "You cannot call writeVectorData on the scalar data type \"" << context.fromData->getName()
                                                                             << "\". Use writeScalarData or change the data type for \""
                                                                             << context.fromData->getName() << "\" to vector.");
  PRECICE_ASSERT(context.toData.get() != nullptr);
  auto &values = context.fromData->values();
  PRECICE_CHECK(0 <= valueIndex && valueIndex < values.size() / context.fromData->getDimensions(), "Value index out of range. Please check that the valueIndex for "
                                                                                                       << context.fromData->getName() << " is in the correct range.");
  int offset = valueIndex * _dimensions;
  for (int dim = 0; dim < _dimensions; dim++) {
    values[offset + dim] = value[dim];
  }
}

void SolverInterfaceImpl2::writeBlockScalarData(
    int           fromDataID,
    int           size,
    const int *   valueIndices,
    const double *values)
{
  PRECICE_TRACE(fromDataID, size);
  PRECICE_CHECK(_state != State::Finalized, "writeBlockScalarData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(fromDataID);
  if (size == 0)
    return;
  PRECICE_ASSERT(valueIndices != nullptr);
  PRECICE_ASSERT(values != nullptr);
  //PRECICE_REQUIRE_DATA_WRITE(fromDataID);
  DataContext2 &context = _accessor->dataContext(fromDataID);
  PRECICE_CHECK(context.fromData->getDimensions() == 1,
                "You cannot call writeBlockScalarData on the vector data type \"" << context.fromData->getName()
                                                                                  << "\". Use writeBlockVectorData or change the data type for \""
                                                                                  << context.fromData->getName() << "\" to scalar.");
  PRECICE_ASSERT(context.toData.get() != nullptr);
  auto &valuesInternal = context.fromData->values();
  for (int i = 0; i < size; i++) {
    const auto valueIndex = valueIndices[i];
    PRECICE_CHECK(0 <= valueIndex && valueIndex < valuesInternal.size() / context.fromData->getDimensions(), "Value index out of range. Please check that the size of "
                                                                                                                 << context.fromData->getName() << " is correct.");
    PRECICE_ASSERT(i < valuesInternal.size(), i, valuesInternal.size());
    valuesInternal[valueIndex] = values[i];
  }
}

void SolverInterfaceImpl2::writeScalarData(
    int    fromDataID,
    int    valueIndex,
    double value)
{
  PRECICE_TRACE(fromDataID, valueIndex, value);
  PRECICE_CHECK(_state != State::Finalized, "writeScalarData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(fromDataID);
  //PRECICE_REQUIRE_DATA_WRITE(fromDataID);
  DataContext2 &context = _accessor->dataContext(fromDataID);
  PRECICE_CHECK(valueIndex >= -1, "Invalid value index (" << valueIndex << ") when writing scalar data. Value index must be >= 0. "
                                                                           "Please check the value index for "
                                                          << context.fromData->getName());
  PRECICE_CHECK(context.fromData->getDimensions() == 1,
                "You cannot call writeScalarData on the vector data type \"" << context.fromData->getName()
                                                                             << "\". Use writeVectorData or change the data type for \""
                                                                             << context.fromData->getName() << "\" to scalar.");
  PRECICE_ASSERT(context.toData);
  auto &values = context.fromData->values();
  PRECICE_CHECK(0 <= valueIndex && valueIndex < values.size() / context.fromData->getDimensions(), "Value index out of range. Please check that the valueIndex for "
                                                                                                       << context.fromData->getName() << " is in the correct range.");
  values[valueIndex] = value;
}

void SolverInterfaceImpl2::readBlockVectorData(
    int        toDataID,
    int        size,
    const int *valueIndices,
    double *   values) const
{
  PRECICE_TRACE(toDataID, size);
  PRECICE_CHECK(_state != State::Finalized, "readBlockVectorData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(toDataID);
  if (size == 0)
    return;
  PRECICE_ASSERT(valueIndices != nullptr);
  PRECICE_ASSERT(values != nullptr);
  //PRECICE_REQUIRE_DATA_READ(toDataID);
  DataContext2 &context = _accessor->dataContext(toDataID);
  PRECICE_CHECK(context.toData->getDimensions() == _dimensions,
                "You cannot call readBlockVectorData on the scalar data type \"" << context.toData->getName()
                                                                                 << "\". Use readBlockScalarData or change the data type for \""
                                                                                 << context.fromData->getName() << "\" to vector.");
  PRECICE_ASSERT(context.fromData.get() != nullptr);
  auto &valuesInternal = context.toData->values();
  for (int i = 0; i < size; i++) {
    const auto valueIndex = valueIndices[i];
    PRECICE_CHECK(0 <= valueIndex && valueIndex < valuesInternal.size() / context.fromData->getDimensions(), "Value index out of range. Please check that the size of "
                                                                                                                 << context.fromData->getName() << " is correct.");
    int offsetInternal = valueIndex * _dimensions;
    int offset         = i * _dimensions;
    for (int dim = 0; dim < _dimensions; dim++) {
      PRECICE_ASSERT(offsetInternal + dim < valuesInternal.size(),
                     offsetInternal + dim, valuesInternal.size());
      values[offset + dim] = valuesInternal[offsetInternal + dim];
    }
  }
}

void SolverInterfaceImpl2::readVectorData(
    int     toDataID,
    int     valueIndex,
    double *value) const
{
  PRECICE_TRACE(toDataID, valueIndex);
  PRECICE_CHECK(_state != State::Finalized, "readVectorData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(toDataID);
  //PRECICE_REQUIRE_DATA_READ(toDataID);
  DataContext2 &context = _accessor->dataContext(toDataID);
  PRECICE_CHECK(valueIndex >= -1, "Invalid value index ( " << valueIndex << " ) when reading vector data. Value index must be >= 0. "
                                                                            "Please check the value index for "
                                                           << context.fromData->getName());
  PRECICE_CHECK(context.toData->getDimensions() == _dimensions,
                "You cannot call readVectorData on the scalar data type \"" << context.toData->getName()
                                                                            << "\". Use readScalarData or change the data type for \""
                                                                            << context.fromData->getName() << "\" to vector.");
  PRECICE_ASSERT(context.fromData);
  auto &values = context.toData->values();
  PRECICE_CHECK(0 <= valueIndex && valueIndex < values.size() / context.fromData->getDimensions(), "Value index out of range. Please check that the valueIndex for "
                                                                                                       << context.fromData->getName() << " is in the correct range.");
  int offset = valueIndex * _dimensions;
  for (int dim = 0; dim < _dimensions; dim++) {
    value[dim] = values[offset + dim];
  }
  PRECICE_DEBUG("read value = " << Eigen::Map<const Eigen::VectorXd>(value, _dimensions));
}

void SolverInterfaceImpl2::readBlockScalarData(
    int        toDataID,
    int        size,
    const int *valueIndices,
    double *   values) const
{
  PRECICE_TRACE(toDataID, size);
  PRECICE_CHECK(_state != State::Finalized, "readBlockScalarData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(toDataID);
  if (size == 0)
    return;
  PRECICE_DEBUG("size = " << size);
  PRECICE_ASSERT(valueIndices != nullptr);
  PRECICE_ASSERT(values != nullptr);
  //PRECICE_REQUIRE_DATA_READ(toDataID);
  DataContext2 &context = _accessor->dataContext(toDataID);
  PRECICE_CHECK(context.toData->getDimensions() == 1,
                "You cannot call readBlockScalarData on the vector data type \"" << context.toData->getName()
                                                                                 << "\". Use readBlockVectorData or change the data type for \"" << context.fromData->getName() << "\" to scalar.");
  PRECICE_ASSERT(context.fromData.get() != nullptr);
  auto &valuesInternal = context.toData->values();
  for (int i = 0; i < size; i++) {
    const auto valueIndex = valueIndices[i];
    PRECICE_CHECK(0 <= valueIndex && valueIndex < valuesInternal.size(), "Value index out of range. Please check that the size of "
                                                                             << context.fromData->getName() << " is correct.");
    values[i] = valuesInternal[valueIndex];
  }
}

void SolverInterfaceImpl2::readScalarData(
    int     toDataID,
    int     valueIndex,
    double &value) const
{
  PRECICE_TRACE(toDataID, valueIndex, value);
  PRECICE_CHECK(_state != State::Finalized, "readScalarData(...) cannot be called after finalize().");
  //PRECICE_VALIDATE_DATA_ID(toDataID);
  //PRECICE_REQUIRE_DATA_READ(toDataID);
  DataContext2 &context = _accessor->dataContext(toDataID);
  PRECICE_CHECK(valueIndex >= -1, "Invalid value index ( " << valueIndex << " ) when reading scalar data. Value index must be >= 0. "
                                                                            "Please check the value index for "
                                                           << context.fromData->getName());
  PRECICE_CHECK(context.toData->getDimensions() == 1,
                "You cannot call readScalarData on the vector data type \"" << context.toData->getName()
                                                                            << "\". Use readVectorData or change the data type for \""
                                                                            << context.fromData->getName() << "\" to scalar.");
  PRECICE_ASSERT(context.fromData);
  auto &values = context.toData->values();
  PRECICE_CHECK(0 <= valueIndex && valueIndex < values.size(), "Value index out of range. Please check that the valueIndex for "
                                                                   << context.fromData->getName() << " is in the correct range.");
  value = values[valueIndex];
  PRECICE_DEBUG("Read value = " << value);
}

void SolverInterfaceImpl2::exportMesh(
    const std::string &filenameSuffix,
    int                exportType) const
{
  PRECICE_TRACE(filenameSuffix, exportType);
  // Export meshes
  //const ExportContext& context = _accessor->exportContext();
  for (const io::ExportContext &context : _accessor->exportContexts()) {
  /*  PRECICE_DEBUG("Export type = " << exportType);						//auskommentiert
    bool exportAll  = exportType == io::constants::exportAll();
    bool exportThis = context.exporter->getType() == exportType;
    if (exportAll || exportThis) {
      for (const MeshContext2 *meshContext : _accessor->usedMeshContexts()) {
        std::string name = meshContext->mesh->getName() + "-" + filenameSuffix;
        PRECICE_DEBUG("Exporting mesh to file \"" << name << "\" at location \"" << context.location << "\"");
        context.exporter->doExport(name, context.location, *(meshContext->mesh));
      }
    }*/
  }
}

void SolverInterfaceImpl2::configureM2Ns(
    const m2n::M2NConfiguration2::SharedPointer2 &config)
{
  PRECICE_TRACE();
  for (const auto &m2nTuple : config->m2ns()) {
    std::string comPartner("");
    bool        isRequesting = false;
    if (std::get<1>(m2nTuple) == _accessorName) {
      comPartner   = std::get<2>(m2nTuple);
      isRequesting = true;
    } else if (std::get<2>(m2nTuple) == _accessorName) {
      comPartner = std::get<1>(m2nTuple);
    }
    if (not comPartner.empty()) {
      for (const PtrParticipant2 &participant : _participants) {
        if (participant->getName() == comPartner) {
          PRECICE_ASSERT(not utils::contained(comPartner, _m2ns), comPartner);
          PRECICE_ASSERT(std::get<0>(m2nTuple));

          _m2ns[comPartner] = [&] {
            m2n::BoundM2N2 bound;
            bound.m2n          = std::get<0>(m2nTuple);
            bound.localName    = _accessorName;
            bound.remoteName   = comPartner;
            bound.isRequesting = isRequesting;
            return bound;
          }();
        }
      }
    }
  }
}

void SolverInterfaceImpl2::configurePartitions(
    const m2n::M2NConfiguration2::SharedPointer2 &m2nConfig)
{
  PRECICE_TRACE();
  for (MeshContext2 *context : _accessor->usedMeshContexts()) {

    if (context->provideMesh) { // Accessor provides mesh
      PRECICE_CHECK(context->receiveMeshFrom.empty(),
                    "Participant \"" << _accessorName << "\" cannot provide "
                                     << "and receive mesh " << context->mesh->getName() << "!");

      context->partition = PtrPartition2(new partition::ProvidedPartition2(context->mesh));

      for (auto &receiver : _participants) {
        for (auto &receiverContext : receiver->usedMeshContexts()) {
          if (receiverContext->receiveMeshFrom == _accessorName && receiverContext->mesh->getName() == context->mesh->getName()) {
            // meshRequirement has to be copied from "from" to provide", since
            // mapping are only defined at "provide"
            if (receiverContext->meshRequirement > context->meshRequirement) {
              context->meshRequirement = receiverContext->meshRequirement;
            }

            PtrM2N2 m2n = m2nConfig->getM2N(receiver->getName(), _accessorName);
            m2n->createDistributedCommunication(context->mesh);
            context->partition->addM2N(m2n);
          }
        }
      }
      /// @todo support offset??

    } else { // Accessor receives mesh
      PRECICE_CHECK(not context->receiveMeshFrom.empty(),
                    "Participant \"" << _accessorName << "\" must either provide or receive the mesh \"" << context->mesh->getName() << "\". Please define either a \"from\" or a \"provide\" attribute in the <use-mesh name=\"" << context->mesh->getName() << "\"/> node of \"" << _accessorName << "\".")
      PRECICE_CHECK(not context->provideMesh,
                    "Participant \"" << _accessorName << "\" cannot provide and receive mesh \"" << context->mesh->getName() << "\" at the same time. Please check your \"from\" and \"provide\" attributes in the <use-mesh name=\"" << context->mesh->getName() << "\"/> node of \"" << _accessorName << "\".");
      std::string receiver(_accessorName);
      std::string provider(context->receiveMeshFrom);

      PRECICE_DEBUG("Receiving mesh from " << provider);

      context->partition = PtrPartition2(new partition::ReceivedPartition2(context->mesh, context->geoFilter, context->safetyFactor));

      PtrM2N2 m2n = m2nConfig->getM2N(receiver, provider);
      m2n->createDistributedCommunication(context->mesh);
      context->partition->addM2N(m2n);
      context->partition->setFromMapping(context->fromMappingContext.mapping);
      context->partition->setToMapping(context->toMappingContext.mapping);
    }
  }
}

void SolverInterfaceImpl2::compareBoundingBoxes()
{
  // sort meshContexts by name, for communication in right order.
  std::sort(_accessor->usedMeshContexts().begin(), _accessor->usedMeshContexts().end(),
            [](MeshContext2 const *const lhs, MeshContext2 const *const rhs) -> bool {
              return lhs->mesh->getName() < rhs->mesh->getName();
            });

  for (MeshContext2 *meshContext : _accessor->usedMeshContexts()) {
    if (meshContext->provideMesh) // provided meshes need their bounding boxes already for the re-partitioning
      meshContext->mesh->computeBoundingBox();
  }

  for (MeshContext2 *meshContext : _accessor->usedMeshContexts()) {
    meshContext->partition->compareBoundingBoxes();
  }
}

void SolverInterfaceImpl2::computePartitions()
{
  //We need to do this in two loops: First, communicate the mesh and later compute the partition.
  //Originally, this was done in one loop. This however gave deadlock if two meshes needed to be communicated cross-wise.
  //Both loops need a different sorting

  auto &contexts = _accessor->usedMeshContexts();

  std::sort(contexts.begin(), contexts.end(),
            [](MeshContext2 const *const lhs, MeshContext2 const *const rhs) -> bool {
              return lhs->mesh->getName() < rhs->mesh->getName();
            });

  for (MeshContext2 *meshContext : contexts) {
    meshContext->partition->communicate();
  }

  // for two-level initialization, there is also still communication in partition::compute()
  // therefore, we cannot resort here.
  // @todo this hacky solution should be removed as part of #633
  bool resort = true;
  for (auto &m2nPair : _m2ns) {
    if (m2nPair.second.m2n->usesTwoLevelInitialization()) {
      resort = false;
      break;
    }
  }

  if (resort) {
    // pull provided meshes up front, to have them ready for the decomposition of the received meshes (for the mappings)
    std::stable_partition(contexts.begin(), contexts.end(),
                          [](MeshContext2 const *const meshContext) -> bool {
                            return meshContext->provideMesh;
                          });
  }

  for (MeshContext2 *meshContext : contexts) {
    meshContext->partition->compute();
    meshContext->mesh->computeState();
    if (not meshContext->provideMesh) { // received mesh can only compute their bounding boxes here
      meshContext->mesh->computeBoundingBox();
    }
    meshContext->mesh->allocateDataValues();
  }
}

void SolverInterfaceImpl2::mapWrittenData()
{
  PRECICE_TRACE();
  using namespace mapping;
  MappingConfiguration2::Timing2 timing;
  // Compute mappings
  for (impl::MappingContext2 &context : _accessor->writeMappingContexts()) {
    timing         = context.timing;
    bool rightTime = timing == MappingConfiguration2::ON_ADVANCE;
    rightTime |= timing == MappingConfiguration2::INITIAL;
    bool hasComputed = context.mapping->hasComputedMapping();
    if (rightTime && not hasComputed) {
      PRECICE_INFO("Compute write mapping from mesh \""
                   << _accessor->meshContext(context.fromMeshID).mesh->getName()
                   << "\" to mesh \""
                   << _accessor->meshContext(context.toMeshID).mesh->getName()
                   << "\".");

      context.mapping->computeMapping();
    }
  }

  // Map data
  for (impl::DataContext2 &context : _accessor->writeDataContexts()) {
    timing          = context.mappingContext.timing;
    bool hasMapping = context.mappingContext.mapping.get() != nullptr;
    bool rightTime  = timing == MappingConfiguration::ON_ADVANCE;
    rightTime |= timing == MappingConfiguration2::INITIAL;
    bool hasMapped = context.mappingContext.hasMappedData;
    if (hasMapping && rightTime && (not hasMapped)) {
      int inDataID  = context.fromData->getID();
      int outDataID = context.toData->getID();
      PRECICE_DEBUG("Map data \"" << context.fromData->getName()
                                  << "\" from mesh \"" << context.mesh->getName() << "\"");
      context.toData->values() = Eigen::VectorXd::Zero(context.toData->values().size());
      PRECICE_DEBUG("Map from dataID " << inDataID << " to dataID: " << outDataID);
      context.mappingContext.mapping->map(inDataID, outDataID);
      PRECICE_DEBUG("Mapped values = " << utils::previewRange(3, context.toData->values()));
    }
  }

  // Clear non-stationary, non-incremental mappings
  for (impl::MappingContext2 &context : _accessor->writeMappingContexts()) {
    bool isStationary = context.timing == MappingConfiguration2::INITIAL;
    if (not isStationary) {
      context.mapping->clear();
    }
    context.hasMappedData = false;
  }
}

void SolverInterfaceImpl2::mapReadData()
{

  PRECICE_DEBUG("precice inside mapReadData 1.0");

  PRECICE_TRACE();
  mapping::MappingConfiguration2::Timing2 timing;
  // Compute mappings
  for (impl::MappingContext2 &context : _accessor->readMappingContexts()) {
    timing      = context.timing;
    bool mapNow = timing == mapping::MappingConfiguration2::ON_ADVANCE;
    mapNow |= timing == mapping::MappingConfiguration2::INITIAL;
    bool hasComputed = context.mapping->hasComputedMapping();
    if (mapNow && not hasComputed) {
      PRECICE_INFO("Compute read mapping from mesh \""
                   << _accessor->meshContext(context.fromMeshID).mesh->getName()
                   << "\" to mesh \""
                   << _accessor->meshContext(context.toMeshID).mesh->getName()
                   << "\".");

      context.mapping->computeMapping();
    }
  }

  PRECICE_DEBUG("precice inside mapReadData 2.0");

  // Map data
  for (impl::DataContext2 &context : _accessor->readDataContexts()) {
    timing      = context.mappingContext.timing;
    bool mapNow = timing == mapping::MappingConfiguration2::ON_ADVANCE;
    mapNow |= timing == mapping::MappingConfiguration2::INITIAL;
    bool hasMapping = context.mappingContext.mapping.get() != nullptr;
    bool hasMapped  = context.mappingContext.hasMappedData;
    if (mapNow && hasMapping && (not hasMapped)) {
      int inDataID             = context.fromData->getID();
      int outDataID            = context.toData->getID();
      context.toData->values() = Eigen::VectorXd::Zero(context.toData->values().size());
      PRECICE_DEBUG("Map read data \"" << context.fromData->getName()
                                       << "\" to mesh \"" << context.mesh->getName() << "\"");
      context.mappingContext.mapping->map(inDataID, outDataID);
      PRECICE_DEBUG("Mapped values = " << utils::previewRange(3, context.toData->values()));
    }
  }
  
    PRECICE_DEBUG("precice inside mapReadData 3.0");
    
  // Clear non-initial, non-incremental mappings
  for (impl::MappingContext2 &context : _accessor->readMappingContexts()) {
    bool isStationary = context.timing == mapping::MappingConfiguration2::INITIAL;
    if (not isStationary) {
      context.mapping->clear();
    }
    context.hasMappedData = false;
  }
  
    PRECICE_DEBUG("precice inside mapReadData 4.0");
  
}

void SolverInterfaceImpl2::performDataActions(
    const std::set<action::Action::Timing> &timings,
    double                                  time,
    double                                  dt,
    double                                  partFullDt,
    double                                  fullDt)
{
  PRECICE_TRACE();
  for (action::PtrAction &action : _accessor->actions()) {
    if (timings.find(action->getTiming()) != timings.end()) {
      action->performAction(time, dt, partFullDt, fullDt);
    }
  }
}

void SolverInterfaceImpl2::handleExports()
{
  PRECICE_TRACE();
  //timesteps was already incremented before
  int timesteps = _couplingScheme->getTimeWindows() - 1;

  for (const io::ExportContext &context : _accessor->exportContexts()) {
    if (_couplingScheme->isTimeWindowComplete() || context.everyIteration) {
      if (context.everyNTimeWindows != -1) {
        if (timesteps % context.everyNTimeWindows == 0) {
          if (context.everyIteration) {
            std::ostringstream everySuffix;
            everySuffix << _accessorName << ".it" << _numberAdvanceCalls;
           // exportMesh(everySuffix.str());						//auskommentiert
          }
          std::ostringstream suffix;
          suffix << _accessorName << ".dt" << _couplingScheme->getTimeWindows() - 1;
          //exportMesh(suffix.str());							//auskommentiert
          if (context.triggerSolverPlot) {
            _couplingScheme->requireAction(std::string("plot-output"));
          }
        }
      }
    }
  }

  if (_couplingScheme->isTimeWindowComplete()) {
    // Export watch point data
    for (const PtrWatchPoint &watchPoint : _accessor->watchPoints()) {
      watchPoint->exportPointData(_couplingScheme->getTime());
    }
  }
}

void SolverInterfaceImpl2::resetWrittenData()
{
  PRECICE_TRACE();
  for (DataContext2 &context : _accessor->writeDataContexts()) {
    context.fromData->toZero();
    if (context.toData != context.fromData) {
      context.toData->toZero();
    }
  }
}

PtrParticipant2 SolverInterfaceImpl2::determineAccessingParticipant(
    const config::SolverInterfaceConfiguration2 &config)
{
  const auto &partConfig = config.getParticipantConfiguration();
  for (const PtrParticipant2 &participant : partConfig->getParticipants()) {
    if (participant->getName() == _accessorName) {
      return participant;
    }
  }
  PRECICE_ERROR("This participant's name, which was specified in the constructor of the preCICE interface as \""
                << _accessorName << "\", is not defined in the preCICE configuration. Please double-check the correct spelling.");
}

void SolverInterfaceImpl2::initializeMasterSlaveCommunication()
{
  PRECICE_TRACE();

  Event2 e("com.initializeMasterSlaveCom", precice::syncMode);
  utils::MasterSlave2::_communication->connectMasterSlaves(
      _accessorName, "MasterSlaves",
      _accessorProcessRank, _accessorCommunicatorSize);
}

void SolverInterfaceImpl2::syncTimestep(double computedTimestepLength)
{
  PRECICE_ASSERT(utils::MasterSlave2::isMaster() || utils::MasterSlave2::isSlave());
  if (utils::MasterSlave2::isSlave()) {
    utils::MasterSlave2::_communication->send(computedTimestepLength, 0);
  } else if (utils::MasterSlave2::isMaster()) {
    for (int rankSlave = 1; rankSlave < _accessorCommunicatorSize; rankSlave++) {
      double dt;
      utils::MasterSlave2::_communication->receive(dt, rankSlave);
      PRECICE_CHECK(math::equals(dt, computedTimestepLength),
                    "Found ambiguous values for the timestep length passed to preCICE in \"advance\". On rank " << rankSlave << ", the value is " << dt << ", while on rank 0, the value is " << computedTimestepLength << ".");
    }
  }
}

const mesh::Mesh2 &SolverInterfaceImpl2::mesh(const std::string &meshName) const
{
  PRECICE_TRACE(meshName);
  const MeshContext2 *context = _accessor->usedMeshContextByName(meshName);
  PRECICE_ASSERT(context && context->mesh,
                 "Participant \"" << _accessorName << "\" does not use mesh \"" << meshName << "\"!");
  return *context->mesh;
}

} // namespace impl
} // namespace precice
