#include "ConfigParser2.h"
#include <algorithm>
#include <exception>
#include <fstream>
#include <iterator>
#include <libxml/SAX.h>
#include <memory>
#include <string>
#include <unordered_set>
#include <utility>
#include "logging/LogMacros.hpp"
#include "logging/Logger.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"

namespace precice {
namespace xml {

// ------------------------- Callback functions for libxml2  -------------------------


void OnStartElementNs(
    void *          ctx,
    const xmlChar * localname,
    const xmlChar * prefix,
    const xmlChar * URI,
    int             nb_namespaces,
    const xmlChar **namespaces,
    int             nb_attributes,
    int             nb_defaulted,
    const xmlChar **attributes)
{
  ConfigParser2::CTag::AttributePair attributesMap;
  unsigned int                      index = 0;
  for (int indexAttribute = 0; indexAttribute < nb_attributes; ++indexAttribute, index += 5) {
    std::string attributeName(reinterpret_cast<const char *>(attributes[index]));

    auto        valueBegin = reinterpret_cast<const char *>(attributes[index + 3]);
    auto        valueEnd   = reinterpret_cast<const char *>(attributes[index + 4]);
    std::string value(valueBegin, valueEnd);

    attributesMap[attributeName] = value;
  }

  auto pParser = static_cast<ConfigParser2 *>(ctx);

  std::string sPrefix(prefix == nullptr ? "" : reinterpret_cast<const char *>(prefix));

  pParser->OnStartElement(reinterpret_cast<const char *>(localname), sPrefix, attributesMap);
}

void OnEndElementNs(
    void *         ctx,
    const xmlChar *localname,
    const xmlChar *prefix,
    const xmlChar *URI)
{
  ConfigParser2 *pParser = static_cast<ConfigParser2 *>(ctx);
  pParser->OnEndElement();
}

void OnCharacters(void *ctx, const xmlChar *ch, int len)
{
  ConfigParser2 *pParser = static_cast<ConfigParser2 *>(ctx);
  pParser->OnTextSection(std::string(reinterpret_cast<const char *>(ch), len));
}

void OnStructuredErrorFunc(void *userData, xmlError *error)
{
  const std::string message{error->message};

  // Ignore all namespace-related messages
  if (message.find("Namespace") != std::string::npos) {
    return;
  }

  ConfigParser2::MessageProxy(error->level, message);
}

// ------------------------- ConfigParser2 implementation  -------------------------

precice::logging::Logger ConfigParser2::_log("xml::XMLParser");


ConfigParser2::ConfigParser2(const std::string &filePath, const ConfigurationContext2 &context, std::shared_ptr<precice::xml::XMLTag2> pXMLTag, FEModel *fem)
    : m_pXMLTag(std::move(pXMLTag))
{

  fem1 = fem;
  
   write_log(fem1, 3,"here precice 5.1.2");

  readXmlFile(filePath);
  
   write_log(fem1, 3,"here precice 5.1.3");
   
   
  std::vector<std::shared_ptr<XMLTag2>> DefTags{m_pXMLTag};
  CTagPtrVec                           SubTags;
  // Initialize with the root tag, if any.
  if (not m_AllTags.empty())
  {
  
   write_log(fem1, 3,"here precice 5.1.4");
  
    SubTags.push_back(m_AllTags[0]);
    
     write_log(fem1, 3,"here precice 5.1.5");
     
  }
  
  write_log(fem1, 3,"here precice 5.1.6");
  
  try {
    connectTags(context, DefTags, SubTags);
    
     write_log(fem1, 3,"here precice 5.1.7");
     
  } catch (const std::exception &e) {
    PRECICE_ERROR("An unexpected exception occurred during configuration: " << e.what() << '.');
  }
}

ConfigParser2::ConfigParser2(const std::string &filePath)
{
  readXmlFile(filePath);
}

void ConfigParser2::MessageProxy(int level, const std::string &mess)
{
  switch (level) {
  case (XML_ERR_FATAL):
  case (XML_ERR_ERROR):
    PRECICE_ERROR(mess);
    break;
  case (XML_ERR_WARNING):
    PRECICE_WARN(mess);
    break;
  default:
    PRECICE_INFO(mess);
  }
}

int ConfigParser2::readXmlFile(std::string const &filePath)
{
  xmlSAXHandler SAXHandler;

  memset(&SAXHandler, 0, sizeof(xmlSAXHandler));

  SAXHandler.initialized    = XML_SAX2_MAGIC;
  SAXHandler.startElementNs = OnStartElementNs;
  SAXHandler.endElementNs   = OnEndElementNs;
  SAXHandler.characters     = OnCharacters;
  SAXHandler.serror         = OnStructuredErrorFunc;

  std::ifstream ifs(filePath);
  PRECICE_CHECK(ifs, "XML parser was unable to open configuration file \"" << filePath << '"');

  std::string content{std::istreambuf_iterator<char>(ifs), std::istreambuf_iterator<char>()};

  xmlParserCtxtPtr ctxt = xmlCreatePushParserCtxt(&SAXHandler, static_cast<void *>(this),
                                                  content.c_str(), content.size(), nullptr);

  xmlParseChunk(ctxt, nullptr, 0, 1);
  xmlFreeParserCtxt(ctxt);
  xmlCleanupParser();

  return 0;
}


void ConfigParser2::connectTags(const ConfigurationContext2 &context, std::vector<std::shared_ptr<XMLTag2>> &DefTags, CTagPtrVec &SubTags)
{
  std::unordered_set<std::string> usedTags;

write_log(fem1, 3,"here precice 5.2.1");
//PRECICE_TRACE(SubTags.front()->m_aSubTags[1]->m_aSubTags[0]->m_Name,SubTags.front()->m_aSubTags[1]->m_aSubTags[1]->m_Name,SubTags.front()->m_aSubTags[1]->m_aSubTags[2]->m_Name,SubTags.front()->m_aSubTags[1]->m_aSubTags[3]->m_Name,SubTags.front()->m_aSubTags[1]->m_aSubTags[4]->m_Name,SubTags.front()->m_aSubTags[1]->m_aSubTags[6]->m_Name);
//write_log(fem1, 3,"here precice 5.2.1");
//PRECICE_TRACE(DefTags.size(),DefTags.front()->_fullName);
//PRECICE_TRACE(DefTags.front()->_subtags[0]->_fullName,DefTags.front()->_subtags[1]->_fullName);

  for (auto &subtag : SubTags) {
  
  write_log(fem1, 3,"here precice start 5.2.2");
  
  write_log(fem1, 3, (subtag->m_Name).c_str());
   
  
    std::string expectedName = (subtag->m_Prefix.length() ? subtag->m_Prefix + ":" : "") + subtag->m_Name;
    
    write_log(fem1, 3,"here precice 5.2.3.1");
    
    PRECICE_TRACE(DefTags.size(),DefTags.front()->_fullName,expectedName);
    
    const auto  tagPosition  = std::find_if(
        DefTags.begin(),
        DefTags.end(),
        [expectedName](const std::shared_ptr<XMLTag2> &pTag) {
          return pTag->_fullName == expectedName;
        });
        
    write_log(fem1, 3, "outside");
    for (int i=0;i<DefTags.size();i++) { 		//Neu
        write_log(fem1, 3, (DefTags[i]->getName()).c_str());
    }
    write_log(fem1, 3,"outside2");

    if (tagPosition == DefTags.end()) {
      PRECICE_ERROR("The configuration contains an unknown tag <" + expectedName + ">.");
    }

    write_log(fem1, 3,"here precice 5.2.3");

    auto pDefSubTag = *tagPosition;
    pDefSubTag->resetAttributes();

    write_log(fem1, 3,"here precice 5.2.4");
    
    if ((pDefSubTag->_occurrence == XMLTag2::OCCUR_ONCE) || (pDefSubTag->_occurrence == XMLTag2::OCCUR_NOT_OR_ONCE)) {
      if (usedTags.count(pDefSubTag->_fullName)) {
        PRECICE_ERROR("Tag <" + pDefSubTag->_fullName + "> is not allowed to occur multiple times.");
      }
      
       write_log(fem1, 3,"inside 5.2.5");
       
      usedTags.emplace(pDefSubTag->_fullName);
    }
    
    write_log(fem1, 3,"here precice 5.2.5");
    
    pDefSubTag->_configuredNamespaces[pDefSubTag->_namespace] = true;
    pDefSubTag->readAttributes(subtag->m_aAttributes);
    pDefSubTag->_listener.XMLTagCallback(context, *pDefSubTag);
    pDefSubTag->_configured = true;

    //PRECICE_TRACE(pDefSubTag->_subtags[0]);

    connectTags(context, pDefSubTag->_subtags, subtag->m_aSubTags);

    pDefSubTag->areAllSubtagsConfigured();
    pDefSubTag->_listener.xmlEndTagCallback(context, *pDefSubTag);
    
    write_log(fem1, 3,"here precice 5.2.6");
    
  }
}


void ConfigParser2::OnStartElement(
    std::string         localname,
    std::string         prefix,
    CTag::AttributePair attributes)
{
  auto pTag = std::make_shared<CTag>();

  pTag->m_Prefix      = std::move(prefix);
  pTag->m_Name        = std::move(localname);
  pTag->m_aAttributes = std::move(attributes);

  if (not m_CurrentTags.empty()) {
    auto pParentTag = m_CurrentTags.back();
    pParentTag->m_aSubTags.push_back(pTag);
  }

  m_AllTags.push_back(pTag);
  m_CurrentTags.push_back(pTag);
}

void ConfigParser2::OnEndElement()
{
  m_CurrentTags.pop_back();
}

void ConfigParser2::OnTextSection(const std::string &)
{
  // This page intentionally left blank
}

} // namespace xml
} // namespace precice
