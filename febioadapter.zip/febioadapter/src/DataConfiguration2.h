#pragma once

#include <string>
#include <vector>
#include "logging/Logger.hpp"
#include "mesh/Data.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"

namespace precice {
namespace mesh {

/// Performs and provides configuration for Data objects from XML files.
class DataConfiguration2 : public xml::XMLTag2::Listener {
public:

  FEModel *fem1;
  
  struct ConfiguredData {
    std::string name;
    int         dimensions;

    ConfiguredData(
        const std::string &name,
        int                dimensions)
        : name(name), dimensions(dimensions) {}
  };

  DataConfiguration2(xml::XMLTag2 &parent, FEModel *fem);

  void setDimensions(int dimensions);

  const std::vector<ConfiguredData> &data() const;

  ConfiguredData getRecentlyConfiguredData() const;

  virtual void XMLTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);

  virtual void xmlEndTagCallback(
      const xml::ConfigurationContext2 &context,
      xml::XMLTag2 &                    callingTag);

  /**
   * @brief Adds data manually.
   *
   * @param[in] name Unqiue name of the data.
   * @param[in] dataDimensions Dimensionality (1: scalar, 2,3: vector) of data.
   */
  void addData(
      const std::string &name,
      int                dataDimensions);

  //int getDimensions() const;

private:
  mutable logging::Logger _log{"mesh::DataConfiguration2"};

  const std::string TAG          = "data";
  const std::string ATTR_NAME    = "name";
  const std::string VALUE_VECTOR = "vector";
  const std::string VALUE_SCALAR = "scalar";

  /// Dimension of space.
  int _dimensions = 0;

  std::vector<ConfiguredData> _data;

  int _indexLastConfigured = -1;

  int getDataDimensions(const std::string &typeName) const;
};

} // namespace mesh
} // namespace precice
