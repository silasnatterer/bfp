#pragma once

//#include "DistributedCommunication.hpp"

#include "DistributedCommunication2.h"

#include <memory>

#include "Mesh2.h"

namespace precice {
namespace m2n {
class DistributedComFactory2 {

public:
  using SharedPointer = std::shared_ptr<DistributedComFactory2>;

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  
  virtual ~DistributedComFactory2(){};

  virtual DistributedCommunication2::SharedPointer newDistributedCommunication(
      PtrMesh2 mesh) = 0;
};
} // namespace m2n
} // namespace precice
