#pragma once

#include <vector>
//#include "MappingContext.hpp"

#include "MappingContext2.h" 

#include "SharedPointer.hpp"

//#include "/home/jan/opendihu/dependencies/precice/src/precice-2.1.0/src/precice/impl/SharedPointer.hpp"

#include "com/Communication.hpp"
//#include "mapping/Mapping.hpp"

#include "Mapping2.h"

#include "mesh/SharedPointer.hpp"
//#include "partition/ReceivedPartition.hpp"

#include "ReceivedPartition2.h"

#include "partition/SharedPointer.hpp"

#include "Partition2.h"
#include "Mesh2.h"

namespace precice {
namespace impl {

  using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
  using PtrPartition2 = std::shared_ptr<precice::partition::Partition2>;
  
/// Stores a mesh and related objects and data.
struct MeshContext2 {
  MeshContext2(int dimensions)
      : localOffset(Eigen::VectorXd::Zero(dimensions))
  {
  }

  /** Upgrades the mesh requirement to a more specific level.
    * @param[in] requirement The requirement to upgrade to.
    */
  void require(mapping::Mapping2::MeshRequirement requirement);

  /// Mesh holding the geometry data structure.
  PtrMesh2 mesh;

  /// Data IDs of properties the geometry does possess.
  std::vector<int> associatedData;

  /// Determines which mesh type has to be provided by the accessor.
  mapping::Mapping2::MeshRequirement meshRequirement = mapping::Mapping2::MeshRequirement::UNDEFINED;

  /// Name of participant that creates the mesh.
  std::string receiveMeshFrom;

  /// bounding box to speed up decomposition of received mesh is increased by this safety factor
  double safetyFactor = -1;

  /// True, if accessor does create the mesh.
  bool provideMesh = false;

  /// type of geometric filter
  partition::ReceivedPartition::GeometricFilter geoFilter = partition::ReceivedPartition::GeometricFilter::UNDEFINED;

  /// Offset only applied to meshes local to the accessor.
  Eigen::VectorXd localOffset;

  /// Partition creating the parallel decomposition of the mesh
  PtrPartition2 partition;

  /// Mapping used when mapping data from the mesh. Can be empty.
  MappingContext2 fromMappingContext;

  /// Mapping used when mapping data to the mesh. Can be empty.
  MappingContext2 toMappingContext;
};

inline void MeshContext2::require(mapping::Mapping2::MeshRequirement requirement)
{
  meshRequirement = std::max(meshRequirement, requirement);
}

} // namespace impl
} // namespace precice
