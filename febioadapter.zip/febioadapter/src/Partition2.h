#pragma once

#include <string>
#include <vector>
#include "logging/Logger.hpp"
#include "m2n/SharedPointer.hpp"
#include "mapping/SharedPointer.hpp"
#include "mesh/SharedPointer.hpp"

#include "Mesh2.h"
#include "M2N2.h"
#include "Mapping2.h"

// ----------------------------------------------------------- CLASS DEFINITION

namespace precice {
namespace partition {

using PtrMesh2 = std::shared_ptr<precice::mesh::Mesh2>;
using PtrM2N2 = std::shared_ptr<precice::m2n::M2N2>;
using PtrMapping2 = std::shared_ptr<precice::mapping::Mapping2>;
  
/**
 * @brief Abstract base class for partitions.
 *
 * A Partition describes how a mesh is decomposed among multiple ranks and
 * is associated to a "use-mesh" a participant holds. This class holds the
 * structures that describe the decomposition (if not the mesh) and compute
 * them.
 *
 * A Partition can come in two flavors: Either defined by a participants
 * (provided=true in the config) or received from another participant
 * (from=... in the config).
 *
 * Access to the associated mesh, to both mappings (from and to this mesh),
 * and to an m2n communication to another participant is necessary.
 */
class Partition2 {
public:
  /// Constructor.
  Partition2(PtrMesh2 mesh);

  Partition2 &operator=(Partition2 &&) = delete;

  virtual ~Partition2() {}

  /// Intersections between bounding boxes around each rank are computed
  virtual void compareBoundingBoxes() = 0;

  /// The mesh is communicated between both master ranks (if required)
  virtual void communicate() = 0;

  /// The partition is computed, i.e. the mesh re-partitioned if required and all data structures are set up.
  virtual void compute() = 0;

  void setFromMapping(PtrMapping2 fromMapping)
  {
    _fromMapping = fromMapping;
  }

  void setToMapping(PtrMapping2 toMapping)
  {
    _toMapping = toMapping;
  }

  void addM2N(PtrM2N2 m2n)
  {
    _m2ns.push_back(m2n);
  }

protected:
  PtrMesh2 _mesh;

  PtrMapping2 _fromMapping;

  PtrMapping2 _toMapping;

  /// m2n connection to each connected participant
  std::vector<PtrM2N2> _m2ns;

private:
  logging::Logger _log{"partition::Partition"};
};

} // namespace partition
} // namespace precice
