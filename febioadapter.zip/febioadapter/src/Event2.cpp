//#include "Event.hpp"

#include "Event2.h"

//#include "EventUtils.hpp"

#include "EventUtils2.h"

#include "logging/LogMacros.hpp"

namespace precice {
namespace utils {

Event2::Event2(std::string eventName, Clock::duration initialDuration)
    : name(EventRegistry2::instance().prefix + eventName),
      duration(initialDuration)
{
  EventRegistry2::instance().put(*this);
}

Event2::Event2(std::string eventName, bool barrier, bool autostart)
    : name(eventName),
      _barrier(barrier)
{
  // Set prefix here: workaround to omit data lock between instance() and Event ctor
  if (eventName != "_GLOBAL")
    name = EventRegistry2::instance().prefix + eventName;
  if (autostart) {
    start(_barrier);
  }
}

Event2::~Event2()
{
  stop(_barrier);
}

void Event2::start(bool barrier)
{
  if (barrier)
    MPI_Barrier(EventRegistry2::instance().getMPIComm());

  state = State::STARTED;
  stateChanges.push_back(std::make_pair(State::STARTED, Clock::now()));
  starttime = Clock::now();
  PRECICE_DEBUG("Started event " << name);
}

void Event2::stop(bool barrier)
{
  if (state == State::STARTED or state == State::PAUSED) {
    if (barrier)
      MPI_Barrier(EventRegistry2::instance().getMPIComm());

    if (state == State::STARTED) {
      auto stoptime = Clock::now();
      duration += Clock::duration(stoptime - starttime);
    }
    stateChanges.push_back(std::make_pair(State::STOPPED, Clock::now()));
    state = State::STOPPED;
    EventRegistry2::instance().put(*this);
    data.clear();
    stateChanges.clear();
    duration = Clock::duration::zero();
    PRECICE_DEBUG("Stopped event " << name);
  }
}

void Event2::pause(bool barrier)
{
  if (state == State::STARTED) {
    if (barrier)
      MPI_Barrier(EventRegistry2::instance().getMPIComm());

    auto stoptime = Clock::now();
    stateChanges.emplace_back(State::PAUSED, Clock::now());
    state = State::PAUSED;
    duration += Clock::duration(stoptime - starttime);
    PRECICE_DEBUG("Paused event " << name);
  }
}

Event2::Clock::duration Event2::getDuration() const
{
  return duration;
}

void Event2::addData(std::string key, int value)
{
  data[key].push_back(value);
}

// -----------------------------------------------------------------------

ScopedEventPrefix2::ScopedEventPrefix2(std::string const &name)
{
  previousName = EventRegistry2::instance().prefix;
  EventRegistry2::instance().prefix += name;
}

ScopedEventPrefix2::~ScopedEventPrefix2()
{
  EventRegistry2::instance().prefix = previousName;
}

} // namespace utils
} // namespace precice
