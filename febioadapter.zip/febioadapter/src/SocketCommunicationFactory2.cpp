#include "SocketCommunicationFactory2.h"
#include <memory>
//#include "SocketCommunication.hpp"

#include "SocketCommunication2.h"

#include "com/SharedPointer.hpp"
#include "utils/networking.hpp"

namespace precice {
namespace com {

  using PtrCommunication2 = std::shared_ptr<Communication2>;
  
SocketCommunicationFactory2::SocketCommunicationFactory2(
    unsigned short     portNumber,
    bool               reuseAddress,
    std::string const &networkName,
    std::string const &addressDirectory)
    : _portNumber(portNumber),
      _reuseAddress(reuseAddress),
      _networkName(networkName),
      _addressDirectory(addressDirectory)
{
  if (_addressDirectory.empty()) {
    _addressDirectory = ".";
  }
}

SocketCommunicationFactory2::SocketCommunicationFactory2(
    std::string const &addressDirectory)
    : SocketCommunicationFactory2(0, false, utils::networking::loopbackInterfaceName(), addressDirectory)
{
}

PtrCommunication2 SocketCommunicationFactory2::newCommunication()
{
  return std::make_shared<SocketCommunication2>(
      _portNumber, _reuseAddress, _networkName, _addressDirectory);
}

std::string SocketCommunicationFactory2::addressDirectory()
{
  return _addressDirectory;
}
} // namespace com
} // namespace precice
