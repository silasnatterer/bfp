#pragma once

#include <list>
#include <string>
#include "io/ExportContext.hpp"
#include "logging/Logger.hpp"
//#include "xml/XMLTag.hpp"

#include "XMLTag2.h"

namespace precice {
namespace io {

/**
 * @brief Configuration class for exports.
 */
class ExportConfiguration2 : public xml::XMLTag2::Listener {
public:

  FEModel *fem1;
   
  ExportConfiguration2(xml::XMLTag2 &parent, FEModel *fem);

  /**
   * @brief Returns the configured export context
   */
  std::list<ExportContext> &exportContexts()
  {
    return _contexts;
  }

  virtual void XMLTagCallback(const xml::ConfigurationContext2 &context, xml::XMLTag2 &callingTag);

  /// Callback from automatic configuration. Not utilitzed here.
  virtual void xmlEndTagCallback(const xml::ConfigurationContext2 &context, xml::XMLTag2 &callingTag) {}

  void resetExports()
  {
    _contexts.clear();
  }

private:
  logging::Logger _log{"io::ExportConfiguration2"};

  const std::string TAG = "export";

  const std::string ATTR_LOCATION = "directory";
  const std::string ATTR_TYPE     = "type";
  const std::string ATTR_AUTO     = "auto";
  const std::string VALUE_VTK     = "vtk";

  const std::string ATTR_EVERY_N_TIME_WINDOWS = "every-n-time-windows";
  const std::string ATTR_NEIGHBORS            = "neighbors";
  const std::string ATTR_TRIGGER_SOLVER       = "trigger-solver";
  const std::string ATTR_NORMALS              = "normals";
  const std::string ATTR_EVERY_ITERATION      = "every-iteration";

  std::list<ExportContext> _contexts;
};

} // namespace io
} // namespace precice
